﻿using System;
using Styx;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Pathing;
using Styx.Logic.AreaManagement;
using Styx.Logic.BehaviorTree;
using Styx.Logic.Profiles;
using Styx.Logic.Combat;
using Styx.Combat.CombatRoutine;
using Styx.Plugins;
using Styx.Plugins.PluginClass;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.Misc;
using Styx.WoWInternals.World;
using Styx.Logic.Inventory;
using Styx.Logic.Inventory.Frames.Gossip;
using Styx.Logic.Inventory.Frames.Quest;
using Styx.Logic.Inventory.Frames.LootFrame;
using System.Collections.Generic;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Xml.Linq;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Forms;
using System.Drawing;
using System.Text;
using System.ComponentModel;
using System.Media;
//using Microsoft.Aspnet.Snapin;

namespace ShutUp
{
    public partial class Form_ShutUp : Form
    {
        string ShutUpLogLocation = (Logging.ApplicationPath + "\\Plugins\\ShutUp\\Logs\\ShutUp_Log_" + ObjectManager.Me.Name + ".txt");

        public Form_ShutUp()
        {
            InitializeComponent();
        }

        private void Form_ShutUp_Load(object sender, EventArgs e)
        {
            var _shutUp = new ShutUp();
            VersionLabel.Text = "v" + _shutUp.Version.ToString();

            BarryD.Image = Image.FromStream(new MemoryStream(new WebClient().DownloadData("http://www.thebuddyforum.com/avatars/barrydurex.gif")));
            guildMasterCheck.Text = Lua.GetReturnVal<string>("return GuildControlGetRankName(1);", 0);
            guildOfficersCheck.Text = (Lua.GetReturnVal<string>("return GuildControlGetRankName(2);", 0) + "  (Rank 2)");

            #region list friendslist
            List<string> inGameFriends = new List<string>();
            int numFriends = Lua.GetReturnVal<int>("return GetNumFriends()", 0);
            for (int i = 1; numFriends != 0 && i <= numFriends; ++i)
            {
                string xName = Lua.GetReturnVal<string>("local name, level, klasse, ort, online = GetFriendInfo(" + i + "); return name", 0);
                inGameFriends.Add(xName);
            }
            #endregion

            #region list Guild
            List<string> guildMembers = new List<string>();
            List<string> guildOffis = new List<string>();
            int numGuildMembers = Lua.GetReturnVal<int>("local numTotal, numOnline = GetNumGuildMembers(); return numTotal", 0);
            for (int i = 1; numGuildMembers != 0 && i <= numGuildMembers; ++i)
            {
                string xName = Lua.GetReturnVal<string>("local name, rank, rankIndex, level, class, zone, note, officernote, online, status, classFileName, achievementPoints, achievementRank, isMobile = GetGuildRosterInfo(" + i + "); return name", 0);
                int xRank = Lua.GetReturnVal<int>("local name, rank, rankIndex, level, class, zone, note, officernote, online, status, classFileName, achievementPoints, achievementRank, isMobile = GetGuildRosterInfo(" + i + "); return rankIndex", 0);

                if (xName != ObjectManager.Me.Name) guildMembers.Add(xName);
                if (xRank == 0) guildMaster.Text = xName;
                if (xRank == 1) guildOffis.Add(xName);
            }
            #endregion

            guildMembersList.Lines = guildMembers.ToArray();
            guildOfficersList.Lines = guildOffis.ToArray();
            inGameFriendList.Lines = inGameFriends.ToArray();

            soundOnCheck.Checked = ShutUpSettings.Instance.SoundOn;
            comboBox1.SelectedItem = (string)ShutUpSettings.Instance.selectedSound;
            LogSaveCheck.Checked = ShutUpSettings.Instance.saveLog;
            answerWhisperCheck.Checked = ShutUpSettings.Instance.answerWisper;
            answerBGCheck.Checked = ShutUpSettings.Instance.answerBG;
            answerAfterSecMin.Value = (int)ShutUpSettings.Instance.answerBetweenMin;
            answerAfterSecMax.Value = (int)ShutUpSettings.Instance.answerBetweenMax;
            answerContainBG.Checked = ShutUpSettings.Instance.ContainAnswerBG;
            ignoAll.Checked = ShutUpSettings.Instance.ignoAll;
            ignoAfterX.Checked = ShutUpSettings.Instance.ignoXW;
            ignoNo.Checked = ShutUpSettings.Instance.ignoNo;
            FriendList1Check.Checked = ShutUpSettings.Instance.UseFriedlist1;
            guildMasterCheck.Checked = ShutUpSettings.Instance.UseGuildMaster;
            guildOfficersCheck.Checked = ShutUpSettings.Instance.UseGuildOffisList;
            guildMembersCheck.Checked = ShutUpSettings.Instance.UseGuildMembersList;
            inGameFriendsCheck.Checked = ShutUpSettings.Instance.UseInGameFriedlist;
            SoundByFriendCheck.Checked = ShutUpSettings.Instance.SoundByFriend;
            comboBox2.SelectedItem = (string)ShutUpSettings.Instance.selectedFriendSound;
            answerFriendsCheck.Checked = ShutUpSettings.Instance.answerFriend;
            softIgnoFriendsCheck.Checked = ShutUpSettings.Instance.softIgnoFriend;
            softIgnoFriendsAfter.Value = (int)ShutUpSettings.Instance.softIgnoFrAfter;
            softIgnoAfter.Value = (int)ShutUpSettings.Instance.softIgnoAfter;
            soundLoop.Value = (int)ShutUpSettings.Instance.SoundLoop;
            soundLoopEvery.Value = (int)ShutUpSettings.Instance.SoundLoopEvery;
            UseExternalPlayerCheck.Checked = ShutUpSettings.Instance.useExternalPlayer;
            soundByGMwhisperCheck.Checked = ShutUpSettings.Instance.GMwhisperSound;
            logoutByGMwhisperCheck.Checked = ShutUpSettings.Instance.logoutByGMwhisper;
            soundNearByGMCheck.Checked = ShutUpSettings.Instance.nearByGMsound;
            logoutNearByGMCheck.Checked = ShutUpSettings.Instance.logoutNearByGM;
            answerGMwhisperCheck.Checked = ShutUpSettings.Instance.answerGM;
            //guildMaster.Text = ShutUpSettings.Instance.GuildMaster;
            //guildOfficersList.Lines = ShutUpSettings.Instance.GuildOfficers;
            //guildMembersList.Lines = ShutUpSettings.Instance.GuildMembers;
            //inGameFriendList.Lines = ShutUpSettings.Instance.InGameFriends;

            loadShutUpGlobalSettings();

            OpenFile();

            if (!ShutUpSettings.Instance.saveLog)
            {
                //MessageBox.Show("Save in Log is off!", "Info", MessageBoxButtons.OK);
                _shutUp.slog("Save in Log is off!");
            }

            if (guildMembersCheck.Checked) { guildMasterCheck.Enabled = false; guildOfficersCheck.Enabled = false; }
            else if (!guildMembersCheck.Checked) { guildMasterCheck.Enabled = true; guildOfficersCheck.Enabled = true; }
        }

        private void Form_ShutUp_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        public void Form_ShutUp_FormClosed(object sender, FormClosedEventArgs e)
        {
            var _shutUp = new ShutUp();
            if (ShutUpSettings.Instance.answerWisper && ShutUpGlobalSettings.Instance.rAnswerW1 == string.Empty && ShutUpGlobalSettings.Instance.rAnswerW2 == string.Empty &&
                ShutUpGlobalSettings.Instance.rAnswerW3 == string.Empty && ShutUpGlobalSettings.Instance.rAnswerW4 == string.Empty)
            {
                //MessageBox.Show(" You have answer to whisper selected,\n but you have added no random reply!", "AnswerError", MessageBoxButtons.OK);
                _shutUp.dlog("#6 : You have answer to whisper selected, but you have added no random reply!");
            }

            if (ShutUpSettings.Instance.answerBG && ShutUpGlobalSettings.Instance.rAnswerBG1 == string.Empty && ShutUpGlobalSettings.Instance.rAnswerBG2 == string.Empty &&
                ShutUpGlobalSettings.Instance.rAnswerBG3 == string.Empty && ShutUpGlobalSettings.Instance.rAnswerBG4 == string.Empty)
            {
                //MessageBox.Show(" You have answer to BG-Chat selected,\n but you have added no random reply!", "AnswerError", MessageBoxButtons.OK);
                _shutUp.dlog("#7 : You have answer to BG-Chat selected,\n but you have added no random reply!");
            }
        }

        public void Form_ShutUp_Shown(object sender, EventArgs e)
        {

        }

        public void ShutUpLog(string message)
        {
                tbLog.AppendText(message);
                tbLog.ScrollToCaret();
        }

        private void Openbutton_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                this.WaveLocation.Text = openFileDialog1.FileName;
            }
        }

        private void clearLog_button_Click(object sender, EventArgs e)
        {
            File.Delete(ShutUpLogLocation);
            File.Create(ShutUpLogLocation);
            this.tbLog.Text = string.Empty;
        }

        public void OpenFile()
        {
            var _shutUp = new ShutUp();

            string strFileContents = "";
            try
            {
                strFileContents = File.ReadAllText(ShutUpLogLocation);
            }
            //return false if problem opening file
            catch (Exception ex) 
            {
                _shutUp.dlog("#8 : Log not found! Perhaps there is no folder \"Logs\" in the \"HonorBuddy/Plugins/ShutUp/\" directory! If it is your first start, ignore this message and start HonorBuddy \"shortly\" first!");
                //MessageBox.Show("Error: Log not found! \n Perhaps there is no folder \"Logs\" in the \n \"HonorBuddy/Plugins/ShutUp/\" directory! \n \n If it is your first start,\n ignore this message and start HonorBuddy \"shortly\" first! \n \n " + ex + "", "Error", MessageBoxButtons.OK);
                System.Windows.Forms.MessageBox.Show("Error #8: Log not found! \n \n If it is your first start,\n ignore this message and start HonorBuddy \"shortly\" first!", "Error #8", MessageBoxButtons.OK); 
                
            }

            if (strFileContents != "")
            {
                this.ShutUpLog(strFileContents);
            }
        }

        private void BarryD_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.thebuddyforum.com/honorbuddy-forum/plugins/free/monitoring/21926-%5Bplugin-alert%5D-shutup-whisper-alert-answer-ingnore.html");
        }

        private void Titel_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.thebuddyforum.com/honorbuddy-forum/plugins/free/monitoring/21926-%5Bplugin-alert%5D-shutup-whisper-alert-answer-ingnore.html");
        }

        private void soundTestButton_Click(object sender, EventArgs e)
        {
            Object selectedItem = comboBox1.SelectedItem.ToString();

            if (selectedItem == "bing sound")
            {
                System.Media.SystemSounds.Beep.Play();
                System.Media.SystemSounds.Beep.Play();
            }
            else if (selectedItem == "MyWave")
            {
                if (WaveLocation.Text == "C:/MyFolder/MyWave.wav" || WaveLocation.Text == string.Empty)
                {
                    System.Windows.Forms.MessageBox.Show("#5.2 : you have not selected a wave! \n \n   -klick on the search button!", "Error #5.2", MessageBoxButtons.OK);
                }
                else
                {
                    new SoundPlayer(WaveLocation.Text).Play();
                }
            }
            else
            {
                new SoundPlayer(Logging.ApplicationPath + "\\Plugins\\ShutUp\\Sounds\\" + comboBox1.SelectedItem.ToString()).Play();
            }
        }

        //public string ShutUpSoundLocation() // made by katzerle
        //{
        //    string File = "Plugins\\ShutUp\\Sounds\\";
        //    string sPath = Process.GetCurrentProcess().MainModule.FileName;
        //    sPath = Path.GetDirectoryName(sPath);
        //    sPath = Path.Combine(sPath, File);
        //    sPath = Path.Combine(sPath, comboBox1.SelectedItem.ToString());
        //    return sPath;
        //}

        private void AnswerBetween_Change(object sender, EventArgs e)
        {
            if (answerAfterSecMin.Value > answerAfterSecMax.Value)
            {
                --answerAfterSecMin.Value;
            }
        }

        private void saveBackUpButton_Click(object sender, EventArgs e)
        {
            saveShutUpSettings();
            var saveBackup = new SaveFileDialog
            {
                Filter = "Xml files | *.xml",
                Title = "Select where to save file!"
            };

            if (saveBackup.ShowDialog() == DialogResult.OK)
            {
                string fileName = saveBackup.FileName;
                ShutUpGlobalSettings.Instance.SaveToFile(fileName);
                Logging.Write(System.Drawing.Color.Red, "save backup");
            }
        }

        private void loadBackUpButton_Click(object sender, EventArgs e)
        {
            var loadBackup = new OpenFileDialog
            {
                Filter = "Xml files | *.xml",
                Title = "Select xml file to load"
            };

            if (loadBackup.ShowDialog() == DialogResult.OK)
            {
                string fileName = loadBackup.FileName;
                if (!string.IsNullOrEmpty(fileName))
                {
                    ShutUpGlobalSettings.Instance.LoadFromXML(XElement.Load(fileName));
                    loadShutUpGlobalSettings();
                    var _ShutUp = new ShutUp();
                    _ShutUp.slog("load backup");
                }
            }
        }

        public void cancelWindow_Click(object sender, EventArgs e)
        {
            var _ShutUp = new ShutUp();
            _ShutUp.slog("cancel changes & close");
            Form_ShutUp.ActiveForm.Close();
        }

        public void closeWindow_Click(object sender, EventArgs e)
        {
            saveShutUpSettings();
            var _ShutUp = new ShutUp();
            _ShutUp.slog("save settings & close");
            Form_ShutUp.ActiveForm.Close();
        }

        public void saveShutUpSettings()
        {
            ShutUpSettings.Instance.SoundOn = soundOnCheck.Checked;
            ShutUpSettings.Instance.selectedSound = (string)comboBox1.SelectedItem;
            ShutUpSettings.Instance.saveLog = LogSaveCheck.Checked;
            ShutUpSettings.Instance.answerWisper = answerWhisperCheck.Checked;
            ShutUpSettings.Instance.answerBG = answerBGCheck.Checked;
            ShutUpSettings.Instance.answerBetweenMin = (int)answerAfterSecMin.Value;
            ShutUpSettings.Instance.answerBetweenMax = (int)answerAfterSecMax.Value;
            ShutUpSettings.Instance.ContainAnswerBG = answerContainBG.Checked;
            ShutUpSettings.Instance.ignoAll = ignoAll.Checked;
            ShutUpSettings.Instance.ignoXW = ignoAfterX.Checked;
            ShutUpSettings.Instance.ignoNo = ignoNo.Checked;
            ShutUpSettings.Instance.UseFriedlist1 = FriendList1Check.Checked;
            ShutUpSettings.Instance.UseGuildMaster = guildMasterCheck.Checked;
            ShutUpSettings.Instance.UseGuildOffisList = guildOfficersCheck.Checked;
            ShutUpSettings.Instance.UseGuildMembersList = guildMembersCheck.Checked;
            ShutUpSettings.Instance.UseInGameFriedlist = inGameFriendsCheck.Checked;
            ShutUpSettings.Instance.SoundByFriend = SoundByFriendCheck.Checked;
            ShutUpSettings.Instance.selectedFriendSound = (string)comboBox2.SelectedItem;
            ShutUpSettings.Instance.answerFriend = answerFriendsCheck.Checked;
            ShutUpSettings.Instance.softIgnoFriend = softIgnoFriendsCheck.Checked;
            ShutUpSettings.Instance.softIgnoFrAfter = (int)softIgnoFriendsAfter.Value;
            ShutUpSettings.Instance.softIgnoAfter = (int)softIgnoAfter.Value;
            ShutUpSettings.Instance.ingameIgno = ingameIgnoCheck.Checked;
            ShutUpSettings.Instance.SoundLoop = (int)soundLoop.Value;
            ShutUpSettings.Instance.SoundLoopEvery = (int)soundLoopEvery.Value;
            ShutUpSettings.Instance.useExternalPlayer = UseExternalPlayerCheck.Checked;
            ShutUpSettings.Instance.GuildMaster = (string)guildMaster.Text;
            ShutUpSettings.Instance.GuildOfficers = guildOfficersList.Lines;
            ShutUpSettings.Instance.GuildMembers = guildMembersList.Lines;
            ShutUpSettings.Instance.InGameFriends = inGameFriendList.Lines;
            if (string.IsNullOrEmpty(friendList1.Text) && FriendList1Check.Checked) { ShutUpSettings.Instance.UseFriedlist1 = false; }
            if (string.IsNullOrEmpty(guildMembersList.Text) && guildMembersCheck.Checked) { ShutUpSettings.Instance.UseGuildMembersList = false; }
            if (string.IsNullOrEmpty(guildMaster.Text) && guildMasterCheck.Checked) { ShutUpSettings.Instance.UseGuildMaster = false; }
            if (string.IsNullOrEmpty(guildOfficersList.Text) && guildOfficersCheck.Checked) { ShutUpSettings.Instance.UseGuildOffisList = false; }
            if (string.IsNullOrEmpty(inGameFriendList.Text) && inGameFriendsCheck.Checked) { ShutUpSettings.Instance.UseInGameFriedlist = false; }
            ShutUpSettings.Instance.GMwhisperSound = soundByGMwhisperCheck.Checked;
            ShutUpSettings.Instance.logoutByGMwhisper = logoutByGMwhisperCheck.Checked;
            ShutUpSettings.Instance.nearByGMsound = soundNearByGMCheck.Checked;
            ShutUpSettings.Instance.logoutNearByGM = logoutNearByGMCheck.Checked;
            ShutUpSettings.Instance.answerGM = answerGMwhisperCheck.Checked;
            ShutUpSettings.Instance.Save();

            Thread.Sleep(500);

            ShutUpGlobalSettings.Instance.myWaveLocation = (string)WaveLocation.Text;
            ShutUpGlobalSettings.Instance.rAnswerW1 = (string)rAnswerW1.Text;
            ShutUpGlobalSettings.Instance.rAnswerW2 = (string)rAnswerW2.Text;
            ShutUpGlobalSettings.Instance.rAnswerW3 = (string)rAnswerW3.Text;
            ShutUpGlobalSettings.Instance.rAnswerW4 = (string)rAnswerW4.Text;
            ShutUpGlobalSettings.Instance.rAnswerBG1 = (string)rAnswerBG1.Text;
            ShutUpGlobalSettings.Instance.rAnswerBG2 = (string)rAnswerBG2.Text;
            ShutUpGlobalSettings.Instance.rAnswerBG3 = (string)rAnswerBG3.Text;
            ShutUpGlobalSettings.Instance.rAnswerBG4 = (string)rAnswerBG4.Text;
            ShutUpGlobalSettings.Instance.contain1 = (string)containBox1.Text;
            ShutUpGlobalSettings.Instance.contain2 = (string)containBox2.Text;
            ShutUpGlobalSettings.Instance.contain3 = (string)containBox3.Text;
            ShutUpGlobalSettings.Instance.contain4 = (string)containBox4.Text;
            ShutUpGlobalSettings.Instance.answerContain1 = (string)answerText1.Text;
            ShutUpGlobalSettings.Instance.answerContain2 = (string)answerText2.Text;
            ShutUpGlobalSettings.Instance.answerContain3 = (string)answerText3.Text;
            ShutUpGlobalSettings.Instance.answerContain4 = (string)answerText4.Text;
            ShutUpGlobalSettings.Instance.FriendList1 = friendList1.Lines;
            ShutUpGlobalSettings.Instance.answerGMwhisper = (string)answerGMtext.Text;
            ShutUpGlobalSettings.Instance.Save();

            //Logging.Write(System.Drawing.Color.Red, "[ShutUp]: save settings &");
        }
         
        public void loadShutUpGlobalSettings()
        {
            WaveLocation.Text = (string)ShutUpGlobalSettings.Instance.myWaveLocation;
            rAnswerW1.Text = (string)ShutUpGlobalSettings.Instance.rAnswerW1;
            rAnswerW2.Text = (string)ShutUpGlobalSettings.Instance.rAnswerW2;
            rAnswerW3.Text = (string)ShutUpGlobalSettings.Instance.rAnswerW3;
            rAnswerW4.Text = (string)ShutUpGlobalSettings.Instance.rAnswerW4;
            rAnswerBG1.Text = (string)ShutUpGlobalSettings.Instance.rAnswerBG1;
            rAnswerBG2.Text = (string)ShutUpGlobalSettings.Instance.rAnswerBG2;
            rAnswerBG3.Text = (string)ShutUpGlobalSettings.Instance.rAnswerBG3;
            rAnswerBG4.Text = (string)ShutUpGlobalSettings.Instance.rAnswerBG4;
            containBox1.Text = (string)ShutUpGlobalSettings.Instance.contain1;
            containBox2.Text = (string)ShutUpGlobalSettings.Instance.contain2;
            containBox3.Text = (string)ShutUpGlobalSettings.Instance.contain3;
            containBox4.Text = (string)ShutUpGlobalSettings.Instance.contain4;
            answerText1.Text = (string)ShutUpGlobalSettings.Instance.answerContain1;
            answerText2.Text = (string)ShutUpGlobalSettings.Instance.answerContain2;
            answerText3.Text = (string)ShutUpGlobalSettings.Instance.answerContain3;
            answerText4.Text = (string)ShutUpGlobalSettings.Instance.answerContain4;
            friendList1.Lines = ShutUpGlobalSettings.Instance.FriendList1;        
            answerGMtext.Text = (string)ShutUpGlobalSettings.Instance.answerGMwhisper;
        }

        private void guildMembersCheck_Click(object sender, EventArgs e)
        {
            if (guildMembersCheck.Checked) { guildMasterCheck.Enabled = false; guildOfficersCheck.Enabled = false; }
            else if (!guildMembersCheck.Checked) { guildMasterCheck.Enabled = true; guildOfficersCheck.Enabled = true; }
        }
    }
}
#region Nothing to see here!
//this.friendListTab.Controls.Add(this.label12);
//this.friendListTab.Controls.Add(this.groupBox13);
//this.friendListTab.Controls.Add(this.FriendListInfoText);
//this.friendListTab.Controls.Add(this.checkFriendList3);
//this.friendListTab.Controls.Add(this.checkFriendList2);
//this.friendListTab.Controls.Add(this.checkFriendList1);
//this.friendListTab.Controls.Add(this.friendList3);
//this.friendListTab.Controls.Add(this.friendList2);
//this.friendListTab.Controls.Add(this.friendList1);

//this.friendListTab.Controls.Add(this.RevisingLabel);
#endregion