﻿using System;
using Styx;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Pathing;
using Styx.Logic.AreaManagement;
using Styx.Logic.BehaviorTree;
//using Styx.Logic.Profiles;
//using Styx.Logic.Combat;
//using Styx.Combat.CombatRoutine;
using Styx.Plugins;
using Styx.Plugins.PluginClass;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.Misc;
using Styx.WoWInternals.World;
//using Styx.Logic.Inventory;
//using Styx.Logic.Inventory.Frames.Gossip;
//using Styx.Logic.Inventory.Frames.Quest;
//using Styx.Logic.Inventory.Frames.LootFrame;
using System.Collections.Generic;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Xml.Linq;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Forms;
using System.Drawing;
using System.Text;
//using System.ComponentModel;
//using Microsoft.Aspnet.Snapin;

namespace ShutUp
{
    partial class Form_ShutUp
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.BarryD = new System.Windows.Forms.PictureBox();
            this.Titel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.UseExternalPlayerCheck = new System.Windows.Forms.CheckBox();
            this.soundTestButton = new System.Windows.Forms.Button();
            this.soundOnCheck = new System.Windows.Forms.CheckBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Openbutton = new System.Windows.Forms.Button();
            this.WaveLocation = new System.Windows.Forms.TextBox();
            this.labelx = new System.Windows.Forms.Label();
            this.VersionLabel = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.clearLog_button = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.LogSaveCheck = new System.Windows.Forms.CheckBox();
            this.saveBackupButton = new System.Windows.Forms.Button();
            this.loadBackupButton = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.answerBGCheck = new System.Windows.Forms.CheckBox();
            this.answerWhisperCheck = new System.Windows.Forms.CheckBox();
            this.answerAfterSecMin = new System.Windows.Forms.NumericUpDown();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.answerAfterSecMax = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.softIgnoAfter = new System.Windows.Forms.NumericUpDown();
            this.ingameIgnoCheck = new System.Windows.Forms.CheckBox();
            this.ignoAfterX = new System.Windows.Forms.RadioButton();
            this.ignoNo = new System.Windows.Forms.RadioButton();
            this.ignoAll = new System.Windows.Forms.RadioButton();
            this.saveButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.LogTab = new System.Windows.Forms.TabPage();
            this.tbLog = new System.Windows.Forms.RichTextBox();
            this.answerTab = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.answerContainBG = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.answerText4 = new System.Windows.Forms.TextBox();
            this.answerText3 = new System.Windows.Forms.TextBox();
            this.answerText2 = new System.Windows.Forms.TextBox();
            this.answerText1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.containBox4 = new System.Windows.Forms.TextBox();
            this.containBox3 = new System.Windows.Forms.TextBox();
            this.containBox2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.containBox1 = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.rAnswerBG4 = new System.Windows.Forms.TextBox();
            this.rAnswerBG3 = new System.Windows.Forms.TextBox();
            this.rAnswerBG2 = new System.Windows.Forms.TextBox();
            this.rAnswerBG1 = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.rAnswerW4 = new System.Windows.Forms.TextBox();
            this.rAnswerW3 = new System.Windows.Forms.TextBox();
            this.rAnswerW2 = new System.Windows.Forms.TextBox();
            this.rAnswerW1 = new System.Windows.Forms.TextBox();
            this.friendListTab = new System.Windows.Forms.TabPage();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.answerFriendsCheck = new System.Windows.Forms.CheckBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.softIgnoFriendsCheck = new System.Windows.Forms.CheckBox();
            this.softIgnoFriendsAfter = new System.Windows.Forms.NumericUpDown();
            this.guildOfficersCheck = new System.Windows.Forms.CheckBox();
            this.guildMasterCheck = new System.Windows.Forms.CheckBox();
            this.guildOfficersList = new System.Windows.Forms.RichTextBox();
            this.guildMaster = new System.Windows.Forms.RichTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.SoundByFriendCheck = new System.Windows.Forms.CheckBox();
            this.inGameFriendsCheck = new System.Windows.Forms.CheckBox();
            this.guildMembersCheck = new System.Windows.Forms.CheckBox();
            this.FriendList1Check = new System.Windows.Forms.CheckBox();
            this.inGameFriendList = new System.Windows.Forms.RichTextBox();
            this.guildMembersList = new System.Windows.Forms.RichTextBox();
            this.friendList1 = new System.Windows.Forms.RichTextBox();
            this.GMalertTab = new System.Windows.Forms.TabPage();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.logoutNearByGMCheck = new System.Windows.Forms.CheckBox();
            this.soundNearByGMCheck = new System.Windows.Forms.CheckBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.answerGMtext = new System.Windows.Forms.TextBox();
            this.logoutByGMwhisperCheck = new System.Windows.Forms.CheckBox();
            this.answerGMwhisperCheck = new System.Windows.Forms.CheckBox();
            this.soundByGMwhisperCheck = new System.Windows.Forms.CheckBox();
            this.RevisingLabel = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.soundLoopEvery = new System.Windows.Forms.NumericUpDown();
            this.soundLoop = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.BarryD)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.answerAfterSecMin)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.answerAfterSecMax)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.softIgnoAfter)).BeginInit();
            this.tabControl.SuspendLayout();
            this.LogTab.SuspendLayout();
            this.answerTab.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.friendListTab.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.softIgnoFriendsAfter)).BeginInit();
            this.groupBox13.SuspendLayout();
            this.GMalertTab.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.soundLoopEvery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soundLoop)).BeginInit();
            this.SuspendLayout();
            // 
            // BarryD
            // 
            this.BarryD.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.BarryD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BarryD.Location = new System.Drawing.Point(7, 2);
            this.BarryD.Name = "BarryD";
            this.BarryD.Size = new System.Drawing.Size(80, 80);
            this.BarryD.TabIndex = 100;
            this.BarryD.TabStop = false;
            this.BarryD.Click += new System.EventHandler(this.BarryD_Click);
            // 
            // Titel
            // 
            this.Titel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Titel.AutoSize = true;
            this.Titel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Titel.Font = new System.Drawing.Font("Comic Sans MS", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Titel.Location = new System.Drawing.Point(265, -4);
            this.Titel.Name = "Titel";
            this.Titel.Size = new System.Drawing.Size(235, 67);
            this.Titel.TabIndex = 0;
            this.Titel.Text = "[ShutUp]";
            this.Titel.Click += new System.EventHandler(this.Titel_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox1.Controls.Add(this.UseExternalPlayerCheck);
            this.groupBox1.Controls.Add(this.soundTestButton);
            this.groupBox1.Controls.Add(this.soundOnCheck);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(105, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(116, 122);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sound";
            // 
            // UseExternalPlayerCheck
            // 
            this.UseExternalPlayerCheck.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.UseExternalPlayerCheck.AutoSize = true;
            this.UseExternalPlayerCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UseExternalPlayerCheck.Location = new System.Drawing.Point(8, 89);
            this.UseExternalPlayerCheck.Name = "UseExternalPlayerCheck";
            this.UseExternalPlayerCheck.Size = new System.Drawing.Size(104, 28);
            this.UseExternalPlayerCheck.TabIndex = 110;
            this.UseExternalPlayerCheck.Text = "use external Player \r\n(example: for Mp3)";
            this.UseExternalPlayerCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.UseExternalPlayerCheck.UseVisualStyleBackColor = true;
            // 
            // soundTestButton
            // 
            this.soundTestButton.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.soundTestButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.soundTestButton.Location = new System.Drawing.Point(11, 64);
            this.soundTestButton.Name = "soundTestButton";
            this.soundTestButton.Size = new System.Drawing.Size(94, 23);
            this.soundTestButton.TabIndex = 109;
            this.soundTestButton.Text = "sound &test";
            this.soundTestButton.UseVisualStyleBackColor = true;
            this.soundTestButton.Click += new System.EventHandler(this.soundTestButton_Click);
            // 
            // soundOnCheck
            // 
            this.soundOnCheck.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.soundOnCheck.AutoSize = true;
            this.soundOnCheck.Checked = true;
            this.soundOnCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.soundOnCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.soundOnCheck.Location = new System.Drawing.Point(21, 19);
            this.soundOnCheck.Name = "soundOnCheck";
            this.soundOnCheck.Size = new System.Drawing.Size(77, 17);
            this.soundOnCheck.TabIndex = 108;
            this.soundOnCheck.Text = "PlaySound";
            this.soundOnCheck.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "bing sound",
            "MySoundFile",
            "beep.wav",
            "boing.wav",
            "canwedo.wav",
            "elephant.wav",
            "himan.wav",
            "murloc.wav",
            "scream.wav",
            "siren1.wav",
            "snore.wav",
            "youagain.wav"});
            this.comboBox1.Location = new System.Drawing.Point(11, 37);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(94, 21);
            this.comboBox1.TabIndex = 107;
            this.comboBox1.Text = "select a sound";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox2.Controls.Add(this.Openbutton);
            this.groupBox2.Controls.Add(this.WaveLocation);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(13, 178);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(522, 44);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "MySoundFile  (*.wav | *.mp3)";
            // 
            // Openbutton
            // 
            this.Openbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Openbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Openbutton.Location = new System.Drawing.Point(441, 14);
            this.Openbutton.Name = "Openbutton";
            this.Openbutton.Size = new System.Drawing.Size(75, 24);
            this.Openbutton.TabIndex = 101;
            this.Openbutton.Text = "&search";
            this.Openbutton.UseVisualStyleBackColor = true;
            this.Openbutton.Click += new System.EventHandler(this.Openbutton_Click);
            // 
            // WaveLocation
            // 
            this.WaveLocation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.WaveLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WaveLocation.Location = new System.Drawing.Point(6, 17);
            this.WaveLocation.Name = "WaveLocation";
            this.WaveLocation.Size = new System.Drawing.Size(429, 20);
            this.WaveLocation.TabIndex = 0;
            this.WaveLocation.Text = "C:/MyFolder/MyWave.wav ";
            // 
            // labelx
            // 
            this.labelx.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.labelx.AutoSize = true;
            this.labelx.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.labelx.Location = new System.Drawing.Point(491, 580);
            this.labelx.Name = "labelx";
            this.labelx.Size = new System.Drawing.Size(55, 9);
            this.labelx.TabIndex = 55;
            this.labelx.Text = "by BarryDurex";
            // 
            // VersionLabel
            // 
            this.VersionLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.VersionLabel.AutoSize = true;
            this.VersionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F);
            this.VersionLabel.Location = new System.Drawing.Point(1, 580);
            this.VersionLabel.Name = "VersionLabel";
            this.VersionLabel.Size = new System.Drawing.Size(38, 9);
            this.VersionLabel.TabIndex = 56;
            this.VersionLabel.Text = "vX.X.XXX";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.DefaultExt = "*.wav|*.wave|*.mp3";
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "WAVE File (*.wav)|*.wav|WAVE File (*.wave)|*.wave|Mp3 File (*.mp3)|*.mp3";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox3.Controls.Add(this.clearLog_button);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(13, 123);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(81, 53);
            this.groupBox3.TabIndex = 101;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "clearLog";
            // 
            // clearLog_button
            // 
            this.clearLog_button.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.clearLog_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearLog_button.Location = new System.Drawing.Point(7, 20);
            this.clearLog_button.Name = "clearLog_button";
            this.clearLog_button.Size = new System.Drawing.Size(68, 23);
            this.clearLog_button.TabIndex = 0;
            this.clearLog_button.Text = "cl&ear Log";
            this.clearLog_button.UseVisualStyleBackColor = true;
            this.clearLog_button.Click += new System.EventHandler(this.clearLog_button_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox4.Controls.Add(this.LogSaveCheck);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(13, 80);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(81, 44);
            this.groupBox4.TabIndex = 102;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "SaveLog";
            // 
            // LogSaveCheck
            // 
            this.LogSaveCheck.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.LogSaveCheck.AutoSize = true;
            this.LogSaveCheck.Checked = true;
            this.LogSaveCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.LogSaveCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogSaveCheck.Location = new System.Drawing.Point(19, 20);
            this.LogSaveCheck.Name = "LogSaveCheck";
            this.LogSaveCheck.Size = new System.Drawing.Size(49, 17);
            this.LogSaveCheck.TabIndex = 0;
            this.LogSaveCheck.Text = "save";
            this.LogSaveCheck.UseVisualStyleBackColor = true;
            // 
            // saveBackupButton
            // 
            this.saveBackupButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.saveBackupButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.saveBackupButton.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveBackupButton.Location = new System.Drawing.Point(135, 559);
            this.saveBackupButton.Name = "saveBackupButton";
            this.saveBackupButton.Size = new System.Drawing.Size(81, 27);
            this.saveBackupButton.TabIndex = 1;
            this.saveBackupButton.Text = "Save &backup";
            this.saveBackupButton.UseVisualStyleBackColor = true;
            this.saveBackupButton.Click += new System.EventHandler(this.saveBackUpButton_Click);
            // 
            // loadBackupButton
            // 
            this.loadBackupButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.loadBackupButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.loadBackupButton.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loadBackupButton.Location = new System.Drawing.Point(48, 559);
            this.loadBackupButton.Name = "loadBackupButton";
            this.loadBackupButton.Size = new System.Drawing.Size(81, 27);
            this.loadBackupButton.TabIndex = 0;
            this.loadBackupButton.Text = "&Load backup";
            this.loadBackupButton.UseVisualStyleBackColor = true;
            this.loadBackupButton.Click += new System.EventHandler(this.loadBackUpButton_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox5.Controls.Add(this.answerBGCheck);
            this.groupBox5.Controls.Add(this.answerWhisperCheck);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(233, 68);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(121, 56);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "AnswerChat";
            // 
            // answerBGCheck
            // 
            this.answerBGCheck.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.answerBGCheck.AutoSize = true;
            this.answerBGCheck.BackColor = System.Drawing.Color.Transparent;
            this.answerBGCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerBGCheck.Location = new System.Drawing.Point(13, 36);
            this.answerBGCheck.Name = "answerBGCheck";
            this.answerBGCheck.Size = new System.Drawing.Size(103, 17);
            this.answerBGCheck.TabIndex = 1;
            this.answerBGCheck.Text = "answer BG Chat";
            this.answerBGCheck.UseVisualStyleBackColor = false;
            // 
            // answerWhisperCheck
            // 
            this.answerWhisperCheck.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.answerWhisperCheck.AutoSize = true;
            this.answerWhisperCheck.Checked = true;
            this.answerWhisperCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.answerWhisperCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerWhisperCheck.Location = new System.Drawing.Point(13, 16);
            this.answerWhisperCheck.Name = "answerWhisperCheck";
            this.answerWhisperCheck.Size = new System.Drawing.Size(99, 17);
            this.answerWhisperCheck.TabIndex = 0;
            this.answerWhisperCheck.Text = "answer whisper";
            this.answerWhisperCheck.UseVisualStyleBackColor = true;
            // 
            // answerAfterSecMin
            // 
            this.answerAfterSecMin.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.answerAfterSecMin.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerAfterSecMin.Location = new System.Drawing.Point(20, 25);
            this.answerAfterSecMin.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.answerAfterSecMin.Name = "answerAfterSecMin";
            this.answerAfterSecMin.Size = new System.Drawing.Size(32, 20);
            this.answerAfterSecMin.TabIndex = 0;
            this.answerAfterSecMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.answerAfterSecMin.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.answerAfterSecMin.ValueChanged += new System.EventHandler(this.AnswerBetween_Change);
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox9.BackColor = System.Drawing.Color.Transparent;
            this.groupBox9.Controls.Add(this.label2);
            this.groupBox9.Controls.Add(this.answerAfterSecMax);
            this.groupBox9.Controls.Add(this.label1);
            this.groupBox9.Controls.Add(this.answerAfterSecMin);
            this.groupBox9.Controls.Add(this.label4);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(233, 125);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(122, 51);
            this.groupBox9.TabIndex = 105;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "AnswerBetween";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(53, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 24);
            this.label2.TabIndex = 5;
            this.label2.Text = "-";
            // 
            // answerAfterSecMax
            // 
            this.answerAfterSecMax.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.answerAfterSecMax.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerAfterSecMax.Location = new System.Drawing.Point(71, 25);
            this.answerAfterSecMax.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.answerAfterSecMax.Minimum = this.answerAfterSecMin.Value;
            this.answerAfterSecMax.Name = "answerAfterSecMax";
            this.answerAfterSecMax.Size = new System.Drawing.Size(32, 20);
            this.answerAfterSecMax.TabIndex = 3;
            this.answerAfterSecMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.answerAfterSecMax.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.answerAfterSecMax.ValueChanged += new System.EventHandler(this.AnswerBetween_Change);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(67, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "max sec";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(18, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 12);
            this.label4.TabIndex = 2;
            this.label4.Text = "min sec";
            // 
            // groupBox10
            // 
            this.groupBox10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox10.Controls.Add(this.softIgnoAfter);
            this.groupBox10.Controls.Add(this.ingameIgnoCheck);
            this.groupBox10.Controls.Add(this.ignoAfterX);
            this.groupBox10.Controls.Add(this.ignoNo);
            this.groupBox10.Controls.Add(this.ignoAll);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(364, 68);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(171, 108);
            this.groupBox10.TabIndex = 106;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "IgnorePlayer";
            // 
            // softIgnoAfter
            // 
            this.softIgnoAfter.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.softIgnoAfter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.softIgnoAfter.Location = new System.Drawing.Point(85, 42);
            this.softIgnoAfter.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.softIgnoAfter.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.softIgnoAfter.Name = "softIgnoAfter";
            this.softIgnoAfter.Size = new System.Drawing.Size(32, 20);
            this.softIgnoAfter.TabIndex = 115;
            this.softIgnoAfter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.softIgnoAfter.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // ingameIgnoCheck
            // 
            this.ingameIgnoCheck.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ingameIgnoCheck.AutoSize = true;
            this.ingameIgnoCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ingameIgnoCheck.Location = new System.Drawing.Point(10, 88);
            this.ingameIgnoCheck.Name = "ingameIgnoCheck";
            this.ingameIgnoCheck.Size = new System.Drawing.Size(93, 17);
            this.ingameIgnoCheck.TabIndex = 4;
            this.ingameIgnoCheck.Text = "ignore Ingame";
            this.ingameIgnoCheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ingameIgnoCheck.UseVisualStyleBackColor = true;
            // 
            // ignoAfterX
            // 
            this.ignoAfterX.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ignoAfterX.AutoSize = true;
            this.ignoAfterX.Checked = true;
            this.ignoAfterX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ignoAfterX.Location = new System.Drawing.Point(10, 42);
            this.ignoAfterX.Name = "ignoAfterX";
            this.ignoAfterX.Size = new System.Drawing.Size(157, 17);
            this.ignoAfterX.TabIndex = 2;
            this.ignoAfterX.TabStop = true;
            this.ignoAfterX.Text = "igniore after            whispers";
            this.ignoAfterX.UseVisualStyleBackColor = true;
            // 
            // ignoNo
            // 
            this.ignoNo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ignoNo.AutoSize = true;
            this.ignoNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ignoNo.Location = new System.Drawing.Point(10, 65);
            this.ignoNo.Name = "ignoNo";
            this.ignoNo.Size = new System.Drawing.Size(92, 17);
            this.ignoNo.TabIndex = 3;
            this.ignoNo.Text = "ignore nobody";
            this.ignoNo.UseVisualStyleBackColor = true;
            // 
            // ignoAll
            // 
            this.ignoAll.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.ignoAll.AutoSize = true;
            this.ignoAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ignoAll.Location = new System.Drawing.Point(10, 19);
            this.ignoAll.Name = "ignoAll";
            this.ignoAll.Size = new System.Drawing.Size(99, 17);
            this.ignoAll.TabIndex = 0;
            this.ignoAll.Text = "ignore all Player";
            this.ignoAll.UseVisualStyleBackColor = true;
            // 
            // saveButton
            // 
            this.saveButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.saveButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.saveButton.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveButton.Location = new System.Drawing.Point(402, 559);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(83, 27);
            this.saveButton.TabIndex = 107;
            this.saveButton.Text = "save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.closeWindow_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.cancelButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.cancelButton.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelButton.Location = new System.Drawing.Point(313, 559);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(83, 27);
            this.cancelButton.TabIndex = 108;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelWindow_Click);
            // 
            // tabControl
            // 
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl.Controls.Add(this.LogTab);
            this.tabControl.Controls.Add(this.answerTab);
            this.tabControl.Controls.Add(this.friendListTab);
            this.tabControl.Controls.Add(this.GMalertTab);
            this.tabControl.Location = new System.Drawing.Point(12, 228);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(522, 324);
            this.tabControl.TabIndex = 109;
            // 
            // LogTab
            // 
            this.LogTab.BackColor = System.Drawing.Color.Gainsboro;
            this.LogTab.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.LogTab.Controls.Add(this.tbLog);
            this.LogTab.Location = new System.Drawing.Point(4, 22);
            this.LogTab.Name = "LogTab";
            this.LogTab.Padding = new System.Windows.Forms.Padding(3);
            this.LogTab.Size = new System.Drawing.Size(514, 298);
            this.LogTab.TabIndex = 0;
            this.LogTab.Text = "  Log";
            // 
            // tbLog
            // 
            this.tbLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tbLog.BackColor = System.Drawing.Color.White;
            this.tbLog.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tbLog.Location = new System.Drawing.Point(0, 0);
            this.tbLog.Name = "tbLog";
            this.tbLog.ReadOnly = true;
            this.tbLog.Size = new System.Drawing.Size(514, 301);
            this.tbLog.TabIndex = 4;
            this.tbLog.Text = "";
            this.tbLog.WordWrap = false;
            // 
            // answerTab
            // 
            this.answerTab.BackColor = System.Drawing.Color.Gainsboro;
            this.answerTab.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.answerTab.Controls.Add(this.groupBox8);
            this.answerTab.Controls.Add(this.groupBox7);
            this.answerTab.Controls.Add(this.groupBox6);
            this.answerTab.Location = new System.Drawing.Point(4, 22);
            this.answerTab.Name = "answerTab";
            this.answerTab.Padding = new System.Windows.Forms.Padding(3);
            this.answerTab.Size = new System.Drawing.Size(514, 298);
            this.answerTab.TabIndex = 1;
            this.answerTab.Text = " Answers";
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox8.Controls.Add(this.answerContainBG);
            this.groupBox8.Controls.Add(this.label10);
            this.groupBox8.Controls.Add(this.answerText4);
            this.groupBox8.Controls.Add(this.answerText3);
            this.groupBox8.Controls.Add(this.answerText2);
            this.groupBox8.Controls.Add(this.answerText1);
            this.groupBox8.Controls.Add(this.label9);
            this.groupBox8.Controls.Add(this.label8);
            this.groupBox8.Controls.Add(this.label7);
            this.groupBox8.Controls.Add(this.containBox4);
            this.groupBox8.Controls.Add(this.containBox3);
            this.groupBox8.Controls.Add(this.containBox2);
            this.groupBox8.Controls.Add(this.label6);
            this.groupBox8.Controls.Add(this.label5);
            this.groupBox8.Controls.Add(this.containBox1);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(6, 144);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(502, 148);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Answers when whisper contain -           ";
            // 
            // answerContainBG
            // 
            this.answerContainBG.AutoSize = true;
            this.answerContainBG.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerContainBG.Location = new System.Drawing.Point(220, 1);
            this.answerContainBG.Name = "answerContainBG";
            this.answerContainBG.Size = new System.Drawing.Size(98, 17);
            this.answerContainBG.TabIndex = 14;
            this.answerContainBG.Text = "use in BGs, too";
            this.answerContainBG.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(267, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 15);
            this.label10.TabIndex = 13;
            this.label10.Text = "Answers:";
            // 
            // answerText4
            // 
            this.answerText4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.answerText4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerText4.Location = new System.Drawing.Point(103, 121);
            this.answerText4.Name = "answerText4";
            this.answerText4.Size = new System.Drawing.Size(393, 20);
            this.answerText4.TabIndex = 12;
            // 
            // answerText3
            // 
            this.answerText3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.answerText3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerText3.Location = new System.Drawing.Point(103, 95);
            this.answerText3.Name = "answerText3";
            this.answerText3.Size = new System.Drawing.Size(393, 20);
            this.answerText3.TabIndex = 11;
            // 
            // answerText2
            // 
            this.answerText2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.answerText2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerText2.Location = new System.Drawing.Point(103, 68);
            this.answerText2.Name = "answerText2";
            this.answerText2.Size = new System.Drawing.Size(393, 20);
            this.answerText2.TabIndex = 10;
            // 
            // answerText1
            // 
            this.answerText1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.answerText1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerText1.Location = new System.Drawing.Point(103, 41);
            this.answerText1.Name = "answerText1";
            this.answerText1.Size = new System.Drawing.Size(393, 20);
            this.answerText1.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(78, 126);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(19, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "-->";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(78, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "-->";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(78, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(19, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "-->";
            // 
            // containBox4
            // 
            this.containBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.containBox4.Location = new System.Drawing.Point(6, 121);
            this.containBox4.Name = "containBox4";
            this.containBox4.Size = new System.Drawing.Size(66, 20);
            this.containBox4.TabIndex = 5;
            // 
            // containBox3
            // 
            this.containBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.containBox3.Location = new System.Drawing.Point(6, 95);
            this.containBox3.Name = "containBox3";
            this.containBox3.Size = new System.Drawing.Size(66, 20);
            this.containBox3.TabIndex = 4;
            // 
            // containBox2
            // 
            this.containBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.containBox2.Location = new System.Drawing.Point(6, 68);
            this.containBox2.Name = "containBox2";
            this.containBox2.Size = new System.Drawing.Size(66, 20);
            this.containBox2.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(78, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(19, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "-->";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 15);
            this.label5.TabIndex = 1;
            this.label5.Text = "contain:";
            // 
            // containBox1
            // 
            this.containBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.containBox1.Location = new System.Drawing.Point(6, 41);
            this.containBox1.Name = "containBox1";
            this.containBox1.Size = new System.Drawing.Size(66, 20);
            this.containBox1.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox7.Controls.Add(this.rAnswerBG4);
            this.groupBox7.Controls.Add(this.rAnswerBG3);
            this.groupBox7.Controls.Add(this.rAnswerBG2);
            this.groupBox7.Controls.Add(this.rAnswerBG1);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(260, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(248, 132);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "RandomAnswer - BG Chat";
            // 
            // rAnswerBG4
            // 
            this.rAnswerBG4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rAnswerBG4.Location = new System.Drawing.Point(6, 101);
            this.rAnswerBG4.Name = "rAnswerBG4";
            this.rAnswerBG4.Size = new System.Drawing.Size(236, 20);
            this.rAnswerBG4.TabIndex = 3;
            // 
            // rAnswerBG3
            // 
            this.rAnswerBG3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rAnswerBG3.Location = new System.Drawing.Point(6, 74);
            this.rAnswerBG3.Name = "rAnswerBG3";
            this.rAnswerBG3.Size = new System.Drawing.Size(236, 20);
            this.rAnswerBG3.TabIndex = 2;
            // 
            // rAnswerBG2
            // 
            this.rAnswerBG2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rAnswerBG2.Location = new System.Drawing.Point(6, 47);
            this.rAnswerBG2.Name = "rAnswerBG2";
            this.rAnswerBG2.Size = new System.Drawing.Size(236, 20);
            this.rAnswerBG2.TabIndex = 1;
            // 
            // rAnswerBG1
            // 
            this.rAnswerBG1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rAnswerBG1.Location = new System.Drawing.Point(6, 20);
            this.rAnswerBG1.Name = "rAnswerBG1";
            this.rAnswerBG1.Size = new System.Drawing.Size(236, 20);
            this.rAnswerBG1.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox6.Controls.Add(this.rAnswerW4);
            this.groupBox6.Controls.Add(this.rAnswerW3);
            this.groupBox6.Controls.Add(this.rAnswerW2);
            this.groupBox6.Controls.Add(this.rAnswerW1);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(8, 6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(248, 132);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "RadomAnswer - Whisper";
            // 
            // rAnswerW4
            // 
            this.rAnswerW4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rAnswerW4.Location = new System.Drawing.Point(4, 103);
            this.rAnswerW4.Name = "rAnswerW4";
            this.rAnswerW4.Size = new System.Drawing.Size(238, 20);
            this.rAnswerW4.TabIndex = 3;
            // 
            // rAnswerW3
            // 
            this.rAnswerW3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rAnswerW3.Location = new System.Drawing.Point(4, 75);
            this.rAnswerW3.Name = "rAnswerW3";
            this.rAnswerW3.Size = new System.Drawing.Size(238, 20);
            this.rAnswerW3.TabIndex = 2;
            // 
            // rAnswerW2
            // 
            this.rAnswerW2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rAnswerW2.Location = new System.Drawing.Point(6, 47);
            this.rAnswerW2.Name = "rAnswerW2";
            this.rAnswerW2.Size = new System.Drawing.Size(236, 20);
            this.rAnswerW2.TabIndex = 1;
            // 
            // rAnswerW1
            // 
            this.rAnswerW1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rAnswerW1.Location = new System.Drawing.Point(6, 20);
            this.rAnswerW1.Name = "rAnswerW1";
            this.rAnswerW1.Size = new System.Drawing.Size(236, 20);
            this.rAnswerW1.TabIndex = 0;
            // 
            // friendListTab
            // 
            this.friendListTab.BackColor = System.Drawing.Color.Gainsboro;
            this.friendListTab.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.friendListTab.Controls.Add(this.groupBox14);
            this.friendListTab.Controls.Add(this.groupBox12);
            this.friendListTab.Controls.Add(this.guildOfficersCheck);
            this.friendListTab.Controls.Add(this.guildMasterCheck);
            this.friendListTab.Controls.Add(this.guildOfficersList);
            this.friendListTab.Controls.Add(this.guildMaster);
            this.friendListTab.Controls.Add(this.label12);
            this.friendListTab.Controls.Add(this.groupBox13);
            this.friendListTab.Controls.Add(this.inGameFriendsCheck);
            this.friendListTab.Controls.Add(this.guildMembersCheck);
            this.friendListTab.Controls.Add(this.FriendList1Check);
            this.friendListTab.Controls.Add(this.inGameFriendList);
            this.friendListTab.Controls.Add(this.guildMembersList);
            this.friendListTab.Controls.Add(this.friendList1);
            this.friendListTab.Location = new System.Drawing.Point(4, 22);
            this.friendListTab.Name = "friendListTab";
            this.friendListTab.Size = new System.Drawing.Size(514, 298);
            this.friendListTab.TabIndex = 2;
            this.friendListTab.Text = "Guild & Friend   ";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.answerFriendsCheck);
            this.groupBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox14.Location = new System.Drawing.Point(329, 119);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(118, 45);
            this.groupBox14.TabIndex = 113;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "AnswerChat";
            // 
            // answerFriendsCheck
            // 
            this.answerFriendsCheck.AutoSize = true;
            this.answerFriendsCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerFriendsCheck.Location = new System.Drawing.Point(11, 20);
            this.answerFriendsCheck.Name = "answerFriendsCheck";
            this.answerFriendsCheck.Size = new System.Drawing.Size(99, 17);
            this.answerFriendsCheck.TabIndex = 111;
            this.answerFriendsCheck.Text = "answer whisper";
            this.answerFriendsCheck.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label15);
            this.groupBox12.Controls.Add(this.softIgnoFriendsCheck);
            this.groupBox12.Controls.Add(this.softIgnoFriendsAfter);
            this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.Location = new System.Drawing.Point(329, 70);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(169, 44);
            this.groupBox12.TabIndex = 112;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "(soft) ignore";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(118, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 13);
            this.label15.TabIndex = 116;
            this.label15.Text = "whispers";
            // 
            // softIgnoFriendsCheck
            // 
            this.softIgnoFriendsCheck.AutoSize = true;
            this.softIgnoFriendsCheck.Checked = true;
            this.softIgnoFriendsCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.softIgnoFriendsCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.softIgnoFriendsCheck.Location = new System.Drawing.Point(7, 20);
            this.softIgnoFriendsCheck.Name = "softIgnoFriendsCheck";
            this.softIgnoFriendsCheck.Size = new System.Drawing.Size(79, 17);
            this.softIgnoFriendsCheck.TabIndex = 112;
            this.softIgnoFriendsCheck.Text = "ignore after";
            this.softIgnoFriendsCheck.UseVisualStyleBackColor = true;
            // 
            // softIgnoFriendsAfter
            // 
            this.softIgnoFriendsAfter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.softIgnoFriendsAfter.Location = new System.Drawing.Point(86, 19);
            this.softIgnoFriendsAfter.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.softIgnoFriendsAfter.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.softIgnoFriendsAfter.Name = "softIgnoFriendsAfter";
            this.softIgnoFriendsAfter.Size = new System.Drawing.Size(32, 20);
            this.softIgnoFriendsAfter.TabIndex = 113;
            this.softIgnoFriendsAfter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.softIgnoFriendsAfter.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // guildOfficersCheck
            // 
            this.guildOfficersCheck.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guildOfficersCheck.AutoSize = true;
            this.guildOfficersCheck.BackColor = System.Drawing.Color.Transparent;
            this.guildOfficersCheck.Location = new System.Drawing.Point(225, 228);
            this.guildOfficersCheck.Name = "guildOfficersCheck";
            this.guildOfficersCheck.Size = new System.Drawing.Size(106, 17);
            this.guildOfficersCheck.TabIndex = 111;
            this.guildOfficersCheck.Text = "Officers  (Rank2)";
            this.guildOfficersCheck.UseVisualStyleBackColor = false;
            // 
            // guildMasterCheck
            // 
            this.guildMasterCheck.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guildMasterCheck.AutoSize = true;
            this.guildMasterCheck.BackColor = System.Drawing.Color.Transparent;
            this.guildMasterCheck.Location = new System.Drawing.Point(225, 187);
            this.guildMasterCheck.Name = "guildMasterCheck";
            this.guildMasterCheck.Size = new System.Drawing.Size(85, 17);
            this.guildMasterCheck.TabIndex = 110;
            this.guildMasterCheck.Text = "Guild Master";
            this.guildMasterCheck.UseVisualStyleBackColor = false;
            // 
            // guildOfficersList
            // 
            this.guildOfficersList.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guildOfficersList.Location = new System.Drawing.Point(222, 245);
            this.guildOfficersList.Name = "guildOfficersList";
            this.guildOfficersList.ReadOnly = true;
            this.guildOfficersList.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.guildOfficersList.Size = new System.Drawing.Size(100, 48);
            this.guildOfficersList.TabIndex = 109;
            this.guildOfficersList.Text = "";
            // 
            // guildMaster
            // 
            this.guildMaster.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guildMaster.Location = new System.Drawing.Point(222, 204);
            this.guildMaster.Name = "guildMaster";
            this.guildMaster.ReadOnly = true;
            this.guildMaster.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.guildMaster.Size = new System.Drawing.Size(100, 21);
            this.guildMaster.TabIndex = 108;
            this.guildMaster.Text = "";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(5, 266);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 26);
            this.label12.TabIndex = 107;
            this.label12.Text = "Add one Friend per line!";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox13
            // 
            this.groupBox13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox13.Controls.Add(this.comboBox2);
            this.groupBox13.Controls.Add(this.SoundByFriendCheck);
            this.groupBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox13.Location = new System.Drawing.Point(329, 16);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(182, 49);
            this.groupBox13.TabIndex = 13;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Sound";
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "bing sound",
            "MySoundFile",
            "beep.wav",
            "boing.wav",
            "canwedo.wav",
            "elephant.wav",
            "himan.wav",
            "murloc.wav",
            "scream.wav",
            "siren1.wav",
            "snore.wav",
            "youagain.wav"});
            this.comboBox2.Location = new System.Drawing.Point(80, 19);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(94, 21);
            this.comboBox2.TabIndex = 110;
            this.comboBox2.Text = "select a sound";
            // 
            // SoundByFriendCheck
            // 
            this.SoundByFriendCheck.AutoSize = true;
            this.SoundByFriendCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SoundByFriendCheck.Location = new System.Drawing.Point(6, 22);
            this.SoundByFriendCheck.Name = "SoundByFriendCheck";
            this.SoundByFriendCheck.Size = new System.Drawing.Size(77, 17);
            this.SoundByFriendCheck.TabIndex = 11;
            this.SoundByFriendCheck.Text = "PlaySound";
            this.SoundByFriendCheck.UseVisualStyleBackColor = true;
            // 
            // inGameFriendsCheck
            // 
            this.inGameFriendsCheck.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.inGameFriendsCheck.AutoSize = true;
            this.inGameFriendsCheck.BackColor = System.Drawing.Color.Transparent;
            this.inGameFriendsCheck.Checked = true;
            this.inGameFriendsCheck.CheckState = System.Windows.Forms.CheckState.Checked;
            this.inGameFriendsCheck.Location = new System.Drawing.Point(113, 5);
            this.inGameFriendsCheck.Name = "inGameFriendsCheck";
            this.inGameFriendsCheck.Size = new System.Drawing.Size(106, 17);
            this.inGameFriendsCheck.TabIndex = 7;
            this.inGameFriendsCheck.Text = "inGame Friendlist";
            this.inGameFriendsCheck.UseVisualStyleBackColor = false;
            // 
            // guildMembersCheck
            // 
            this.guildMembersCheck.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guildMembersCheck.AutoSize = true;
            this.guildMembersCheck.BackColor = System.Drawing.Color.Transparent;
            this.guildMembersCheck.Location = new System.Drawing.Point(226, 5);
            this.guildMembersCheck.Name = "guildMembersCheck";
            this.guildMembersCheck.Size = new System.Drawing.Size(96, 17);
            this.guildMembersCheck.TabIndex = 6;
            this.guildMembersCheck.Text = "Guild Members";
            this.guildMembersCheck.UseVisualStyleBackColor = false;
            this.guildMembersCheck.Click += new System.EventHandler(this.guildMembersCheck_Click);
            // 
            // FriendList1Check
            // 
            this.FriendList1Check.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.FriendList1Check.AutoSize = true;
            this.FriendList1Check.BackColor = System.Drawing.Color.Transparent;
            this.FriendList1Check.Location = new System.Drawing.Point(20, 5);
            this.FriendList1Check.Name = "FriendList1Check";
            this.FriendList1Check.Size = new System.Drawing.Size(76, 17);
            this.FriendList1Check.TabIndex = 5;
            this.FriendList1Check.Text = "FriendsList";
            this.FriendList1Check.UseVisualStyleBackColor = false;
            // 
            // inGameFriendList
            // 
            this.inGameFriendList.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.inGameFriendList.Location = new System.Drawing.Point(113, 22);
            this.inGameFriendList.Name = "inGameFriendList";
            this.inGameFriendList.ReadOnly = true;
            this.inGameFriendList.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.inGameFriendList.Size = new System.Drawing.Size(100, 271);
            this.inGameFriendList.TabIndex = 4;
            this.inGameFriendList.Text = "";
            // 
            // guildMembersList
            // 
            this.guildMembersList.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.guildMembersList.Location = new System.Drawing.Point(222, 22);
            this.guildMembersList.Name = "guildMembersList";
            this.guildMembersList.ReadOnly = true;
            this.guildMembersList.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.guildMembersList.Size = new System.Drawing.Size(100, 163);
            this.guildMembersList.TabIndex = 3;
            this.guildMembersList.Text = "";
            // 
            // friendList1
            // 
            this.friendList1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.friendList1.Location = new System.Drawing.Point(5, 22);
            this.friendList1.Name = "friendList1";
            this.friendList1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.friendList1.Size = new System.Drawing.Size(100, 241);
            this.friendList1.TabIndex = 2;
            this.friendList1.Text = "";
            // 
            // GMalertTab
            // 
            this.GMalertTab.BackColor = System.Drawing.Color.Gainsboro;
            this.GMalertTab.Controls.Add(this.groupBox16);
            this.GMalertTab.Controls.Add(this.groupBox15);
            this.GMalertTab.Location = new System.Drawing.Point(4, 22);
            this.GMalertTab.Name = "GMalertTab";
            this.GMalertTab.Size = new System.Drawing.Size(514, 298);
            this.GMalertTab.TabIndex = 3;
            this.GMalertTab.Text = "GM Alert";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.label17);
            this.groupBox16.Controls.Add(this.logoutNearByGMCheck);
            this.groupBox16.Controls.Add(this.soundNearByGMCheck);
            this.groupBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox16.Location = new System.Drawing.Point(16, 16);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(241, 82);
            this.groupBox16.TabIndex = 1;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "NearByAlert";
            // 
            // label17
            // 
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 49);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(229, 21);
            this.label17.TabIndex = 5;
            this.label17.Text = "Alerts you when a GM is near you!";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // logoutNearByGMCheck
            // 
            this.logoutNearByGMCheck.AutoSize = true;
            this.logoutNearByGMCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutNearByGMCheck.Location = new System.Drawing.Point(119, 20);
            this.logoutNearByGMCheck.Name = "logoutNearByGMCheck";
            this.logoutNearByGMCheck.Size = new System.Drawing.Size(59, 17);
            this.logoutNearByGMCheck.TabIndex = 4;
            this.logoutNearByGMCheck.Text = "Logout";
            this.logoutNearByGMCheck.UseVisualStyleBackColor = true;
            // 
            // soundNearByGMCheck
            // 
            this.soundNearByGMCheck.AutoSize = true;
            this.soundNearByGMCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.soundNearByGMCheck.Location = new System.Drawing.Point(15, 20);
            this.soundNearByGMCheck.Name = "soundNearByGMCheck";
            this.soundNearByGMCheck.Size = new System.Drawing.Size(77, 17);
            this.soundNearByGMCheck.TabIndex = 3;
            this.soundNearByGMCheck.Text = "PlaySound";
            this.soundNearByGMCheck.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.label16);
            this.groupBox15.Controls.Add(this.answerGMtext);
            this.groupBox15.Controls.Add(this.logoutByGMwhisperCheck);
            this.groupBox15.Controls.Add(this.answerGMwhisperCheck);
            this.groupBox15.Controls.Add(this.soundByGMwhisperCheck);
            this.groupBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox15.Location = new System.Drawing.Point(16, 116);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(481, 102);
            this.groupBox15.TabIndex = 0;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "WhisperAlert";
            this.groupBox15.Visible = false;
            // 
            // label16
            // 
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(275, 23);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(166, 32);
            this.label16.TabIndex = 3;
            this.label16.Text = "Alerts you when a GM whispers you!\r\n";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // answerGMtext
            // 
            this.answerGMtext.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerGMtext.Location = new System.Drawing.Point(15, 70);
            this.answerGMtext.Name = "answerGMtext";
            this.answerGMtext.Size = new System.Drawing.Size(453, 20);
            this.answerGMtext.TabIndex = 0;
            // 
            // logoutByGMwhisperCheck
            // 
            this.logoutByGMwhisperCheck.AutoSize = true;
            this.logoutByGMwhisperCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutByGMwhisperCheck.Location = new System.Drawing.Point(119, 20);
            this.logoutByGMwhisperCheck.Name = "logoutByGMwhisperCheck";
            this.logoutByGMwhisperCheck.Size = new System.Drawing.Size(59, 17);
            this.logoutByGMwhisperCheck.TabIndex = 2;
            this.logoutByGMwhisperCheck.Text = "Logout";
            this.logoutByGMwhisperCheck.UseVisualStyleBackColor = true;
            // 
            // answerGMwhisperCheck
            // 
            this.answerGMwhisperCheck.AutoSize = true;
            this.answerGMwhisperCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.answerGMwhisperCheck.Location = new System.Drawing.Point(15, 45);
            this.answerGMwhisperCheck.Name = "answerGMwhisperCheck";
            this.answerGMwhisperCheck.Size = new System.Drawing.Size(85, 17);
            this.answerGMwhisperCheck.TabIndex = 1;
            this.answerGMwhisperCheck.Text = "answer with:";
            this.answerGMwhisperCheck.UseVisualStyleBackColor = true;
            // 
            // soundByGMwhisperCheck
            // 
            this.soundByGMwhisperCheck.AutoSize = true;
            this.soundByGMwhisperCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.soundByGMwhisperCheck.Location = new System.Drawing.Point(15, 20);
            this.soundByGMwhisperCheck.Name = "soundByGMwhisperCheck";
            this.soundByGMwhisperCheck.Size = new System.Drawing.Size(77, 17);
            this.soundByGMwhisperCheck.TabIndex = 0;
            this.soundByGMwhisperCheck.Text = "PlaySound";
            this.soundByGMwhisperCheck.UseVisualStyleBackColor = true;
            // 
            // RevisingLabel
            // 
            this.RevisingLabel.AutoSize = true;
            this.RevisingLabel.Font = new System.Drawing.Font("Comic Sans MS", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RevisingLabel.Location = new System.Drawing.Point(168, 122);
            this.RevisingLabel.Name = "RevisingLabel";
            this.RevisingLabel.Size = new System.Drawing.Size(177, 45);
            this.RevisingLabel.TabIndex = 108;
            this.RevisingLabel.Text = "in revising";
            // 
            // groupBox11
            // 
            this.groupBox11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox11.Controls.Add(this.label13);
            this.groupBox11.Controls.Add(this.label11);
            this.groupBox11.Controls.Add(this.label3);
            this.groupBox11.Controls.Add(this.soundLoopEvery);
            this.groupBox11.Controls.Add(this.soundLoop);
            this.groupBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.Location = new System.Drawing.Point(105, 125);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(116, 51);
            this.groupBox11.TabIndex = 110;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "SoundLoop";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 12);
            this.label13.TabIndex = 118;
            this.label13.Text = "how many";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(80, 14);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 12);
            this.label11.TabIndex = 6;
            this.label11.Text = "sec";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(42, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 102;
            this.label3.Text = "every";
            // 
            // soundLoopEvery
            // 
            this.soundLoopEvery.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.soundLoopEvery.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.soundLoopEvery.Location = new System.Drawing.Point(75, 26);
            this.soundLoopEvery.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.soundLoopEvery.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.soundLoopEvery.Name = "soundLoopEvery";
            this.soundLoopEvery.Size = new System.Drawing.Size(32, 20);
            this.soundLoopEvery.TabIndex = 117;
            this.soundLoopEvery.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.soundLoopEvery.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            // 
            // soundLoop
            // 
            this.soundLoop.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.soundLoop.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.soundLoop.Location = new System.Drawing.Point(9, 26);
            this.soundLoop.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.soundLoop.Name = "soundLoop";
            this.soundLoop.Size = new System.Drawing.Size(32, 20);
            this.soundLoop.TabIndex = 116;
            this.soundLoop.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.soundLoop.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(484, 46);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 21);
            this.label14.TabIndex = 111;
            this.label14.Text = "Beta";
            this.label14.Visible = false;
            // 
            // Form_ShutUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(546, 589);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.loadBackupButton);
            this.Controls.Add(this.saveBackupButton);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.BarryD);
            this.Controls.Add(this.VersionLabel);
            this.Controls.Add(this.labelx);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Titel);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(562, 620);
            this.Name = "Form_ShutUp";
            this.ShowIcon = false;
            this.Text = "[ShutUp] - settings";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_ShutUp_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_ShutUp_FormClosed);
            this.Load += new System.EventHandler(this.Form_ShutUp_Load);
            this.Shown += new System.EventHandler(this.Form_ShutUp_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.BarryD)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.answerAfterSecMin)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.answerAfterSecMax)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.softIgnoAfter)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.LogTab.ResumeLayout(false);
            this.answerTab.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.friendListTab.ResumeLayout(false);
            this.friendListTab.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.softIgnoFriendsAfter)).EndInit();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.GMalertTab.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.soundLoopEvery)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soundLoop)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox BarryD;
        private System.Windows.Forms.Label Titel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox WaveLocation;
        private System.Windows.Forms.Label labelx;
        private System.Windows.Forms.Label VersionLabel;
        private Button Openbutton;
        private OpenFileDialog openFileDialog1;
        private GroupBox groupBox3;
        private Button clearLog_button;
        private GroupBox groupBox4;
        private CheckBox LogSaveCheck;
        private GroupBox groupBox5;
        private CheckBox answerBGCheck;
        private NumericUpDown answerAfterSecMin;
        private CheckBox answerWhisperCheck;
        private GroupBox groupBox9;
        private GroupBox groupBox10;
        private RadioButton ignoAfterX;
        private RadioButton ignoNo;
        private RadioButton ignoAll;
        private ComboBox comboBox1;
        private Button soundTestButton;
        private CheckBox soundOnCheck;
        private Label label2;
        private NumericUpDown answerAfterSecMax;
        private Label label1;
        private Label label4;
        private Button saveBackupButton;
        private Button loadBackupButton;
        private Button saveButton;
        private Button cancelButton;
        private TabControl tabControl;
        private TabPage LogTab;
        private RichTextBox tbLog;
        public TabPage answerTab;
        private GroupBox groupBox8;
        private CheckBox answerContainBG;
        private Label label10;
        private TextBox answerText4;
        private TextBox answerText3;
        private TextBox answerText2;
        private TextBox answerText1;
        private Label label9;
        private Label label8;
        private Label label7;
        private TextBox containBox4;
        private TextBox containBox3;
        private TextBox containBox2;
        private Label label6;
        private Label label5;
        private TextBox containBox1;
        private GroupBox groupBox7;
        private TextBox rAnswerBG4;
        private TextBox rAnswerBG3;
        private TextBox rAnswerBG2;
        private TextBox rAnswerBG1;
        private GroupBox groupBox6;
        private TextBox rAnswerW4;
        private TextBox rAnswerW3;
        private TextBox rAnswerW2;
        private TextBox rAnswerW1;
        private TabPage friendListTab;
        private Label label12;
        private GroupBox groupBox13;
        private CheckBox SoundByFriendCheck;
        private CheckBox inGameFriendsCheck;
        private CheckBox guildMembersCheck;
        private CheckBox FriendList1Check;
        private RichTextBox inGameFriendList;
        private RichTextBox guildMembersList;
        private RichTextBox friendList1;
        private Label RevisingLabel;
        private NumericUpDown softIgnoFriendsAfter;
        private CheckBox softIgnoFriendsCheck;
        private CheckBox answerFriendsCheck;
        private ComboBox comboBox2;
        private NumericUpDown softIgnoAfter;
        private CheckBox ingameIgnoCheck;
        private GroupBox groupBox11;
        private Label label11;
        private Label label3;
        private NumericUpDown soundLoopEvery;
        private NumericUpDown soundLoop;
        private Label label13;
        private CheckBox UseExternalPlayerCheck;
        private Label label14;
        private CheckBox guildOfficersCheck;
        private CheckBox guildMasterCheck;
        private RichTextBox guildOfficersList;
        private RichTextBox guildMaster;
        private GroupBox groupBox14;
        private GroupBox groupBox12;
        private Label label15;
        private TabPage GMalertTab;
        private GroupBox groupBox16;
        private CheckBox logoutNearByGMCheck;
        private CheckBox soundNearByGMCheck;
        private GroupBox groupBox15;
        private TextBox answerGMtext;
        private CheckBox logoutByGMwhisperCheck;
        private CheckBox answerGMwhisperCheck;
        private CheckBox soundByGMwhisperCheck;
        private Label label17;
        private Label label16;


    }
}