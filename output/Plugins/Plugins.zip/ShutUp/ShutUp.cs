﻿using System;
using Styx;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Pathing;
using Styx.Logic.AreaManagement;
using Styx.Logic.BehaviorTree;
using Styx.Logic.Profiles;
//using Styx.Logic.Combat;
//using Styx.Combat.CombatRoutine;
using Styx.Plugins;
using Styx.Plugins.PluginClass;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.Misc;
using Styx.WoWInternals.World;
//using Styx.Logic.Inventory;
//using Styx.Logic.Inventory.Frames.Gossip;
//using Styx.Logic.Inventory.Frames.Quest;
//using Styx.Logic.Inventory.Frames.LootFrame;
using System.Collections.Generic;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Xml.Linq;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Forms;
using System.Drawing;
using System.Text;
using System.ComponentModel;
using System.Media;
//using Microsoft.Aspnet.Snapin;

namespace ShutUp
{
    public class ShutUp : HBPlugin
    {
        #region Nothing to see here!
        bool hasItBeenInitialized = false;
        string myFileLocation = string.Empty;
        private int Rnd;
        private int lastInt;
        private int loop = 0;
        private int lastIntBG;
        private string loopSound;
        private string lastMessage;
        private string lastBgMessage;
        private static string lastAuthor;
        private static string message = string.Empty;
        private static sbyte igno;
        private bool GMsound = false;

        public override string Author { get { return "BarryDurex"; } }
        public override Version Version { get { return new Version(1, 8, 101); } }
        public override string Name { get { return "[ShutUp]"; } }
        public override string ButtonText { get { return "Settings"; } }
        public override bool WantButton { get { return true; } }

        StreamWriter writer;
        Random random = new Random();
        private static BotEvents.OnBotStopDelegate _stopBot;
        private static Stopwatch check = new Stopwatch();
        private static Stopwatch InitializeCheck = new Stopwatch();
        private static Stopwatch loopTimer = new Stopwatch();
        private static LocalPlayer Me { get { return ObjectManager.Me; } }
        private string ShutUpLogLocation = (Logging.ApplicationPath + "\\Plugins\\ShutUp\\Logs\\ShutUp_Log_" + ObjectManager.Me.Name + ".txt");
        //static private Styx.Plugins.PluginContainer myPlugin;

        public void slog(string format, params object[] args)
        { Logging.Write(System.Drawing.Color.Blue, "[ShutUp]:" + format, args); }

        public void dlog(string format, params object[] args)
        {
            Logging.WriteDebug(System.Drawing.Color.Red, "################# [ShutUp Error] #################");
            Logging.WriteDebug(System.Drawing.Color.Red, "[Error]:" + format, args);
            Logging.WriteDebug(System.Drawing.Color.Red, "################# [ShutUp Error] #################");
            System.Media.SystemSounds.Asterisk.Play();
        }

        #region on button press
        public override void OnButtonPress()
        {
            var _configForm = new Form_ShutUp();
            _configForm.ShowDialog();
        }
        #endregion
        #endregion

        public void Initialize()
        {
            WoWChat.Whisper += newWhisper;
            WoWChat.Battleground += newBattlegroundTalk;
            BotEvents.OnBotStop += stopBot;
        }

        private void stopBot(EventArgs args)
        {
            WoWChat.Whisper -= newWhisper;
            WoWChat.Battleground -= newBattlegroundTalk;
            BotEvents.OnBotStop -= stopBot;
            IgnoreManager.players.Clear();
            hasItBeenInitialized = false;
            loopTimer.Stop();
            loop = 0;
            GMsound = false;
            //slog("STOP BOT");
        }


        public override void Pulse()
        {
            #region Initialize
            if (!hasItBeenInitialized)
            {
                if (!InitializeCheck.IsRunning)
                {
                    InitializeCheck.Start();
                }
                else if (InitializeCheck.IsRunning && InitializeCheck.ElapsedMilliseconds > 7000) // we have to wait a few seconds! |-> private void stopBot(EventArgs args) 
                {
                    if (!File.Exists(ShutUpLogLocation))
                    {
                        try
                        {
                            File.Create(ShutUpLogLocation);
                        }
                        catch (Exception ex)
                        {
                            dlog("#1 : can not creat logfile");
                            dlog("#1 : {0}", ex);
                        }
                    }

                    InitializeCheck.Stop();
                    InitializeCheck.Reset();

                    hasItBeenInitialized = true;
                    Initialize();
                    Logging.Write(System.Drawing.Color.Green, "[ShutUp] has been Initialized. Ready for whisper! ;-)");
                }
                else
                {
                    long time = (7000 - InitializeCheck.ElapsedMilliseconds) / 1000;
                    if (time >= 0 && time <= 2)
                    Logging.Write(System.Drawing.Color.Green, "[ShutUp] start in {0}sec!", ++time);
                }
            }
            #endregion

            #region sound loop
            if (!GMsound && loopTimer.IsRunning && loopTimer.ElapsedMilliseconds > (ShutUpSettings.Instance.SoundLoopEvery * 1000) && loop < ShutUpSettings.Instance.SoundLoop)
            {
                loopTimer.Reset(); loopTimer.Start();
                ++loop;
                PlaySound(loopSound);

                if (loop == ShutUpSettings.Instance.SoundLoop) { loop = 0; loopTimer.Stop(); }
            }
            #endregion

            GMcheck();
        }

        #region got a Whisper
        public void newWhisper(WoWChat.ChatWhisperEventArgs arg)
        {
            bool _isGM = Lua.GetReturnVal<bool>("if(_G.GMChatFrame_IsGM and _G.GMChatFrame_IsGM("+ arg.Author + ")) then return true; else return false; end", 0); // from WIM Addon; WIM.lua Z:449

            if (arg.Author != ObjectManager.Me.Name && arg.Message != lastMessage && CharacterSettings.Instance.EnabledPlugins.Contains("[ShutUp]"))
            {
                if (_isGM && (ShutUpSettings.Instance.GMwhisperSound || ShutUpSettings.Instance.logoutByGMwhisper || ShutUpSettings.Instance.answerGM))
                {
                    if (ShutUpSettings.Instance.GMwhisperSound)
                    {
                        GMsound = true;
                        GMalert("We have received a message from a GM!");
                    }

                    if (ShutUpSettings.Instance.saveLog) writeToLogFile(DateTime.Now.ToShortTimeString() + " - GM - " + arg.Author + " : " + arg.Message);

                    if (ShutUpSettings.Instance.answerGM)
                    {
                        string GMmessage = ShutUpGlobalSettings.Instance.answerGMwhisper;
                        Lua.DoString(string.Format("SendChatMessage(\"{0}\", 'WHISPER', nil, '{1}')", GMmessage, arg.Author));
                    }

                    if (ShutUpSettings.Instance.logoutByGMwhisper)
                    {
                        Thread.Sleep(3000);
                        exitWoW();
                    }
                }
                else
                {
                    lastMessage = arg.Message;
                    slog("you got a whisper from: {0} - {1}", arg.Author, arg.Message);

                    bool igno = false;
                    bool newIgno = false;

                    if (useFriendList1(arg.Author) || useGuildMaster(arg.Author) || useGuildOffiList(arg.Author) ||     // is a friend?
                        useGuildMembersList(arg.Author) || useInGameFriendsList(arg.Author))                            //
                    {
                        slog("{0} is a Friend or GuildMember!", arg.Author);

                        if (ShutUpSettings.Instance.softIgnoFriend)
                        {
                            if (IgnoreManager.onListOrAdd(arg.Author))
                            {
                                if (IgnoreManager.Igno(arg.Author, ShutUpSettings.Instance.softIgnoFrAfter))
                                {
                                    igno = true;
                                    slog("(soft) ignore: {0}", arg.Author);
                                }
                            }
                        }

                        if (ShutUpSettings.Instance.SoundByFriend && !igno) // play sound?
                        {
                            PlaySound(ShutUpSettings.Instance.selectedFriendSound);
                        }

                        if (ShutUpSettings.Instance.saveLog) // save Msg in Log?
                        {
                            #region save in log
                            string guilMasterRank = Lua.GetReturnVal<string>("return GuildControlGetRankName(1);", 0);
                            string gulidOffiRank = Lua.GetReturnVal<string>("return GuildControlGetRankName(2);", 0);

                            if (!igno)
                            {
                                if (useFriendList1(arg.Author) || useInGameFriendsList(arg.Author))
                                    writeToLogFile(DateTime.Now.ToShortTimeString() + " - FRIEND - " + arg.Author + " : " + arg.Message);

                                if (useGuildMaster(arg.Author))
                                    writeToLogFile(DateTime.Now.ToShortTimeString() + " - " + guilMasterRank + " - " + arg.Author + " : " + arg.Message);

                                if (useGuildOffiList(arg.Author))
                                    writeToLogFile(DateTime.Now.ToShortTimeString() + " - " + gulidOffiRank + " - " + arg.Author + " : " + arg.Message);

                                if (useGuildMembersList(arg.Author))
                                    writeToLogFile(DateTime.Now.ToShortTimeString() + " - GUILD MEMBER - " + arg.Author + " : " + arg.Message);
                            }
                            else if (igno)
                            {
                                if (useFriendList1(arg.Author) || useInGameFriendsList(arg.Author))
                                    writeToLogFile(DateTime.Now.ToShortTimeString() + " - FRIEND (soft igno) - " + arg.Author + " : " + arg.Message);

                                if (useGuildMaster(arg.Author))
                                    writeToLogFile(DateTime.Now.ToShortTimeString() + " - " + guilMasterRank + " (soft igno) - " + arg.Author + " : " + arg.Message);

                                if (useGuildOffiList(arg.Author))
                                    writeToLogFile(DateTime.Now.ToShortTimeString() + " - " + gulidOffiRank + " (soft igno) - " + arg.Author + " : " + arg.Message);

                                if (useGuildMembersList(arg.Author))
                                    writeToLogFile(DateTime.Now.ToShortTimeString() + " - GUILD MEMBER (soft igno) - " + arg.Author + " : " + arg.Message);
                            }
                        }
                            #endregion

                        if (ShutUpSettings.Instance.answerFriend && !igno)
                        {
                            AnswerSearch(arg.Author, arg.Message);// search answer
                        }
                    }
                    else        // is no friend
                    {
                        if (ShutUpSettings.Instance.ignoXW || ShutUpSettings.Instance.ignoAll)
                        {
                            if (ShutUpSettings.Instance.ignoXW)
                            {
                                if (IgnoreManager.onListOrAdd(arg.Author))
                                {
                                    if (IgnoreManager.Igno(arg.Author, ShutUpSettings.Instance.softIgnoAfter))
                                    {
                                        igno = true;
                                        if (ShutUpSettings.Instance.ingameIgno) { IgnorePlayer(arg.Author, arg.Message); }
                                        else { slog("(soft) ignore: {0}", arg.Author); }
                                    }
                                }

                            }
                            else if (ShutUpSettings.Instance.ignoAll)
                            {
                                if (!IgnoreManager.onListOrAdd(arg.Author)) { newIgno = true; }
                                if (ShutUpSettings.Instance.ingameIgno) { IgnorePlayer(arg.Author, arg.Message); }
                                else { slog("(soft) ignore: {0}", arg.Author); }
                                igno = true;
                            }
                        }

                        if (ShutUpSettings.Instance.SoundOn && (!igno || newIgno)) // play sound?
                        {
                            PlaySound(ShutUpSettings.Instance.selectedSound);
                        }

                        if (ShutUpSettings.Instance.saveLog) // save Msg in Log?
                        {
                            if (!igno)
                            {
                                writeToLogFile(DateTime.Now.ToShortTimeString() + " - WHISPER - " + arg.Author + " : " + arg.Message);
                            }
                            else if (igno && !ShutUpSettings.Instance.ingameIgno)
                            {
                                writeToLogFile(DateTime.Now.ToShortTimeString() + " - WHISPER (soft igno) - " + arg.Author + " : " + arg.Message);
                            }
                        }

                        if (ShutUpSettings.Instance.answerWisper && !igno) // answer whisper?
                        {
                            AnswerSearch(arg.Author, arg.Message); // search answer
                        }
                    }
                }
            }            
        }
        #endregion


        #region search answer
        public void AnswerSearch(string Author, string Message)
        {
            int answerAfter = random.Next(ShutUpSettings.Instance.answerBetweenMin, ShutUpSettings.Instance.answerBetweenMax);
            Rnd = random.Next(1, 8);

            AnswerWhisper(Rnd); // search rnd answer

            if (ShutUpGlobalSettings.Instance.contain1 != string.Empty && ShutUpGlobalSettings.Instance.answerContain1 != string.Empty && Message.Contains(ShutUpGlobalSettings.Instance.contain1))
            { message = ShutUpGlobalSettings.Instance.answerContain1; }
            if (ShutUpGlobalSettings.Instance.contain2 != string.Empty && ShutUpGlobalSettings.Instance.answerContain2 != string.Empty && Message.Contains(ShutUpGlobalSettings.Instance.contain2))
            { message = ShutUpGlobalSettings.Instance.answerContain2; }
            if (ShutUpGlobalSettings.Instance.contain3 != string.Empty && ShutUpGlobalSettings.Instance.answerContain3 != string.Empty && Message.Contains(ShutUpGlobalSettings.Instance.contain3))
            { message = ShutUpGlobalSettings.Instance.answerContain3; }
            if (ShutUpGlobalSettings.Instance.contain4 != string.Empty && ShutUpGlobalSettings.Instance.answerContain4 != string.Empty && Message.Contains(ShutUpGlobalSettings.Instance.contain4))
            { message = ShutUpGlobalSettings.Instance.answerContain4; }

            TreeRoot.StatusText = "[ShutUp]: write message..";
            Thread.Sleep(answerAfter * 1000);

            Lua.DoString(string.Format("SendChatMessage(\"{0}\", 'WHISPER', nil, '{1}')", message, Author));
            slog("Answer Whisper from {0} with: {1}", Author, message);

            if (ShutUpSettings.Instance.saveLog) // save answer in Log?
            {
                writeToLogFile(DateTime.Now.ToShortTimeString() + " - ANSWER WHISPER - " + Author + " : " + message);
            }
        }
        #endregion

        #region got a BG "whisper"
        public void newBattlegroundTalk(WoWChat.ChatLanguageSpecificEventArgs e)
        {
            if (e.Message.Contains(Me.Name) && e.Message != lastBgMessage && CharacterSettings.Instance.EnabledPlugins.Contains("[ShutUp]"))
            {
                lastBgMessage = e.Message;
                slog("you got a BG Msg! : {0}", e.Message);

                if (ShutUpSettings.Instance.SoundOn)
                {
                    PlaySound(ShutUpSettings.Instance.selectedSound); // play sound?
                }

                if (ShutUpSettings.Instance.saveLog) // save in Log?
                {
                    writeToLogFile(DateTime.Now.ToShortTimeString() + " - BG - " + e.Message);
                }

                if (ShutUpSettings.Instance.answerBG) // answer BG chat?
                {
                    Rnd = random.Next(1, 8);
                    AnswerBG(Rnd);

                    int answerAfter = random.Next(ShutUpSettings.Instance.answerBetweenMin, ShutUpSettings.Instance.answerBetweenMax);

                    if (ShutUpSettings.Instance.ContainAnswerBG)
                    {
                        if (ShutUpGlobalSettings.Instance.contain1 != string.Empty && ShutUpGlobalSettings.Instance.answerContain1 != string.Empty && e.Message.Contains(ShutUpGlobalSettings.Instance.contain1)) { message = ShutUpGlobalSettings.Instance.answerContain1; }
                        if (ShutUpGlobalSettings.Instance.contain2 != string.Empty && ShutUpGlobalSettings.Instance.answerContain2 != string.Empty && e.Message.Contains(ShutUpGlobalSettings.Instance.contain2)) { message = ShutUpGlobalSettings.Instance.answerContain2; }
                        if (ShutUpGlobalSettings.Instance.contain3 != string.Empty && ShutUpGlobalSettings.Instance.answerContain3 != string.Empty && e.Message.Contains(ShutUpGlobalSettings.Instance.contain3)) { message = ShutUpGlobalSettings.Instance.answerContain3; }
                        if (ShutUpGlobalSettings.Instance.contain4 != string.Empty && ShutUpGlobalSettings.Instance.answerContain4 != string.Empty && e.Message.Contains(ShutUpGlobalSettings.Instance.contain4)) { message = ShutUpGlobalSettings.Instance.answerContain4; }
                    }

                    TreeRoot.StatusText = "[ShutUp]: write message..";
                    Thread.Sleep(answerAfter * 1000);
                    Lua.DoString(string.Format("SendChatMessage(\"{0}\", 'BATTLEGROUND')", message));
                    slog("Answer BG-Chat with: {0}", message);

                    if (ShutUpSettings.Instance.saveLog) // save answer in Log?
                    {
                        writeToLogFile(DateTime.Now.ToShortTimeString() + " - ANSWER BG -  " + message);
                    }
                }
            }
        }
        #endregion

        #region Friebdlist
        public bool useFriendList1(string author)
        {
            if (ShutUpSettings.Instance.UseFriedlist1 && ShutUpGlobalSettings.Instance.FriendList1.Contains(author))
            { return true; }
            else { return false; }
        }

        public bool useGuildMembersList(string author)
        {
            if (ShutUpSettings.Instance.UseGuildMembersList && ShutUpSettings.Instance.GuildMembers.Contains(author))
            { return true; }
            else { return false; }
        }

        public bool useGuildMaster(string author)
        {
            if (ShutUpSettings.Instance.UseGuildMaster && ShutUpSettings.Instance.GuildMaster == author)
            { return true; }
            else { return false; }
        }

        public bool useGuildOffiList(string author)
        {
            if (ShutUpSettings.Instance.UseGuildOffisList && ShutUpSettings.Instance.GuildOfficers.Contains(author))
            { return true; }
            else { return false; }
        }

        public bool useInGameFriendsList(string author)
        {
            if (ShutUpSettings.Instance.UseInGameFriedlist && ShutUpSettings.Instance.InGameFriends.Contains(author))
            { return true; }
            else { return false; }
        }
        #endregion

        #region IgnorePlayer
        private void IgnorePlayer(string Author, string Msg)
        {
                Lua.DoString("RunMacroText(\"/ignore " + Author + "\")");
                slog("(ingame)Ignore Player: {0}!", Author);

                if (ShutUpSettings.Instance.saveLog)
                {
                    writeToLogFile(DateTime.Now.ToShortTimeString() + " - IGNORE PLAYER - " + Author + " : " + Msg);
                }
        }
        #endregion

        #region random answers / whisper
        private void AnswerWhisper(int i)
        {
            if (lastInt == i || lastInt == i - 4 || lastInt == i + 4)
            {
                if (i > 7) { --i; }
                else { ++i; }
            }
            lastInt = i;

            if (ShutUpGlobalSettings.Instance.rAnswerW1 == string.Empty && ShutUpGlobalSettings.Instance.rAnswerW2 == string.Empty &&
                ShutUpGlobalSettings.Instance.rAnswerW3 == string.Empty && ShutUpGlobalSettings.Instance.rAnswerW4 == string.Empty)
            {
                //MessageBox.Show(" You have answer to whisper selected,\n but you have added no random reply!", "AnswerError", MessageBoxButtons.OK);
                dlog("#2 : You have answer to whisper selected, but you have added no random reply!");
                message = string.Empty;
            }
            else
            {
                if ((i == 1 || i == 5) && ShutUpGlobalSettings.Instance.rAnswerW1 != string.Empty) { message = ShutUpGlobalSettings.Instance.rAnswerW1; }
                else if ((i == 2 || i == 6) && ShutUpGlobalSettings.Instance.rAnswerW2 != string.Empty) { message = ShutUpGlobalSettings.Instance.rAnswerW2; }
                else if ((i == 3 || i == 7) && ShutUpGlobalSettings.Instance.rAnswerW3 != string.Empty) { message = ShutUpGlobalSettings.Instance.rAnswerW3; }
                else if ((i == 4 || i >= 8) && ShutUpGlobalSettings.Instance.rAnswerW4 != string.Empty) { message = ShutUpGlobalSettings.Instance.rAnswerW4; }
                else { Rnd = random.Next(1, 8); AnswerWhisper(Rnd); }
            }
        }
        #endregion

        #region random answers / BG Chat
        private void AnswerBG(int i)
        {
            if (lastIntBG == i || lastIntBG == i - 4 || lastIntBG == i + 4)
            {
                if (i > 7) { --i; }
                else { ++i; }
            }
            lastIntBG = i;

            if (ShutUpGlobalSettings.Instance.rAnswerBG1 == string.Empty && ShutUpGlobalSettings.Instance.rAnswerBG2 == string.Empty &&
                ShutUpGlobalSettings.Instance.rAnswerBG3 == string.Empty && ShutUpGlobalSettings.Instance.rAnswerBG4 == string.Empty)
            {
                //MessageBox.Show(" You have answer to BG-Chat selected,\n but you have added no random reply!", "AnswerError", MessageBoxButtons.OK);
                dlog("#3 : You have answer to BG-Chat selected, but you have added no random reply!");
                message = string.Empty;
            }
            else
            {
                if ((i == 1 || i == 5) && ShutUpGlobalSettings.Instance.rAnswerBG1 != string.Empty) { message = ShutUpGlobalSettings.Instance.rAnswerBG1; }
                else if ((i == 2 || i == 6) && ShutUpGlobalSettings.Instance.rAnswerBG2 != string.Empty) { message = ShutUpGlobalSettings.Instance.rAnswerBG2; }
                else if ((i == 3 || i == 7) && ShutUpGlobalSettings.Instance.rAnswerBG3 != string.Empty) { message = ShutUpGlobalSettings.Instance.rAnswerBG3; }
                else if ((i == 4 || i > 7) && ShutUpGlobalSettings.Instance.rAnswerBG4 != string.Empty) { message = ShutUpGlobalSettings.Instance.rAnswerBG4; }
                else { Rnd = random.Next(1, 8); AnswerBG(Rnd); }
            }
        }
        #endregion

        #region writeToLogFile
        private void writeToLogFile(string Msg)
        {
            try
            {
                writer = new StreamWriter(ShutUpLogLocation, true);
                writer.WriteLine((DateTime.Now.ToShortDateString()).Replace('/', '.') + " - " + Msg);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(" Error: There was an error, during writing to LogFile\n \n " + ex + "", "SaveError", MessageBoxButtons.OK);
                //MessageBox.Show(" Error: There was an error, during writing to LogFile!", "SaveError", MessageBoxButtons.OK);
                dlog("#4 : Error: There was an error, during writing to LogFile!");
                dlog("#4 : {0}", ex);
            }

            writer.Close();
        }
        #endregion

        #region PlaySound
        private void PlaySound(string selectedSoundFile)
        {
            if (selectedSoundFile == "bing sound")
            {
                System.Media.SystemSounds.Beep.Play();
                System.Media.SystemSounds.Beep.Play();
            }
            else if (selectedSoundFile == "MySoundFile")
            {
                if (ShutUpGlobalSettings.Instance.myWaveLocation == "C:/MyFolder/MyWave.wav" || ShutUpGlobalSettings.Instance.myWaveLocation == string.Empty)
                {
                    //MessageBox.Show(" you have not selected your wave, \n or the file patch is wrong! \n \n   -klick in the settings on the search button!", "Error", MessageBoxButtons.OK);
                    dlog("#5 MyWave: file patch is wrong!");
                }
                else
                {
                    if (ShutUpSettings.Instance.useExternalPlayer)
                    {
                        System.Diagnostics.Process.Start(ShutUpGlobalSettings.Instance.myWaveLocation);
                    }
                    else
                    {
                        new SoundPlayer(ShutUpGlobalSettings.Instance.myWaveLocation).Play();
                    }
                }
            }
            else
            {
                if (ShutUpSettings.Instance.useExternalPlayer)
                {
                    System.Diagnostics.Process.Start(Logging.ApplicationPath + "\\Plugins\\ShutUp\\Sounds\\" + selectedSoundFile);
                }
                else
                {
                    new SoundPlayer(Logging.ApplicationPath + "\\Plugins\\ShutUp\\Sounds\\" + selectedSoundFile).Play();
                }
            }

            if (!loopTimer.IsRunning)
            {
                loopTimer.Reset(); loopTimer.Start(); loopSound = selectedSoundFile;
            }
        }
        #endregion

        #region GM Alert
        private void GMcheck()
        {
            if (GMsound && loopTimer.IsRunning && loopTimer.ElapsedMilliseconds > (3000))
            {
                loopTimer.Reset(); loopTimer.Start();
                GMalert("We have received a message from a GM!");
            }

            if (nearGM() && (ShutUpSettings.Instance.nearByGMsound || ShutUpSettings.Instance.logoutNearByGM))
            {
                if (ShutUpSettings.Instance.nearByGMsound)
                {
                    if (!ShutUpSettings.Instance.logoutNearByGM)
                    {
                        if (!loopTimer.IsRunning) { loopTimer.Reset(); loopTimer.Start(); }
                        else if (loopTimer.IsRunning && loopTimer.ElapsedMilliseconds > (3000))
                        {
                            loopTimer.Reset(); loopTimer.Start();
                            GMalert("A GM is near you!");
                        }
                    }
                    else
                    {
                        GMalert("A GM is near you!");
                    }
                }

                if (ShutUpSettings.Instance.logoutNearByGM)
                {
                    Thread.Sleep(3000);
                    exitWoW();
                }
            }
        }

        private void exitWoW() //Made by MaiN
        {
            Lua.DoString("ForceQuit()");  // Lua.DoString doesn't seem to run if bot is stopped, thus I placed it here.
            if (Styx.Logic.BehaviorTree.TreeRoot.IsRunning)
            {
                Styx.Logic.BehaviorTree.TreeRoot.Stop();
            }
            int id = ObjectManager.Wow.ProcessId;
            int tickCount = Environment.TickCount;
            while (Environment.TickCount - tickCount < 10000 && Process.GetProcessesByName("Wow").Where(proc => proc.Id == id).ToList().Count > 0)
            {
                Thread.Sleep(200);
            }

            Process process;
            if ((process = Process.GetProcessesByName("Wow").Where(proc => proc.Id == id).FirstOrDefault()) != null)
            {
                process.Kill();
            }
            System.Windows.Forms.Application.Exit();
        }

        private void GMalert(string text)
        {
            Logging.WriteDebug(System.Drawing.Color.Red, "############## WARNING ##############");
            Logging.WriteDebug(System.Drawing.Color.Red, text);
            Logging.WriteDebug(System.Drawing.Color.Red, "#####################################");
            PlaySound("siren1.wav");
        }

        private bool nearGM()
        {
            List<WoWPlayer> GMsearch = ObjectManager.GetObjectsOfType<WoWPlayer>();

            foreach (WoWPlayer player in GMsearch)
            {
                if (player.IsGM)
                {
                    return true;
                }
            }
            return false;
        }
        #endregion
    }
}

public static class IgnoreManager
{
    static public Dictionary<string, int> players = new Dictionary<string, int>();
    public static bool onListOrAdd(string name)
    {
        foreach (KeyValuePair<string, int> player in players)
        {
            if (player.Key == name)
            {
                int i = player.Value; ++i;
                players.Remove(name);
                players.Add(name, i);
                return true;
            }
        }
        players.Add(name, 1);
        return false;
    }

    public static bool Igno(string name, int max)
    {
        foreach (KeyValuePair<string, int> player in players)
        {
            if (player.Key == name && player.Value > max)
            {
                return true;
            }
        }
        return false;
    }
}