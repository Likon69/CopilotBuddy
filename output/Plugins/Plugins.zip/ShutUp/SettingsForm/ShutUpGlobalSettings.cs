﻿using System.IO;
using System.Windows.Forms;
using Styx;
using Styx.Helpers;

namespace ShutUp
{
    public class ShutUpGlobalSettings : Settings
    {
        public static ShutUpGlobalSettings Instance = new ShutUpGlobalSettings();

        public ShutUpGlobalSettings()
            : base(Logging.ApplicationPath + "\\Settings\\ShutUp_GlobalSettings.xml")
        {
            Load();
        }

        ~ShutUpGlobalSettings()
        {
            Save();
        }

        [Setting(Explanation = "wave file location"), DefaultValue("C:/MyFolder/MyWave.wav")]
        public string myWaveLocation { get; set; }

        [Setting(Explanation = "radom whisper answer 1"), DefaultValue("Shut up")]
        public string rAnswerW1 { get; set; }

        [Setting(Explanation = "radom whisper answer 2"), DefaultValue("fuck off")]
        public string rAnswerW2 { get; set; }

        [Setting(Explanation = "radom whisper answer 3"), DefaultValue("let me alone")]
        public string rAnswerW3 { get; set; }

        [Setting(Explanation = "radom whisper answer 4"), DefaultValue("??")]
        public string rAnswerW4 { get; set; }

        [Setting(Explanation = "radom BG answer 1"), DefaultValue("shut up")]
        public string rAnswerBG1 { get; set; }

        [Setting(Explanation = "radom BG answer 2"), DefaultValue("gogo")]
        public string rAnswerBG2 { get; set; }

        [Setting(Explanation = "radom BG answer 3"), DefaultValue("fuck off")]
        public string rAnswerBG3 { get; set; }

        [Setting(Explanation = "radom BG answer 4"), DefaultValue("??")]
        public string rAnswerBG4 { get; set; }

        [Setting(Explanation = "chat contain 1"), DefaultValue("hi")]
        public string contain1 { get; set; }

        [Setting(Explanation = "chat contain 2"), DefaultValue("?")]
        public string contain2 { get; set; }

        [Setting(Explanation = "chat contain 3"), DefaultValue("help")]
        public string contain3 { get; set; }

        [Setting(Explanation = "chat contain 4"), DefaultValue("bot")]
        public string contain4 { get; set; }

        [Setting(Explanation = "answer -> contain 1"), DefaultValue("Hi!")]
        public string answerContain1 { get; set; }

        [Setting(Explanation = "answer -> contain 2"), DefaultValue("no thanks")]
        public string answerContain2 { get; set; }

        [Setting(Explanation = "answer -> contain 3"), DefaultValue("sry no time")]
        public string answerContain3 { get; set; }

        [Setting(Explanation = "answer -> contain 4"), DefaultValue("your mother is a bot!")]
        public string answerContain4 { get; set; }

        [Setting(Explanation = "global friendlist"), DefaultValue(null)]
        public string[] FriendList1 { get; set; }

        [Setting(Explanation = "answer whisper"), DefaultValue("I'm sorry, but I have no more time! I'm already too late..")]
        public string answerGMwhisper { get; set; }

    }
}
