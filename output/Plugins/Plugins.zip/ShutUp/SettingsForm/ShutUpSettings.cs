﻿using System.IO;
using System.Windows.Forms;
using Styx;
using Styx.Helpers;

namespace ShutUp
{
    public class ShutUpSettings : Settings
    {
        public static ShutUpSettings Instance = new ShutUpSettings();

        public ShutUpSettings()
            : base(Logging.ApplicationPath + "\\Settings\\ShutUp_Settings_" + StyxWoW.Me.Name + ".xml")
        {
            Load();
        }

        ~ShutUpSettings()
        {
            Save();
        }

        [Setting(Explanation = "sound on"), DefaultValue(true)]
        public bool SoundOn { get; set; }

        [Setting(Explanation = "sound select"), DefaultValue("murloc.wav")]
        public string selectedSound { get; set; }

        [Setting(Explanation = "save log"), DefaultValue(true)]
        public bool saveLog { get; set; }

        [Setting(Explanation = "answer by whisper"), DefaultValue(true)]
        public bool answerWisper { get; set; }

        [Setting(Explanation = "answer by bg chat"), DefaultValue(false)]
        public bool answerBG { get; set; }

        [Setting(Explanation = "answer bg chat when contain x"), DefaultValue(false)]
        public bool ContainAnswerBG { get; set; }

        [Setting(Explanation = "answer between x sec (min)"), DefaultValue(6)]
        public int answerBetweenMin { get; set; }

        [Setting(Explanation = "answer between x sec (max)"), DefaultValue(11)]
        public int answerBetweenMax { get; set; }

        [Setting(Explanation = "ignore all players"), DefaultValue(false)]
        public bool ignoAll { get; set; }

        [Setting(Explanation = "ignore player after 2. whispers"), DefaultValue(true)]
        public bool igno2W { get; set; }

        [Setting(Explanation = "ignore player after X whispers"), DefaultValue(false)]
        public bool ignoXW { get; set; }

        [Setting(Explanation = "no player ignore"), DefaultValue(false)]
        public bool ignoNo { get; set; }

        [Setting(Explanation = "use global friendlist"), DefaultValue(false)]
        public bool UseFriedlist1 { get; set; }

        [Setting(Explanation = "use guild memberlist"), DefaultValue(false)]
        public bool UseGuildMembersList { get; set; }

        [Setting(Explanation = "use guild master"), DefaultValue(false)]
        public bool UseGuildMaster { get; set; }

        [Setting(Explanation = "use guild offislist"), DefaultValue(false)]
        public bool UseGuildOffisList { get; set; }

        [Setting(Explanation = "use inGame Friendlist"), DefaultValue(false)]
        public bool UseInGameFriedlist { get; set; }

        [Setting(Explanation = "playsound by friend"), DefaultValue(false)]
        public bool SoundByFriend { get; set; }

        [Setting(Explanation = "PopUp by friend"), DefaultValue(false)]
        public bool PopUpByFriend { get; set; }

        [Setting(Explanation = "answer a Friend"), DefaultValue(false)]
        public bool answerFriend { get; set; }

        [Setting(Explanation = "sound select"), DefaultValue("siren1.wav")]
        public string selectedFriendSound { get; set; }

        [Setting(Explanation = "soft igno by friends"), DefaultValue(true)]
        public bool softIgnoFriend { get; set; }

        [Setting(Explanation = "soft igno after"), DefaultValue(4)]
        public int softIgnoAfter { get; set; }

        [Setting(Explanation = "soft igno friend after"), DefaultValue(4)]
        public int softIgnoFrAfter { get; set; }

        [Setting(Explanation = "ingame Ignore?"), DefaultValue(false)]
        public bool ingameIgno { get; set; }

        [Setting(Explanation = "how many soundloop"), DefaultValue(3)]
        public int SoundLoop { get; set; }

        [Setting(Explanation = "soundloop every Xsec"), DefaultValue(6)]
        public int SoundLoopEvery { get; set; }

        [Setting(Explanation = "use external sound player?"), DefaultValue(false)]
        public bool useExternalPlayer { get; set; }

        [Setting(Explanation = "Guild Master"), DefaultValue("")]
        public string GuildMaster { get; set; }

        [Setting(Explanation = "Guild Officers"), DefaultValue(null)]
        public string[] GuildOfficers { get; set; }

        [Setting(Explanation = "Guild Members"), DefaultValue(null)]
        public string[] GuildMembers { get; set; }

        [Setting(Explanation = "inGame Friends"), DefaultValue(null)]
        public string[] InGameFriends { get; set; }

        [Setting(Explanation = "alert by GM whisper"), DefaultValue(true)]
        public bool GMwhisperSound { get; set; }

        [Setting(Explanation = "logout by GM whisper"), DefaultValue(false)]
        public bool logoutByGMwhisper { get; set; }

        [Setting(Explanation = "answer GM"), DefaultValue(false)]
        public bool answerGM { get; set; }

        [Setting(Explanation = "alert near by GM"), DefaultValue(true)]
        public bool nearByGMsound { get; set; }

        [Setting(Explanation = "logout near by GM"), DefaultValue(false)]
        public bool logoutNearByGM { get; set; }

    }
}
