﻿using System;
using System.Collections.Generic;
using System.Windows.Media;
using Styx.Helpers;

namespace KBA.Helpers
{
    internal static class Logger
    {
        private static readonly Queue<string> LogQueue = new Queue<string>(5);

        static void Output(Color color, string format, params object[] args)
        {
            string msg = string.Format(format, args);
            if (LogQueue.Contains(msg)) return;
            if (LogQueue.Count >= 5) LogQueue.Dequeue();
            LogQueue.Enqueue(msg);
            Logging.Write(color, "[KBA]: " + format, args);
        }

        public static void InitLog(string format, params object[] args)
        { Output(Colors.Gainsboro, format, args); }

        public static void ItemLog(string format, params object[] args)
        { Output(Colors.LawnGreen, format, args); }

        public static void FailLog(string format, params object[] args)
        { Output(Colors.GreenYellow, format, args); }

        public static void InfoLog(string format, params object[] args)
        { Output(Colors.CornflowerBlue, format, args); }

        public static void CombatLog(string format, params object[] args)
        { Output(Colors.Pink, format, args); }

        public static void DebugLog(string format, params object[] args)
        { Output(Colors.DarkGoldenrod, format, args); }

        private static WaitTimer logTimer = new WaitTimer(TimeSpan.FromMilliseconds(1000));
    }
}
