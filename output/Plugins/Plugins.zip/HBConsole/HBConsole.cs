﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.CodeDom.Compiler;
using System.Reflection;
using System.Xml.Linq;
using Microsoft.CSharp;
using Styx;
using Styx.Plugins.PluginClass;
using Styx.Helpers;
using Styx.Logic.BehaviorTree;
using Styx.WoWInternals;

namespace HighVoltz
{
    class MainForm : Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param apiName="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btnCompile = new System.Windows.Forms.Button();
            this.csharpCode = new System.Windows.Forms.RichTextBox();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.RenameButton = new System.Windows.Forms.Button();
            this.NewSnipletButton = new System.Windows.Forms.Button();
            this.savedSnipletsCombo = new System.Windows.Forms.ComboBox();
            this.textOutput = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.splitContainer1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(821, 524);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tableLayoutPanel2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.textOutput);
            this.splitContainer1.Size = new System.Drawing.Size(815, 518);
            this.splitContainer1.SplitterDistance = 337;
            this.splitContainer1.TabIndex = 5;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 337F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(815, 337);
            this.tableLayoutPanel2.TabIndex = 7;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 6;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.26708F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.42236F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.42236F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.42236F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.42236F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.04348F));
            this.tableLayoutPanel3.Controls.Add(this.btnCompile, 5, 0);
            this.tableLayoutPanel3.Controls.Add(this.csharpCode, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.DeleteButton, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.saveButton, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.RenameButton, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.NewSnipletButton, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.savedSnipletsCombo, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(815, 337);
            this.tableLayoutPanel3.TabIndex = 12;
            // 
            // btnCompile
            // 
            this.btnCompile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCompile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompile.Location = new System.Drawing.Point(710, 3);
            this.btnCompile.Name = "btnCompile";
            this.btnCompile.Size = new System.Drawing.Size(102, 24);
            this.btnCompile.TabIndex = 15;
            this.btnCompile.Text = "Test!";
            this.btnCompile.UseVisualStyleBackColor = true;
            this.btnCompile.Click += new System.EventHandler(this.btnCompile_Click);
            // 
            // csharpCode
            // 
            this.csharpCode.AcceptsTab = true;
            this.tableLayoutPanel3.SetColumnSpan(this.csharpCode, 6);
            this.csharpCode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.csharpCode.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.csharpCode.HideSelection = false;
            this.csharpCode.Location = new System.Drawing.Point(0, 30);
            this.csharpCode.Margin = new System.Windows.Forms.Padding(0);
            this.csharpCode.Name = "csharpCode";
            this.csharpCode.Size = new System.Drawing.Size(815, 307);
            this.csharpCode.TabIndex = 14;
            this.csharpCode.Text = "";
            this.csharpCode.WordWrap = false;
            this.csharpCode.TextChanged += new System.EventHandler(this.csharpCode_TextChanged);
            this.csharpCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textCode_KeyDown);
            // 
            // DeleteButton
            // 
            this.DeleteButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DeleteButton.Location = new System.Drawing.Point(609, 3);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(95, 24);
            this.DeleteButton.TabIndex = 13;
            this.DeleteButton.Text = "Delete";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.saveButton.Location = new System.Drawing.Point(508, 3);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(95, 24);
            this.saveButton.TabIndex = 12;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // RenameButton
            // 
            this.RenameButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RenameButton.Location = new System.Drawing.Point(407, 3);
            this.RenameButton.Name = "RenameButton";
            this.RenameButton.Size = new System.Drawing.Size(95, 24);
            this.RenameButton.TabIndex = 10;
            this.RenameButton.Text = "Rename";
            this.RenameButton.UseVisualStyleBackColor = true;
            this.RenameButton.Click += new System.EventHandler(this.RenameButton_Click);
            // 
            // NewSnipletButton
            // 
            this.NewSnipletButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NewSnipletButton.Location = new System.Drawing.Point(306, 3);
            this.NewSnipletButton.Name = "NewSnipletButton";
            this.NewSnipletButton.Size = new System.Drawing.Size(95, 24);
            this.NewSnipletButton.TabIndex = 9;
            this.NewSnipletButton.Text = "New";
            this.NewSnipletButton.UseVisualStyleBackColor = true;
            this.NewSnipletButton.Click += new System.EventHandler(this.NewSnipletButton_Click);
            // 
            // savedSnipletsCombo
            // 
            this.savedSnipletsCombo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.savedSnipletsCombo.FormattingEnabled = true;
            this.savedSnipletsCombo.Location = new System.Drawing.Point(3, 3);
            this.savedSnipletsCombo.Name = "savedSnipletsCombo";
            this.savedSnipletsCombo.Size = new System.Drawing.Size(297, 21);
            this.savedSnipletsCombo.TabIndex = 4;
            this.savedSnipletsCombo.SelectedIndexChanged += new System.EventHandler(this.savedSnipletsCombo_SelectedIndexChanged);
            // 
            // textOutput
            // 
            this.textOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textOutput.Font = new System.Drawing.Font("Consolas", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textOutput.Location = new System.Drawing.Point(0, 0);
            this.textOutput.MaxLength = 2100000;
            this.textOutput.Name = "textOutput";
            this.textOutput.ReadOnly = true;
            this.textOutput.Size = new System.Drawing.Size(815, 177);
            this.textOutput.TabIndex = 4;
            this.textOutput.Text = "";
            this.textOutput.WordWrap = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(821, 524);
            this.Controls.Add(this.tableLayoutPanel1);
            this.IsMdiContainer = true;
            this.MinimumSize = new System.Drawing.Size(400, 300);
            this.Name = "MainForm";
            this.Text = "HB Console";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion


        public static MainForm Instance { get; private set; }
        public static bool IsValid { get { return Instance != null && Instance.Visible && !Instance.Disposing && !Instance.IsDisposed; } }
        private TableLayoutPanel tableLayoutPanel1;
        private SplitContainer splitContainer1;
        private TableLayoutPanel tableLayoutPanel2;
        public RichTextBox textOutput;
        private TableLayoutPanel tableLayoutPanel3;
        private Button btnCompile;
        private RichTextBox csharpCode;
        private Button DeleteButton;
        private Button saveButton;
        private Button RenameButton;
        private Button NewSnipletButton;
        private ComboBox savedSnipletsCombo;
        public MainForm()
        {
            InitializeComponent();
            Instance = this;
        }

        private void btnCompile_Click(object sender, EventArgs e)
        {
            CompileAndRun();
        }


        private void textCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F5)
            {
                CompileAndRun();
            }
        }

        void CompileAndRun()
        {
            try
            {
                    btnCompile.BackColor = HBConsole.CodeDriver.CompileAndRun(csharpCode.Text) ? Color.White : Color.Red;
                    HBConsoleSettings.Instance.CSharpSniplets[HBConsoleSettings.Instance.CSharpSelectedIndex] = csharpCode.Text;

            }
            catch (Exception ex)
            {
                HBConsole.Log(Color.Red, ex.ToString());
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            savedSnipletsCombo.Items.AddRange(HBConsoleSettings.Instance.CSharpSnipletNames);
            savedSnipletsCombo.SelectedIndex = HBConsoleSettings.Instance.CSharpSelectedIndex;
            csharpCode.Text = HBConsoleSettings.Instance.CSharpSniplets[savedSnipletsCombo.SelectedIndex != -1 ? savedSnipletsCombo.SelectedIndex : 0];
        }

        private void savedSnipletsCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (savedSnipletsCombo.SelectedIndex < HBConsoleSettings.Instance.CSharpSniplets.Length && savedSnipletsCombo.SelectedIndex != -1)
            {
                csharpCode.Text = HBConsoleSettings.Instance.CSharpSniplets[savedSnipletsCombo.SelectedIndex];
                HBConsoleSettings.Instance.CSharpSelectedIndex = savedSnipletsCombo.SelectedIndex;
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            HBConsoleSettings.Instance.Save();
        }

        private void NewSnipletButton_Click(object sender, EventArgs e)
        {
            AddNewSnipplet(GetNewScriptName());
        }

        void AddNewSnipplet(string name)
        {
            HBConsoleSettings.Instance.CSharpSniplets = new List<string>(HBConsoleSettings.Instance.CSharpSniplets).Concat(new[] { "" }).ToArray();
            HBConsoleSettings.Instance.CSharpSnipletNames = new List<string>(HBConsoleSettings.Instance.CSharpSnipletNames).Concat(new[] { name }).ToArray();
            savedSnipletsCombo.Items.Add(name);
            savedSnipletsCombo.SelectedIndex = HBConsoleSettings.Instance.CSharpSniplets.Length - 1;
            HBConsoleSettings.Instance.CSharpSelectedIndex = savedSnipletsCombo.SelectedIndex;
        }

        private static string GetNewScriptName()
        {
            for (int i = 1; i < int.MaxValue; i++)
            {
                var name = "Untitled" + i;
                if (!HBConsoleSettings.Instance.CSharpSnipletNames.Contains(name))
                    return name;
            }
            return Path.GetRandomFileName();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure?","Delete this?",MessageBoxButtons.YesNo) == DialogResult.Yes &&  savedSnipletsCombo.SelectedIndex >= 0)
            {

                var temp1 = new List<string>(HBConsoleSettings.Instance.CSharpSniplets);
                var temp2 = new List<string>(HBConsoleSettings.Instance.CSharpSnipletNames);
                temp1.RemoveAt(savedSnipletsCombo.SelectedIndex);
                temp2.RemoveAt(savedSnipletsCombo.SelectedIndex);
                HBConsoleSettings.Instance.CSharpSniplets = temp1.ToArray();
                HBConsoleSettings.Instance.CSharpSnipletNames = temp2.ToArray();

                int index = savedSnipletsCombo.SelectedIndex;
                savedSnipletsCombo.Items.RemoveAt(savedSnipletsCombo.SelectedIndex);

                if (index == savedSnipletsCombo.Items.Count)
                    index--;

                if (index < 0)
                {
                    AddNewSnipplet(GetNewScriptName());
                    index++;
                }
                HBConsoleSettings.Instance.CSharpSelectedIndex = savedSnipletsCombo.SelectedIndex = index;
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            HBConsoleSettings.Instance.Save();
        }

        private void csharpCode_TextChanged(object sender, EventArgs e)
        {
            if (savedSnipletsCombo.SelectedIndex >= 0)
                HBConsoleSettings.Instance.CSharpSniplets[savedSnipletsCombo.SelectedIndex] = csharpCode.Text;
        }

        private void RenameButton_Click(object sender, EventArgs e)
        {
            savedSnipletsCombo.Items[HBConsoleSettings.Instance.CSharpSelectedIndex] = savedSnipletsCombo.Text;
            HBConsoleSettings.Instance.CSharpSnipletNames[HBConsoleSettings.Instance.CSharpSelectedIndex] = savedSnipletsCombo.Text;
            savedSnipletsCombo.SelectedIndex = HBConsoleSettings.Instance.CSharpSelectedIndex;
        }
    }
}



namespace HighVoltz
{
    public class HBConsole : HBPlugin
    {
        public override string Name { get { return string.Format("HBConsole {0}", Version); } }
        public override string Author { get { return "HighVoltz"; } }
        private readonly Version _version = new Version(1, 7);
        public override Version Version { get { return _version; } }
        public override string ButtonText { get { return "HBConsole"; } }
        public override bool WantButton { get { return true; } }
        static public string TempFolder = Logging.ApplicationPath + @"\Plugins\HBConsole\Temp\";
        static internal AppDomainDriver CodeDriver = new AppDomainDriver();
        public static HBConsole Instance { get; private set; }

        public HBConsole()
        {
            Instance = this;
            // using ctor so plugin doesn't need to be 'Enabled' to initialize..
            try
            {
                WipeTempFolder();
            }
            catch (Exception ex) { Logging.Write(Color.Red, ex.ToString()); }
        }

        void WipeTempFolder()
        {
            if (!Directory.Exists(TempFolder))
            {
                Directory.CreateDirectory(TempFolder);
            }
            foreach (string file in Directory.GetFiles(TempFolder, "*.*", SearchOption.AllDirectories))
            {
                try
                {
                    File.Delete(file);
                }
                // ReSharper disable EmptyGeneralCatchClause
                catch { }
                // ReSharper restore EmptyGeneralCatchClause
            }
        }

        public override void OnButtonPress()
        {
            if (!MainForm.IsValid)
                new MainForm().Show();
            else
                MainForm.Instance.Activate();
        }

        public override void Pulse()
        {

        }

        static public void Api(string apiName)
        {
            Type[] types = Assembly.GetEntryAssembly().GetExportedTypes().Where(t => t.Name.Contains(apiName)).ToArray();

            foreach (Type t in types)
            {
                Log(Color.DarkGreen, "\n  *** {0} ***", t.FullName);
                foreach (MemberInfo mi in t.GetMembers())
                {
                    Log("{0}", mi);
                }
            }
        }

        internal delegate void UpdateLogCallback(Color color, string text);

        public static void Log(string text, params object[] arg)
        {
            if (!string.IsNullOrEmpty(text))
                Log(Color.Black, text, arg);
        }

        public static void ClearLog()
        {
            if (MainForm.Instance.textOutput.InvokeRequired)
                MainForm.Instance.textOutput.BeginInvoke(new Action(()=> MainForm.Instance.textOutput.Clear()));
            else
                MainForm.Instance.textOutput.Clear();
        }



        public static void Log(Color c, string text, params object[] arg)
        {
            if (string.IsNullOrEmpty(text))
                return;
            text = string.Format(text, arg);
            if (MainForm.IsValid)
            {
                try
                {
                    if (MainForm.Instance.textOutput.InvokeRequired)
                        MainForm.Instance.textOutput.BeginInvoke(new UpdateLogCallback(UpdateLog), c, text);
                    else
                    {
                        MainForm.Instance.textOutput.SelectionStart = MainForm.Instance.textOutput.TextLength;
                        MainForm.Instance.textOutput.SelectionColor = c;
                        MainForm.Instance.textOutput.SelectedText = text + Environment.NewLine;
                        MainForm.Instance.textOutput.ScrollToCaret();
                    }
                }
                // ReSharper disable EmptyGeneralCatchClause
                catch { }
                // ReSharper restore EmptyGeneralCatchClause
            }
            else
            {
                Logging.Write(c, text, arg);
            }
        }

        static internal void UpdateLog(Color c, string text)
        {
            MainForm.Instance.textOutput.SelectionStart = MainForm.Instance.textOutput.TextLength;
            MainForm.Instance.textOutput.SelectionColor = c;
            MainForm.Instance.textOutput.SelectedText = text + Environment.NewLine;
            MainForm.Instance.textOutput.ScrollToCaret();
        }
    }

    public class AppDomainDriver
    {
        public bool CompileAndRun(string code)
        {
            try
            {
                var codeDriver = (CodeDriver)Activator.CreateInstance(typeof(CodeDriver));
                if (!TreeRoot.IsRunning)
                    ObjectManager.Update();
                return codeDriver.CompileAndRun(code);
            }
            catch (Exception ex)
            {
                HBConsole.Log(Color.Red, ex.ToString());
                return false;
            }
        }
    }

    public class CodeDriver : MarshalByRefObject
    {


        



        #region Strings

        private const string Prefix =
            @"using System;
using System.Reflection;
using System.Data;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Xml.Linq;
using Styx;
using Styx.Helpers;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.WoWInternals.WoWCache;
using Styx.Plugins;
using Styx.WoWInternals.World;
using Styx.Database;
using Styx.WoWInternals.DBC;
using Styx.Patchables;" + 

            "public static class Driver" +
            "{" +
            "static LocalPlayer Me = ObjectManager.Me;" +
            " public static void Run()" +
            " {";
        const string Postfix =
        " }" +
            // add util methods here
            "static public void Log ( object format, params object[] arg)" +
            "{" +
                "HighVoltz.HBConsole.Log(format.ToString(),arg);" +
            "}" +
            "static public void Api ( string format)" +
            "{" +
                "HighVoltz.HBConsole.Api(format);" +
            "}" +
            "static public void ClearLog ()" +
            "{" +
                "HighVoltz.HBConsole.ClearLog();" +
            "}" +
            "static List<WoWGameObject> GameObjects {get{return ObjectManager.GetObjectsOfType<WoWGameObject>();}}" +
            "static List<WoWObject> Objects {get{return ObjectManager.ObjectList;}}" +
            "static List<WoWUnit> Units {get{return ObjectManager.GetObjectsOfType<WoWUnit>();}}" +
            "static List<WoWPlayer> Players {get{return ObjectManager.GetObjectsOfType<WoWPlayer>();}}" +
            "static List<WoWItem> Items {get{return ObjectManager.GetObjectsOfType<WoWItem>();}}" +
            "static List<WoWDynamicObject> DynamicObjects {get{return ObjectManager.GetObjectsOfType<WoWDynamicObject>();}}" +
        "}";
        #endregion

        // returns true if compiled sucessfully
        public bool CompileAndRun(string input)
        {
            CompilerResults results;
            using (var provider = new CSharpCodeProvider(new Dictionary<string, string>
                                                             { 
                {"CompilerVersion", "v3.5"},
            }))
            {
                var options = new CompilerParameters();
                foreach (Assembly asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    if (!asm.GetName().Name.Contains(HBConsole.Instance.Name))
                        options.ReferencedAssemblies.Add(asm.Location);
                }
                options.GenerateExecutable = false;
                options.TempFiles = new TempFileCollection(HBConsole.TempFolder, false);
                options.IncludeDebugInformation = false;
                options.OutputAssembly = string.Format("{0}\\CodeAssembly{1:N}.dll", HBConsole.TempFolder, Guid.NewGuid());
                options.CompilerOptions = "/optimize";

                var sb = new StringBuilder();
                sb.Append(Prefix);
                sb.Append(input);
                sb.Append(Postfix);
                results = provider.CompileAssemblyFromSource(options, sb.ToString());
            }
            if (results.Errors.HasErrors)
            {
                var errorMessage = new StringBuilder();
                foreach (CompilerError error in results.Errors)
                {
                    errorMessage.AppendFormat("{0}) {1}\n", error.Line,
                    error.ErrorText);
                }
                HBConsole.Log(Color.Red, errorMessage.ToString());
                return false;
            }
            Type driverType = results.CompiledAssembly.GetType("Driver");
            driverType.InvokeMember("Run", BindingFlags.InvokeMethod |
                                           BindingFlags.Static | BindingFlags.Public,
                                    null, null, null);
            return true;
        }
    }

    internal class HBConsoleSettings : Settings
    {
        internal static readonly HBConsoleSettings Instance = new HBConsoleSettings();

        public HBConsoleSettings()
            : base(Path.Combine(Logging.ApplicationPath, @"Settings\HBConsole.xml"))
        {
            if (CSharpSniplets == null)
                CSharpSniplets = new[] { "" };

            if (CSharpSnipletNames == null)
                CSharpSnipletNames = new[] { "Untitled1" };
        }

        [Setting]
        public string[] CSharpSniplets { get; set; }

        [Setting]
        public string[] CSharpSnipletNames { get; set; }

        [Setting]
        public int CSharpSelectedIndex { get; set; }
    }

}