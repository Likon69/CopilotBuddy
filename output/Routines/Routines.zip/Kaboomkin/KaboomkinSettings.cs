﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization;
using System.Xml;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.WoWInternals;
using ObjectManager = Styx.WoWInternals.ObjectManager;


namespace Kaboomkin
{
    public class KaboomkinSet
    {
        string _cfgFile = "CustomClasses\\Config";
        public KaboomkinSet()
        {
            if (ObjectManager.Me.Class == WoWClass.Druid)
                try
                {
                    Load();
                }
                catch (Exception e)
                { Logging.Write(e.Message); }
        }

        public bool HealBot = false;
        public int HealingMode = 0; //0 = Everything Friendly, 1 = PartyMembers, 2 = Raid Members
        public int EatAt = 50;
        public int DrinkAt = 50;
        public bool isTank = false;
        public int HealingTouch = 30;
        public int Rejuvenation = 70;

        public int Rejuv_HL = 95;
        public int Swiftmend_HL = 95;
        public int Nourish_HL = 95;
        public int Regrowth_HL = 95;
        public int Lifebloom_HL = 95;
        public int Innervate_HL = 50;
        public int HealingTouch_HL = 30;

        public int Tranquility = 70;
        public int Num_TargetsTranquility = 3;
        public bool use_Tranquility = true;

        public int WildGrowth = 70;
        public int Num_TargetsWildGrowth = 3;
        public bool use_WildGrowth = true;

        public bool removeCurse = true;
        public bool abolishPosin = true;

        public bool RaidRotation = false;
        public int Inntervate_Bal = 30;
        public int LowMana = 10;
        public int HighMana = 60;
        public bool Huricane_Adds = true;

        public bool FeralCharge = true;
        public bool NoBear = false;
        public bool PouncePull = true;


        public bool GiftOfTheWild = false;
        public bool MarkOfTheWild = true;

        public bool Revive = true;
        public bool Rebirth = true;
        public bool ThornsTank = true;


        //Code Extracted from ShamWOW
        public void Load()
        {
            //    XmlTextReader reader;
            XmlDocument xml = new XmlDocument();
            XmlNode xvar;

            string sPath = Process.GetCurrentProcess().MainModule.FileName;
            sPath = Path.GetDirectoryName(sPath);
            sPath = Path.Combine(sPath, _cfgFile);

            if (!Directory.Exists(sPath))
            {
                Logging.WriteDebug("Creating config directory");
                Directory.CreateDirectory(sPath);
            }

            String serverName = Lua.GetReturnVal<string>("return GetRealmName()", 0);
            String toonName = Styx.WoWInternals.ObjectManager.Me.Name;

            sPath = Path.Combine(sPath, "Kaboomkin-" + serverName + "-" + toonName + ".config");
       

            //((Warlock)Global.CurrentCC).slog("");
            //Logging.Write("");

            Logging.WriteDebug("Loading config file");
            System.IO.FileStream fs = new System.IO.FileStream(@sPath, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite);
            try
            {
                xml.Load(fs);
                fs.Close();
            }
            catch (Exception e)
            {
                Logging.Write(e.Message);
                Logging.Write("Continuing with Default Config Values");
                fs.Close();
                return;
            }

            //            xml = new XmlDocument();

            try
            {
                //                xml.Load(reader);
                if (xml == null)
                    return;

                xvar = xml.SelectSingleNode("//KaboomkinSettings/HealBot");
                if (xvar != null)
                {
                    HealBot = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + HealBot.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/HealingMode");
                if (xvar != null)
                {
                    HealingMode = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + HealingMode.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/EatAt");
                if (xvar != null)
                {
                    EatAt = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + EatAt.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/DrinkAt");
                if (xvar != null)
                {
                    DrinkAt = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + DrinkAt.ToString());
                }
                xvar = xml.SelectSingleNode("//KaboomkinSettings/isTank");
                if (xvar != null)
                {
                    isTank = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + isTank.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/HealingTouch");
                if (xvar != null)
                {
                    HealingTouch = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + HealingTouch.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Rejuvenation");
                if (xvar != null)
                {
                    Rejuvenation = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Rejuvenation.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Rejuv_HL");
                if (xvar != null)
                {
                    Rejuv_HL = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Rejuv_HL.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Swiftmend_HL");
                if (xvar != null)
                {
                    Swiftmend_HL = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Swiftmend_HL.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Nourish_HL");
                if (xvar != null)
                {
                    Nourish_HL = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Nourish_HL.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Regrowth_HL");
                if (xvar != null)
                {
                    Regrowth_HL = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Regrowth_HL.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Lifebloom_HL");
                if (xvar != null)
                {
                    Lifebloom_HL = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Lifebloom_HL.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Innervate_HL");
                if (xvar != null)
                {
                    Innervate_HL = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Innervate_HL.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Tranquility");
                if (xvar != null)
                {
                    Tranquility = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Tranquility.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Num_TargetsTranquility");
                if (xvar != null)
                {
                    Num_TargetsTranquility = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Num_TargetsTranquility.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/use_Tranquility");
                if (xvar != null)
                {
                    use_Tranquility = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + use_Tranquility.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/abolishPosin");
                if (xvar != null)
                {
                    abolishPosin = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + abolishPosin.ToString());
                }


                xvar = xml.SelectSingleNode("//KaboomkinSettings/removeCurse");
                if (xvar != null)
                {
                    removeCurse = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + removeCurse.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/RaidRotation");
                if (xvar != null)
                {
                    RaidRotation = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + RaidRotation.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Inntervate_Bal");
                if (xvar != null)
                {
                    Inntervate_Bal = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Inntervate_Bal.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/LowMana");
                if (xvar != null)
                {
                    LowMana = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + LowMana.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/HighMana");
                if (xvar != null)
                {
                    HighMana = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + HighMana.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Huricane_Adds");
                if (xvar != null)
                {
                    Huricane_Adds = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Huricane_Adds.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/WildGrowth");
                if (xvar != null)
                {
                    WildGrowth = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + WildGrowth.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Num_TargetsWildGrowth");
                if (xvar != null)
                {
                    Num_TargetsWildGrowth = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Num_TargetsWildGrowth.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/use_WildGrowth");
                if (xvar != null)
                {
                    use_WildGrowth = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + use_Tranquility.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/FeralCharge");
                if (xvar != null)
                {
                    FeralCharge = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + FeralCharge.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/NoBear");
                if (xvar != null)
                {
                    NoBear = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + NoBear.ToString());
                }

                
                xvar = xml.SelectSingleNode("//KaboomkinSettings/PouncePull");
                if (xvar != null)
                {
                    PouncePull = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + PouncePull.ToString());
                }
                
                xvar = xml.SelectSingleNode("//KaboomkinSettings/HealingTouch_HL");
                if (xvar != null)
                {
                    HealingTouch_HL = Convert.ToInt32(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + HealingTouch_HL.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/MarkOfTheWild");
                if (xvar != null)
                {
                    MarkOfTheWild = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + MarkOfTheWild.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/GiftOfTheWild");
                if (xvar != null)
                {
                    GiftOfTheWild = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + GiftOfTheWild.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Revive");
                if (xvar != null)
                {
                    Revive = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Revive.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/Rebirth");
                if (xvar != null)
                {
                    Rebirth = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + Rebirth.ToString());
                }

                xvar = xml.SelectSingleNode("//KaboomkinSettings/ThornsTank");
                if (xvar != null)
                {
                    ThornsTank = Convert.ToBoolean(xvar.InnerText);
                    Logging.WriteDebug("   cfg:  " + xvar.Name + "=" + ThornsTank.ToString());
                }

            }
            catch (Exception e)
            {
                Logging.WriteDebug("PROJECTE EXCEPTION, STACK=" + e.StackTrace);
                Logging.WriteDebug("PROJECTE EXCEPTION, SRC=" + e.Source);
                Logging.WriteDebug("PROJECTE : " + e.Message);
            }
        }

        public void Save()
        {
            XmlDocument xml;
            XmlElement root;
            XmlElement element;
            XmlText text;
            XmlComment xmlComment;

            string sPath = Process.GetCurrentProcess().MainModule.FileName;
            sPath = Path.GetDirectoryName(sPath);

            sPath = Path.Combine(sPath, _cfgFile);

            if (!Directory.Exists(sPath))
            {
                Logging.WriteDebug("Creating config directory");
                Directory.CreateDirectory(sPath);
            }

            String serverName = Lua.GetReturnVal<string>("return GetRealmName()", 0);
            String toonName = ObjectManager.Me.Name;

            sPath = Path.Combine(sPath, "Kaboomkin-" + serverName + "-" + toonName + ".config");


            //((Warlock)Global.CurrentCC).slog("");
            //Logging.Write("");

            Logging.WriteDebug("Saving config file");
            xml = new XmlDocument();
            XmlDeclaration dc = xml.CreateXmlDeclaration("1.0", "utf-8", null);
            xml.AppendChild(dc);

            xmlComment = xml.CreateComment(
                "=======================================================================\n" +
                serverName.ToUpper() + "-" + toonName.ToUpper() +
                ".CONFIG  -  This is the Config File For Kaboomkin\n\n" +
                "XML file containing settings to customize the the Kaboomkin CC\n" +
                "It is STRONGLY recommended you use the Configuration UI to change this\n" +
                "file instead of direct changein it here.\n" +
                "========================================================================");

            //let's add the root element
            root = xml.CreateElement("KaboomkinSettings");
            root.AppendChild(xmlComment);

            //let's add another element (child of the root)
            element = xml.CreateElement("HealBot");
            text = xml.CreateTextNode(HealBot.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("HealingMode");
            text = xml.CreateTextNode(HealingMode.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("EatAt");
            text = xml.CreateTextNode(EatAt.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("DrinkAt");
            text = xml.CreateTextNode(DrinkAt.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("isTank");
            text = xml.CreateTextNode(isTank.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("HealingTouch");
            text = xml.CreateTextNode(HealingTouch.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Rejuvenation");
            text = xml.CreateTextNode(Rejuvenation.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Rejuv_HL");
            text = xml.CreateTextNode(Rejuv_HL.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Swiftmend_HL");
            text = xml.CreateTextNode(Swiftmend_HL.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Nourish_HL");
            text = xml.CreateTextNode(Nourish_HL.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Regrowth_HL");
            text = xml.CreateTextNode(Regrowth_HL.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Lifebloom_HL");
            text = xml.CreateTextNode(Lifebloom_HL.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Innervate_HL");
            text = xml.CreateTextNode(Innervate_HL.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("removeCurse");
            text = xml.CreateTextNode(removeCurse.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("abolishPosin");
            text = xml.CreateTextNode(abolishPosin.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Tranquility");
            text = xml.CreateTextNode(Tranquility.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Num_TargetsTranquility");
            text = xml.CreateTextNode(Num_TargetsTranquility.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("use_Tranquility");
            text = xml.CreateTextNode(use_Tranquility.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("RaidRotation");
            text = xml.CreateTextNode(RaidRotation.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Inntervate_Bal");
            text = xml.CreateTextNode(Inntervate_Bal.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("LowMana");
            text = xml.CreateTextNode(LowMana.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("HighMana");
            text = xml.CreateTextNode(HighMana.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Huricane_Adds");
            text = xml.CreateTextNode(Huricane_Adds.ToString());
            element.AppendChild(text);
            root.AppendChild(element);



            //let's add another element (child of the root)
            element = xml.CreateElement("WildGrowth");
            text = xml.CreateTextNode(WildGrowth.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Num_TargetsWildGrowth");
            text = xml.CreateTextNode(Num_TargetsWildGrowth.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("use_WildGrowth");
            text = xml.CreateTextNode(use_WildGrowth.ToString());
            element.AppendChild(text);
            root.AppendChild(element);
            
            //let's add another element (child of the root)
            element = xml.CreateElement("FeralCharge");
            text = xml.CreateTextNode(FeralCharge.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("NoBear");
            text = xml.CreateTextNode(NoBear.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("PouncePull");
            text = xml.CreateTextNode(PouncePull.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("HealingTouch_HL");
            text = xml.CreateTextNode(HealingTouch_HL.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("GiftOfTheWild");
            text = xml.CreateTextNode(GiftOfTheWild.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("MarkOfTheWild");
            text = xml.CreateTextNode(MarkOfTheWild.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Revive");
            text = xml.CreateTextNode(Revive.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("Rebirth");
            text = xml.CreateTextNode(Rebirth.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            //let's add another element (child of the root)
            element = xml.CreateElement("ThornsTank");
            text = xml.CreateTextNode(ThornsTank.ToString());
            element.AppendChild(text);
            root.AppendChild(element);

            xml.AppendChild(root);

            //let's try to save the XML document in a file: C:\pavel.xml
            System.IO.FileStream fs = new System.IO.FileStream(@sPath, System.IO.FileMode.Create,
                                                               System.IO.FileAccess.Write);
            try
            {
                xml.Save(fs); //I've chosen the c:\ for the resulting file pavel.xml
                fs.Close();
            }
            catch (Exception e)
            {
                Logging.Write(e.Message);
            }

        }
    }
}
