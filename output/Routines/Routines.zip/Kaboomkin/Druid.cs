﻿using System.Linq;
using System.Windows.Forms;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
//using System.Windows.Forms;

#pragma warning disable

namespace Kaboomkin
{
    partial class Druid : CombatRoutine
    {
        private Form _myForm;
        public Form ConfigForm
        {
            get
            {
                if (_myForm == null)
                    _myForm = new KaboomkinConfig();

                return _myForm;
            }
        }

        public override bool WantButton
        {
            get
            {
                return true;
            }
        }

       /* public string ButtonText
        {
            get
            {
                return "Kaboomkin Config";
            }
        }
        */
        public override void OnButtonPress()
        {
            ConfigForm.ShowDialog();
        }
        
        public override WoWClass Class { get { return WoWClass.Druid; } }
        public override sealed string Name { get { return "Kaboomkin v2.3 Final"; } }
        private static LocalPlayer Me { get { return ObjectManager.Me; } }
        public static KaboomkinSet _settings = new KaboomkinSet();
        private static void slog(string format, params object[] args) //use for logging
        {
            Logging.Write(format, args);
        }
        CC_TalentGroup primaryTalents = new CC_TalentGroup();
        CC_TalentGroup secondaryTalents = new CC_TalentGroup();
        private bool _CCLoaded = false;
        public bool OOM_Mode = false;
        public bool runpulse = true;
        public static string LastCast;
        Stopwatch _CheetaTimer = new Stopwatch();
        #region Pulse


        private WoWPlayer RaFLeaderOverride = Me;
        public override void Pulse()
        {
            try
            {
                //Checks to fix crashes	
                if (!ObjectManager.IsInGame || Me == null || !Me.IsValid)
                {
                    LoadingScreen = true;
                    Thread.Sleep(1000);
                    return;
                }

                if (LoadingScreen)
                {
                    Thread.Sleep(2000);
                    LoadingScreen = false;
                }

                if ((IsBattleGround() && Battlegrounds.Finished))
                {
                    return;
                }

                if (!IsBattleGround())
                {
                    FollowTarget = null;
                    followingFlagCarrier = false;
                }

                if (primaryTalents.IsActiveGroup())
                {
                    activeGrp = primaryTalents;
                    inactiveGrp = secondaryTalents;
                }
                else
                {
                    inactiveGrp = primaryTalents;
                    activeGrp = secondaryTalents;
                }

                string sSpecType = activeGrp._tabName[activeGrp.Spec()];
                if (activeGrp.Spec() == 1)
                    eType = DruidType.Balance;
                else if (activeGrp.Spec() == 2)
                    eType = DruidType.Feral;
                else if (activeGrp.Spec() == 3)
                    eType = DruidType.Restoration;
                else
                {
                    eType = DruidType.None;
                    sSpecType = "Undefined";
                }		
  
                // Party buffs pulsing
                if (Me != null && Me.IsValid && !Me.Combat && Me.HealthPercent > 1)
                {
                    Wandon = false;
                    Dispel();

                    if (Me != null && Me.IsValid && Me.Auras.ContainsKey("Preparation"))
                    {
                        if (Battlegrounds.GetCurrentBattleground() == BattlegroundType.WSG)
                        {
                            if (Me != null && Me.IsValid && Me.RaidMembers.Count == 10 && Me.Auras.ContainsKey("Preparation"))
                            {
                                partyBuff(_partyBuffs);
                            }
                        }
                        else if (Battlegrounds.GetCurrentBattleground() == BattlegroundType.AV || Battlegrounds.GetCurrentBattleground() == BattlegroundType.IoC)
                        {
                            if (Me != null && Me.IsValid && Me.RaidMembers.Count == 40 && Me.Auras.ContainsKey("Preparation"))
                            {
                                partyBuff(_partyBuffs);
                            }
                        }
                        else
                        {
                            if (Me != null && Me.IsValid && Me.RaidMembers.Count == 15 && Me.Auras.ContainsKey("Preparation"))
                            {
                                partyBuff(_partyBuffs);
                            }
                        }
                    }

                    if (Me != null && Me.IsValid && !Me.Dead && IsInPartyOrRaid() && !IsBattleGround())
                    {
                        partyBuff(_partyBuffs);
                    }
                }

                // Healbot Pulsing
                if ((eType == Druid.DruidType.Restoration) && Me != null && Me.IsValid && Me.Level >= 10)
                {
                    if (IsBattleGround())
                        HealbotPvP();
                    else
                        Healbot();
                }
            }
            catch (System.Threading.ThreadAbortException) { throw; }
            catch (Exception c)
            {
                Log("An Exception occured. Check debug log for details.");
               slog("{0}", c);
            }
        }

        private void partyBuff(Dictionary<SpellPriority, CastRequirements> buffs)
        {
            var tempBuffQueue = new Queue<WoWSpell>();

            List<WoWPlayer> playerList = new List<WoWPlayer>();

            if (Me.RaidMembers.Count > 0)
            {
                foreach (WoWPlayer p in Me.RaidMembers)
                {
                    playerList.Add(p);
                }
            }
            else
            {
                foreach (WoWPlayer p in Me.PartyMembers)
                {
                    playerList.Add(p);
                }
            }

            foreach (WoWPlayer player in playerList)
            {
                if (player == null || !player.IsValid)
                    continue;

                if (Me != null && ObjectManager.IsInGame && player != Me && !Me.Combat && !player.IsAlive && !IsBattleGround() && CanCast("Revive"))
                {
                    while (ObjectManager.IsInGame && Me != null && Me.IsValid && !Me.Combat && (player.Distance > 27 || !player.InLineOfSight))
                    {
                        WoWPoint movePoint = player.Location;
                        Navigator.MoveTo(movePoint);
                        Thread.Sleep(100);
                    }
                    WoWMovement.MoveStop();
                    Thread.Sleep(250);
                    Log("Resurrecting '{0}'", player.Name);
                    SpellManagerEx.Cast("Revive", player);
                    Thread.Sleep(250);
                    while (Me.HealthPercent > 1 && (Me.IsCasting || Me.ChanneledCasting > 0 || SpellManager.GlobalCooldown))
                    {
                        if (!ObjectManager.IsInGame || Me == null || player == null)
                            return;

                        if (player != null && player.HealthPercent > 1)
                        {
                            Lua.DoString("SpellStopCasting()");
                            Thread.Sleep(100);
                        }

                        Thread.Sleep(50);
                    }
                    Thread.Sleep(250);
                }

                if (player.Distance > 27 || !player.InLineOfSight) continue;

                if (!Me.Combat && player.HealthPercent > 1)
                {

                    foreach (var s in buffs)
                    {
                        if (s.Value.Invoke(player))
                        {
                            if (SpellManager.KnownSpells.ContainsKey(s.Key.Name))
                                tempBuffQueue.Enqueue(SpellManager.KnownSpells[s.Key.Name]);

                            if (tempBuffQueue.Count > 0)
                                break;
                        }
                    }

                   if (Me.HealthPercent > 1 && tempBuffQueue.Count > 0 && !Me.Combat)
					{
						Log("Buffing '{0}'", tempBuffQueue.Peek().Name);
						SpellManagerEx.Cast(tempBuffQueue.Dequeue().Name, player);
						Thread.Sleep(250);
						while (Me.HealthPercent > 1 && (Me.IsCasting || Me.ChanneledCasting > 0 || SpellManager.GlobalCooldown))
						{
							if (!ObjectManager.IsInGame || Me == null)
								return;						
							Thread.Sleep(50);
						}
						Thread.Sleep(250);
					}
                        }
                    }
                }



        public class player
        {
            public WoWUnit pUnit;
            public double pHP;
            public player(WoWUnit pUnit, double pHP)
            {
                this.pUnit = pUnit;
                this.pHP = pHP;
            }
        }

        private static void CheckForHeal(Dictionary<SpellPriority, CastRequirements> heals)
        {
            var tempHealQueue = new Queue<WoWSpell>();

            List<player> playerList = new List<player>();


            if (Me.PartyMembers.Count > 0)
            {
                if (eType == Druid.DruidType.Restoration)
                {
                    foreach (WoWPlayer p in Me.PartyMembers)
                    {
                        if (p != null && p.IsValid && p.Distance < 60 && p.HealthPercent > 1)
                        {
                            playerList.Add(new player(p, p.HealthPercent));

                            if (p.GotAlivePet)
                                playerList.Add(new player(p.Pet, 100));
                        }
                    }
                }
                else if (!IsBattleGround())
                {
                    foreach (WoWPlayer p in Me.PartyMembers)
                    {
                        if (p != null && p.IsValid && p.Distance < 60 && p.HealthPercent > 1)
                        {
                            playerList.Add(new player(p, p.HealthPercent));

                            if (p.GotAlivePet)
                                playerList.Add(new player(p.Pet, 100));
                        }
                    }
                }
            }

            if (playerList.Count > 1)
            {
                playerList.Sort(delegate(player p1, player p2)
                { return p1.pHP.CompareTo(p2.pHP); });
            }

            // List Overrides to put ourself, followtarget and tank to the top of the heal list
            if (FollowTarget != null && FollowTarget.IsValid && FollowTarget.HealthPercent > 1 && FollowTarget.HealthPercent <= 60)
                playerList.Insert(0, new player(FollowTarget, FollowTarget.HealthPercent));

            if (RaFHelper.Leader != null && RaFHelper.Leader.IsValid && RaFHelper.Leader.HealthPercent > 1 && RaFHelper.Leader.HealthPercent <= 60)
                playerList.Insert(0, new player(RaFHelper.Leader, RaFHelper.Leader.HealthPercent));

            if (Me.HealthPercent > 1 && Me.HealthPercent <= 70)
                playerList.Insert(0, new player(Me, Me.HealthPercent));
            else if (Me.HealthPercent > 1)
                playerList.Add(new player(Me, Me.HealthPercent));
            //

            var items = (from k in heals.Keys
                         orderby k.Priority ascending
                         select k);


            foreach (player p in playerList)
            {
                if (p.pUnit == null || !p.pUnit.IsValid)
                    continue;

                foreach (var s in items)
                {
                    if (heals[s].Invoke(p.pUnit))
                    {
                        if (SpellManager.KnownSpells.ContainsKey(s.Name))
                        {
                            tempHealQueue.Enqueue(SpellManager.KnownSpells[s.Name]);
                        }

                        if (tempHealQueue.Count > 0)
                        {
                            HealTarget = p.pUnit;
                            HealSpell = tempHealQueue.Peek().Name;
                            tempHealQueue.Clear();
                            return;
                        }
                    }
                }
            }
            HealTarget = null;
            HealSpell = null;
        }

        public override void Heal()
        {
            if (Me.Shapeshift != ShapeshiftForm.TreeOfLife && SpellManagerEx.CanCast("Tree of Life") && !Me.Mounted)
            {
                slog("Going Tree");
                CastNowSpell("Tree of Life");
            }
            while (ObjectManager.IsInGame && Me != null && Me.IsValid && HealTarget != null && (HealTarget.Distance >= 35 || !HealTarget.InLineOfSight))
            {
                WoWPoint movePoint;

                if (HealTarget.InLineOfSight)
                {
                    movePoint = WoWMovement.CalculatePointFrom(HealTarget.Location, 30);
                }
                else
                {
                    movePoint = HealTarget.Location;
                }

                Navigator.MoveTo(movePoint);
                Thread.Sleep(100);
            }

            if (SpellManager.KnownSpells[HealSpell].CastTime > 0 || HealSpell == "Penance")
            {
                WoWMovement.MoveStop();
                Thread.Sleep(100);
            }

            Wandon = false;

            if (HealTarget == Me)
                Log("Casting '{0}' on self", HealSpell);
            else
                Log("Casting '{0}' on '{1}'", HealSpell, HealTarget.Name);

            SpellManagerEx.Cast(HealSpell, HealTarget);

            if (SpellManager.KnownSpells[HealSpell].CastTime > 0 || HealSpell == "Penance")
                Thread.Sleep(250);

            while (Me.HealthPercent > 1 && (Me.IsCasting || Me.ChanneledCasting > 0 || SpellManager.GlobalCooldown))
            {
                if (!ObjectManager.IsInGame || Me == null)
                    return;

                Thread.Sleep(50);
            }
            Thread.Sleep(250);
        }

        public void Dispel()
        {
            List<WoWUnit> playerList = new List<WoWUnit>();

            if (Me.RaidMembers.Count > 0)
            {
                if (eType == Druid.DruidType.Restoration)
                {
                    foreach (WoWPlayer p in Me.RaidMembers)
                    {
                        if (p != null && p.IsValid && p.Distance < 60 && p.HealthPercent > 1)
                        {
                            playerList.Add(p);
                            
                            if (p.GotAlivePet)
                                playerList.Add(p.Pet);
                        }
                    }
                }
            }
            else if (Me.PartyMembers.Count > 0)
            {
                if (eType == Druid.DruidType.Restoration)
                {
                    foreach (WoWPlayer p in Me.PartyMembers)
                    {
                        if (p != null && p.IsValid && p.Distance < 60 && p.HealthPercent > 1)
                        {
                            playerList.Add(p);

                            if (p.GotAlivePet)
                                playerList.Add(p.Pet);
                        }
                    }
                }
                else if (!IsBattleGround())
                {
                    foreach (WoWPlayer p in Me.PartyMembers)
                    {
                        if (p != null && p.IsValid && p.Distance < 60 && p.HealthPercent > 1)
                        {
                            playerList.Add(p);

                            if (p.GotAlivePet)
                                playerList.Add(p.Pet);
                        }
                    }
                }
            }

            playerList.Add(Me);

            foreach (WoWUnit p in playerList)
            {
                if (p == null || !p.IsValid)
                    continue;

                if (p.Distance < 37 && p.InLineOfSight)
                {
                    foreach (KeyValuePair<string, WoWAura> pair in p.Debuffs)
                    {

                        if (pair.Value.Spell.DispelType == WoWDispelType.Curse && Druid._settings.removeCurse && SpellManager.CanCastSpell("Remove Curse"))
                        {
                            Wandon = false;

                            if (p == Me)
                                Log("Decursing '{0}' from self", pair.Key);
                            else
                                Log("Decursing '{0}' from '{1}'", pair.Key, p.Name);

                            SpellManagerEx.Cast("Remove Curse", p);
                            Thread.Sleep(250);
                            return;
                        }

                        if (pair.Value.Spell.DispelType == WoWDispelType.Poison && Druid._settings.abolishPosin && !p.Buffs.ContainsKey("Abolish Poison") && SpellManagerEx.CanCast("Abolish Poison"))
                        {
                            Wandon = false;

                            if (CanCast("Abolish Poison"))
                            {
                                if (p == Me)
                                    Log("Abolish Poison '{0}' from self", pair.Key);
                                else
                                    Log("Abolish Poison '{0}' from '{1}'", pair.Key, p.Name);

                                SpellManagerEx.Cast("Abolish Poison", p);
                                Thread.Sleep(250);
                            }


                            Thread.Sleep(250);
                            return;
                        }

                    }
                }
            }
        }

        #endregion


        enum DruidType
        {
            None,
            Balance,
            Feral,
            Restoration
        };

        static DruidType eType = DruidType.None;



		CC_TalentGroup activeGrp;
		CC_TalentGroup inactiveGrp;

        public Druid()
        {
            if (Me.Class == WoWClass.Druid)
            {


                if (_CCLoaded)
                {
                    return;
                }


                Logging.Write("");
                Logging.Write("");
                Logging.Write("LOADED:  " + Name);
                Logging.Write("Spec Detection Test.");


                primaryTalents.Load(1);
                secondaryTalents.Load(2);

                if (primaryTalents.IsActiveGroup())
                {
                    activeGrp = primaryTalents;
                    inactiveGrp = secondaryTalents;
                }
                else
                {
                    inactiveGrp = primaryTalents;
                    activeGrp = secondaryTalents;
                }

                string sSpecType = activeGrp._tabName[activeGrp.Spec()];
                if (activeGrp.Spec() == 1)
                    eType = DruidType.Balance;
                else if (activeGrp.Spec() == 2)
                    eType = DruidType.Feral;
                else if (activeGrp.Spec() == 3)
                    eType = DruidType.Restoration;
                else
                {
                    eType = DruidType.None;
                    sSpecType = "Undefined";
                }





                if (Me.Level < 10)
                {
                    slog("You are < level 10. You don't have any talent points");

                }
                else
                {
                    switch (eType)
                    {
                        case Druid.DruidType.Balance:
                            slog("Balance");
                            break;

                        case Druid.DruidType.Feral:
                            slog("Feral Combat");
                            break;

                        case Druid.DruidType.Restoration:
                            slog("Restoration");
                            break;

                        case Druid.DruidType.None:
                            slog("-------------------------------------");
                            slog("-------- Your Have No Talents--------");
                            slog("-------------------------------------");
                            slog("-----Using 1 - 10 Combat Routine-----");
                            slog("-------------------------------------");
                            break;
                    }
                }



                _CCLoaded = true;

                Logging.Write("");
                Logging.Write("");
            }

        }
        public class CC_TalentGroup
        {


            public string[] _tabName = new string[4];
            public int[] _tabPoints = new int[4];
            public int _idxGroup;

            public int totalPoints
            {
                get
                {
                    int nPoints = 0;
                    for (int iTab = 1; iTab <= 3; iTab++)
                    {
                        nPoints += _tabPoints[iTab];
                    }

                    return nPoints;
                }
            }

            public int Spec()
            {
                int nSpec = 0;
                if (_tabPoints[1] >= (_tabPoints[2] + _tabPoints[3]))
                    nSpec = 1;
                else if (_tabPoints[2] >= (_tabPoints[1] + _tabPoints[3]))
                    nSpec = 2;
                else if (_tabPoints[3] >= (_tabPoints[1] + _tabPoints[2]))
                    nSpec = 3;

                return nSpec;
            }

            public CC_TalentGroup()
            {
            }

            ~CC_TalentGroup()
            {
            }

            public bool Load(int nGroup)
            {
                int nTab;

                _idxGroup = nGroup;

                for (nTab = 1; nTab <= 3; nTab++)
                {
                    Lua.DoString("readTabName, __, readTabPointsSpent, __, __ = GetTalentTabInfo(" + nTab + ",false,false," + _idxGroup + ")");
                    _tabName[nTab] = Lua.GetLocalizedText("readTabName", Me.BaseAddress);
                    _tabPoints[nTab] = Lua.GetLocalizedInt32("readTabPointsSpent", Me.BaseAddress);
                }

                return false;
            }

            public bool IsActiveGroup()
            {
                return GetActiveGroup() == _idxGroup;
            }

            public int GetActiveGroup()
            {
                Lua.DoString("activeTalentGroup = GetActiveTalentGroup(false,false)");
                int nActiveGroup = Lua.GetLocalizedInt32("activeTalentGroup", Me.BaseAddress);
                return nActiveGroup;
            }

            public void ActivateGroup()
            {
                Lua.DoString("SetActiveTalentGroup(" + _idxGroup + ")");
            }

            public int GetNumGroups()
            {
                Lua.DoString("numTalentGroups = GetNumTalentGroups(false,false)");
                int cntGroup = Lua.GetLocalizedInt32("numTalentGroups", Me.BaseAddress);
                return cntGroup;
            }
        }
        #region CC_Begin
        private bool WasHealCast = false;
        WoWPlayer playerWithLowestHealth = null;
        List<WoWPlayer> playersToRez = null;


        public override bool NeedRest
        {
            get
            {
                if (Druid._settings.HealBot)
                {

                    return false;
                }
                if (Me.HealthPercent < Druid._settings.EatAt && !Me.Mounted)
                {
                    return true;
                }
                if (Me.ManaPercent < Druid._settings.DrinkAt && !Me.Mounted)
                {
                    return true;
                }
                if (!Me.Buffs.ContainsKey("Mark of the Wild") && !Me.Buffs.ContainsKey("Gift of the Wild") && SpellManager.CanCastSpell("Mark of the Wild") && !Me.Mounted)
                {
                    slog("Need Mark of the Wild");
                    return true;
                }
                if (!Me.Buffs.ContainsKey("Thorns") && SpellManager.CanCastSpell("Thorns") && !Me.Mounted)
                {
                    slog("Need Thorns");
                    return true;
                }
                return false;
            }
        }

        public override void Rest()
        {
                //xxAhzz: Added Rejuvination during Rest
                if ((Me.HealthPercent < Druid._settings.Rejuvenation) && !Me.Buffs.ContainsKey("Rejuvenation") && !Me.Mounted)
                {
                    slog("Casting Rejuvenation");
                    Me.Target();
                    CastNowSpell("Rejuvenation");
                    Me.ClearTarget();
                }
            if (Me.HealthPercent < Druid._settings.EatAt && !Me.Mounted)
            {

                CastNowSpell("Healing Touch");


            }
            if (Me.ManaPercent < Druid._settings.DrinkAt && !Me.Mounted)
            {
                Styx.Logic.Common.Rest.Feed();

            }
            if (!Me.Buffs.ContainsKey("Mark of the Wild") && !Me.Buffs.ContainsKey("Gift of the Wild") && SpellManager.CanCastSpell("Mark of the Wild") && !Me.Mounted)
            {

                Me.Target();
                CastNowSpell("Mark of the Wild");
                Me.ClearTarget();
            }
            if (!Me.Buffs.ContainsKey("Thorns") && SpellManager.CanCastSpell("Thorns") && !Me.Mounted)
            {
                slog("Casting Thorns");
                Me.Target();
                CastNowSpell("Thorns");
                Me.ClearTarget();
            }
        }

        #endregion

        #region Pull

        public override void Pull()
        {
            if (!InstanceBuddyEnabled() && Me.CurrentTarget == null && IsInPartyOrRaid() && RaFHelper.Leader.CurrentTarget != null)
            {
                RaFHelper.Leader.CurrentTarget.Target();
            }
            if (Me.CurrentTarget != null)
            {
                isCaster = false;                               //xxAhzz: Added Caster check for use in combat
                isCaster = TargetIsCaster(Me.CurrentTarget);    //xxAhzz: 
                if (eType == Druid.DruidType.Restoration)
                {
                    Combat();
                }
                if (!IsInPartyOrRaid() && !Me.CurrentTarget.Aggro && !Me.CurrentTarget.IsPlayer)
                {

                    List<WoWUnit> MadList = ObjectManager.GetObjectsOfType<WoWUnit>(false).FindAll(unit =>
                                                                                                   unit.Guid != Me.Guid &&
                                                                                                   unit.Aggro);
                    if (MadList.Count > 0)
                    {
                        Lua.DoString("RunMacroText(\"/stopcasting\")");
                        slog("The Thing targeting is not Mad at me, but something Else is Targeting that.");
                        MadList[0].Target();

                    }

                }
                if (Me.Level < 10)
                {
                    PullLow();
                }
                switch (eType)
                {
                    case Druid.DruidType.Balance:
                        PullBalance();
                        break;

                    case Druid.DruidType.Feral:
                        PullFeral();
                        break;

                    case Druid.DruidType.Restoration:
                        Combat();
                        break;


                }
            }
        }


        #endregion

        #region Pull Buffs

        public override bool NeedPullBuffs { get { return false; } }

        public override void PullBuff() { }

        #endregion

        #region Pre Combat Buffs

        public override bool NeedPreCombatBuffs { get { return false; } }

        public override void PreCombatBuff()
        {
            return;
        }

        #endregion

        #region Combat Buffs

        public override bool NeedCombatBuffs { get { return false; } }

        public override void CombatBuff()
        {

        }

        #endregion

        #region Heal

        public override bool NeedHeal { get { return false; } }



        #endregion

        #region Falling

        public void HandleFalling() { }

        #endregion

        #region Combat

        public override void Combat()
        {
            if (!InstanceBuddyEnabled() && Me.CurrentTarget == null && IsInPartyOrRaid() && RaFHelper.Leader.CurrentTarget != null)
            {
                RaFHelper.Leader.CurrentTarget.Target();
            }
			
            if (Me.CurrentTarget != null)
            {

                if (!IsInPartyOrRaid() && !Me.CurrentTarget.Aggro && !Me.CurrentTarget.IsPlayer)
                {
                    List<WoWUnit> MadList = ObjectManager.GetObjectsOfType<WoWUnit>(false).FindAll(unit =>
                                                                                                   unit.Aggro);
                    if (MadList.Count > 0)
                    {
                        Lua.DoString("RunMacroText(\"/stopcasting\")");
                        slog("The Thing targeting is not Mad at me, but something Else is Targeting that.");
                        MadList[0].Target();
                    }
                }
				
                if (Me.Level < 10)
                {
                    CombatLow();
                }
                switch (eType)
                {
                    case Druid.DruidType.Balance:
                        CombatBalance();
                        break;

                    case Druid.DruidType.Feral:
                        if (Druid._settings.isTank)
                        {
                            BearTank();
                        }
                        else
                        {
                            CatDps();
                        }
                        break;
                }
            }
        }

        #endregion


        #region Spells
        private readonly Queue<WoWSpell> _rotation = new Queue<WoWSpell>();

        private void Enqueue(Dictionary<SpellPriority, CastRequirements> spellrotation, int maxQueueSize)
        {

            if (_rotation != null)
            {
                var items = from k in spellrotation.Keys
                            orderby k.Priority descending
                            select k;

                foreach (var s in items)
                {
                    if (Me.CurrentTarget != null)
                    {
                        if (spellrotation[s].Invoke(Me.CurrentTarget))
                        {
                            if (SpellManager.KnownSpells.ContainsKey(s.Name))
                            {
                                _rotation.Enqueue(SpellManager.KnownSpells[s.Name]);
                            }

                            if (_rotation.Count == maxQueueSize)
                                break;
                        }
                    }
                    else
                    {
                        if (spellrotation[s].Invoke(Me.CurrentTarget))
                        {
                            if (SpellManager.KnownSpells.ContainsKey(s.Name))
                            {
                                _rotation.Enqueue(SpellManager.KnownSpells[s.Name]);
                            }

                            if (_rotation.Count == maxQueueSize)
                                break;
                        }
                    }
                }
            }
        }

        private void Cast()
        {
            if (Me.CurrentTarget != null)
            {
                if (_rotation != null)
                {
                    if (_rotation.Count > 0)
                    {
                        if (!string.IsNullOrEmpty(_rotation.Peek().Name))
                        {
                            if (SpellManager.KnownSpells[_rotation.Peek().Name].CastTime > 0 || _rotation.Peek().Name == "Tranquility")
							{
                                WoWMovement.MoveStop();
								Thread.Sleep(100);
							}

                            if (Me.CurrentTarget != null && Me.CurrentTarget != Me)
                            {
                                Me.CurrentTarget.Face();
                                Thread.Sleep(100);
                            }

                            string CastSpell = _rotation.Peek().Name;
                            Log("Casting '{0}' on '{1}'", _rotation.Peek().Name, Me.CurrentTarget.Name);
                            SpellManagerEx.Cast(_rotation.Dequeue().Name);

                            if (SpellManager.KnownSpells[CastSpell].CastTime > 0)
                                StyxWoW.SleepForLagDuration();

                            StyxWoW.SleepForLagDuration();

                            while (Me.HealthPercent > 1 && (Me.IsCasting || Me.ChanneledCasting > 0 || SpellManager.GlobalCooldown))
                            {
                                if (!ObjectManager.IsInGame || Me == null)
                                    return;

                                WoWMovement.Face();
                                Thread.Sleep(50);
                            }

                            StyxWoW.SleepForLagDuration();

                            //slog("LastCast Was " + LastCast);
                            //LastCast = _rotation.Peek().Name;
                            //slog("Casting {0}", _rotation.Peek().Name);
                           
                        }
                    }
                }
            }
        }
        #endregion
        private void AutoAttack()
        {
            if (!Me.IsAutoAttacking)
            {
                Lua.DoString("StartAttack()");
            }

        }
        private WoWItem HaveItemCheck(List<uint> listId)
        {
            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false))
            {
                if (listId.Contains(item.Entry))
                {
                    return item;
                }
            }
            return null;
        }

    }

}
