﻿using System;
using System.Collections.Generic;
using System.Threading;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
namespace Kaboomkin
{
    public partial class Druid
    {
        private delegate bool CastRequirements(WoWUnit unit);
        private readonly Dictionary<SpellPriority, CastRequirements> _Lowpull = new Dictionary<SpellPriority, CastRequirements>
        { 
            {new SpellPriority("Wrath", 11), unit => SpellManager.CanCastSpell("Wrath") },
            //{new SpellPriority("Frostbolt", 10), unit => SpellManager.CanCastSpell("Frostbolt") && Mage._settings.Com_Low_Frostbolt},
            //{new SpellPriority("Arcane Missiles", 9), unit => SpellManager.CanCastSpell("Arcane Missiles") && Mage._settings.Com_Low_ArcMissiles}
        };
        private readonly Dictionary<SpellPriority, CastRequirements> _LowRotation = new Dictionary<SpellPriority, CastRequirements>
        { 
            //{new SpellPriority("Seal of Righteousness", 102), unit => SpellManager.CanCastSpell("Seal of Righteousness") && !Me.Buffs.ContainsKey("Seal of Righteousness")},
            {new SpellPriority("Healing Touch", 104), unit => SpellManager.CanCastSpell("Healing Touch") && Me.HealthPercent < 50},
           
            {new SpellPriority("Moonfire", 99), unit => SpellManager.CanCastSpell("Moonfire") && !Me.CurrentTarget.Buffs.ContainsKey("Moonfire")},
             {new SpellPriority("Entangling Roots", 100), unit => SpellManager.CanCastSpell("Entangling Roots") && !Me.CurrentTarget.Buffs.ContainsKey("Entangling Roots") && Me.CurrentTarget.HealthPercent > 30 && Me.CurrentTarget.Distance > 10},
            {new SpellPriority("Wrath", 11), unit => SpellManager.CanCastSpell("Wrath") },
            //{new SpellPriority("Frostbolt", 10), unit => SpellManager.CanCastSpell("Frostbolt") && Mage._settings.Com_Low_Frostbolt},
            //{new SpellPriority("Arcane Missiles", 9), unit => SpellManager.CanCastSpell("Arcane Missiles") && Mage._settings.Com_Low_ArcMissiles}
        };

        public void PullLow()
        {
            if (Me.CurrentTarget.Distance > 30)
            {
                return;
            }
            if (Me.CurrentTarget.Distance < 30)
            {
                Me.CurrentTarget.Face();
                Enqueue(_LowRotation, 1);
             
                if (_rotation.Count > 0)
                    Cast();

                Combat();

            }

            //Combat();
        }
        private void CombatLow()
        {
            if (!Me.Silenced)
            {
                if (Me.CurrentTarget != null)
                {


                    Common();

                    WoWMovement.MoveStop();
                    Enqueue(_LowRotation, 1);

                    if (_rotation.Count > 0)
                        Cast();

                    combatChecks();
                }
            }
        }
    }
}
