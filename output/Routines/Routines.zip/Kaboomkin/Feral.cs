﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
namespace Kaboomkin
{
    public partial class Druid
    {
        public bool multimob = false;
        public WoWPoint prevPrevSafePoint = new WoWPoint();
        public WoWPoint prevSafePoint = new WoWPoint();
        public WoWPoint safePoint = new WoWPoint();
        public WoWUnit oldAdd;
        WoWPoint noSpot = new WoWPoint();
        private static ulong lastGuid;
        private static Stopwatch fightTimer = new Stopwatch();
        //private static ulong pullGuid;
        private static Stopwatch pullTimer = new Stopwatch();
        private static Stopwatch moveTimer = new Stopwatch();

        //   public WoWPoint MobLocal = Me.CurrentTarget.Location;
        private readonly Dictionary<SpellPriority, CastRequirements> _FeralBear = new Dictionary<SpellPriority, CastRequirements>
        { 
            //xxAhzz: Added "healMana()" check for healing spells
            //xxAhzz: Will only cast a healing spell if it can shift back into bear form afterwards
            //xxAhzz: Set Growl to top for pulling non-casters
            {new SpellPriority("Growl", 102), unit => SpellManagerEx.CanCast("Growl") && !Me.Combat && !isCaster},
            {new SpellPriority("Healing Touch", 100), unit => healMana() && SpellManagerEx.CanCast("Healing Touch") && Me.HealthPercent < Druid._settings.HealingTouch },
            {new SpellPriority("Rejuvenation", 90), unit => healMana() && SpellManagerEx.CanCast("Rejuvenation") && !Me.Buffs.ContainsKey("Rejuvenation") && Me.HealthPercent < Druid._settings.Rejuvenation && LastCast == "None" },
            {new SpellPriority("Rejuvenation", 80), unit => healMana() && SpellManagerEx.CanCast("Rejuvenation") && LastCast == "Regrowth" },
            {new SpellPriority("Regrowth", 70), unit => healMana() && SpellManagerEx.CanCast("Regrowth") && Me.HealthPercent < Druid._settings.Rejuvenation && !Me.Buffs.ContainsKey("Regrowth") },

            // Bear DPS
            {new SpellPriority("Bear Form", 100), unit => SpellManagerEx.CanCast("Bear Form") && !SpellManagerEx.HasSpell("Dire Bear Form") && Me.Shapeshift != ShapeshiftForm.Bear && Me.ManaPercent > 2},
            {new SpellPriority("Dire Bear Form", 99), unit => SpellManagerEx.CanCast("Dire Bear Form") && Me.Shapeshift != ShapeshiftForm.DireBear && Me.ManaPercent > 2},
            {new SpellPriority("Growl", 98), unit => SpellManagerEx.CanCast("Growl") && !Me.Combat},
            {new SpellPriority("Maul", 11), unit => SpellManagerEx.CanCast("Maul") && Me.CurrentRage > 15}, // Only Maul if we have more than 15 rage.
            {new SpellPriority("Swipe (Bear)", 12), unit => SpellManagerEx.CanCast("Swipe (Bear)") && Me.CurrentRage > 10 && getAdds().Count > 1},
            {new SpellPriority("Demoralizing Roar", 13), unit => SpellManagerEx.CanCast("Demoralizing Roar") && Me.CurrentRage > 10 && !Me.CurrentTarget.Buffs.ContainsKey("Demoralizing Roar") && getAdds().Count > 1},
            {new SpellPriority("Faerie Fire (Feral)", 99), unit => SpellManagerEx.CanCast("Faerie Fire (Feral)") && !Me.CurrentTarget.Buffs.ContainsKey("Faerie Fire (Feral)") && Me.Combat },
            
        };
        private readonly Dictionary<SpellPriority, CastRequirements> _FeralCat = new Dictionary<SpellPriority, CastRequirements>
        { 
           //Special Thanks to Honorbuddy user Pios for providing the roation
           // Healing Spells.
            {new SpellPriority("Healing Touch", 100), unit => SpellManagerEx.CanCast("Healing Touch") && Me.HealthPercent < Druid._settings.HealingTouch },
            {new SpellPriority("Rejuvenation", 90), unit => SpellManagerEx.CanCast("Rejuvenation") && !Me.Buffs.ContainsKey("Rejuvenation") && Me.HealthPercent < Druid._settings.Rejuvenation && LastCast == "None" },
            {new SpellPriority("Rejuvenation", 80), unit => SpellManagerEx.CanCast("Rejuvenation") && LastCast == "Regrowth" },
            {new SpellPriority("Regrowth", 70), unit => SpellManagerEx.CanCast("Regrowth") && Me.HealthPercent < Druid._settings.Rejuvenation && !Me.Buffs.ContainsKey("Regrowth") },
           // Cat DPSs
		    {new SpellPriority("Cat Form", 100), unit => SpellManagerEx.CanCast("Cat Form") && Me.Shapeshift != ShapeshiftForm.Cat && Me.ManaPercent > 2},
            {new SpellPriority("Faerie Fire (Feral)", 99), unit => SpellManagerEx.CanCast("Faerie Fire (Feral)") && !Me.CurrentTarget.Buffs.ContainsKey("Faerie Fire (Feral)") && Me.Combat },
			{new SpellPriority("Mangle (Cat)", 99), unit => SpellManagerEx.CanCast("Mangle (Cat)") && !Me.CurrentTarget.Buffs.ContainsKey("Mangle (Cat)") },
			{new SpellPriority("Savage Roar", 99), unit => SpellManagerEx.CanCast("Savage Roar") && !Me.Buffs.ContainsKey("Savage Roar") },
			{new SpellPriority("Rake", 99), unit => SpellManagerEx.CanCast("Rake") && !Me.CurrentTarget.Buffs.ContainsKey("Rake") },
			{new SpellPriority("Tiger's Fury", 99), unit => SpellManagerEx.CanCast("Tiger's Fury")  && Me.Combat },
            {new SpellPriority("Shred", 90), unit => SpellManagerEx.CanCast("Shred") && Me.BehindTarget && Me.CurrentEnergy > 60},
			{new SpellPriority("Rip", 80), unit => SpellManagerEx.CanCast("Rip") && Me.CurrentEnergy > 30 && Me.ComboPoints >= 4 },
			// AOE yay!
			{new SpellPriority("Swipe (Cat)", 80), unit => SpellManagerEx.CanCast("Swipe (Cat)") && getAdds().Count > 1},
			// Claw should not be used, but since we solo, we will get mobs facing us.
			{new SpellPriority("Claw", 80), unit => SpellManagerEx.CanCast("Claw") && !Me.BehindTarget && Me.ComboPoints < 4 },
        };

        public void PullFeral()
        {
            if (Blacklist.Contains(Me.CurrentTarget.Guid))
            {
                slog("Target is blacklisted");
                Styx.Logic.Blacklist.Add(Me.CurrentTarget.Guid, System.TimeSpan.FromSeconds(30));
                Me.ClearTarget();
                //pullGuid = 0;
            }
            FindClostestPlayer(10);
            if (eType == Druid.DruidType.Feral && Druid._settings.PouncePull && !Me.Combat)
            {
                if (!IsCat() && Druid._settings.PouncePull)
                {
                    CastNowSpell("Cat Form");
                    CastNowSpell("Prowl");
                    if (Me.CurrentTarget.Distance <= 6 && SpellManagerEx.CanCast("Pounce"))
                    {
                        SpellManagerEx.Cast("Pounce");
                    }

                }
                else
            if (IsCat())
            {
                CastNowSpell("Prowl");
                if (Me.CurrentTarget.Distance <= 6 && SpellManagerEx.CanCast("Pounce"))
                {
                    SpellManagerEx.Cast("Pounce");
                }
            }
            else
                if (IsCat() && Me.Shapeshift == ShapeshiftForm.Stealth)
                {
                    if (Me.CurrentTarget.Distance <= 6 && SpellManagerEx.CanCast("Pounce"))
                    {
                        SpellManagerEx.Cast("Pounce");
                    }
                }
            }
            if (Me.CurrentTarget.Guid != lastGuid)
            {
                slog("Pull starting. Target is new");
                pullTimer.Reset();
                pullTimer.Start();
                lastGuid = Me.CurrentTarget.Guid;
                if (Me.CurrentTarget.IsPlayer)
                {
                    slog("Pull: Killing Player at distance " + Math.Round(Me.CurrentTarget.Distance).ToString() + "");
                }
                slog("Pull: Killing " + Me.CurrentTarget.Name + " at distance " + Math.Round(Me.CurrentTarget.Distance).ToString() + "");
                pullTimer.Reset();
                pullTimer.Start();
            }

            if (!Me.CurrentTarget.IsPlayer && Me.CurrentTarget.CurrentHealth > 95 && 90 * 1000 < pullTimer.ElapsedMilliseconds)
            {
                slog(" This " + Me.CurrentTarget.Name + " is a bugged mob.  Blacklisting for 1 hour.");
                Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));
                Me.ClearTarget();
                //pullGuid = 0;
                if (Me.Location.Distance(safePoint) >= 30)
                {
                    slog("Try to move to safePoint");
                    SafeMoveToPoint(safePoint, 10000);
                }
                else if (Me.Location.Distance(prevSafePoint) >= 30)
                {
                    slog("Try to move to prevSafePoint");
                    SafeMoveToPoint(prevSafePoint, 10000);
                }
                else if (Me.Location.Distance(prevPrevSafePoint) >= 30)
                {
                    slog("Try to move to prevPrevSafePoint");
                    SafeMoveToPoint(prevPrevSafePoint, 10000);
                }
                else
                {
                    slog("Can't move to locations");

                }
            }

            switch (DruidMode)
            {
                case CombatType.Bear:
                    BearTank();
                    break;
                case CombatType.Cat:
                    CatDps();
                    break;
                case CombatType.Moonkin:
                    CombatBalance();
                    break;

            }
           
            Lua.DoString("StartAttack()");
            slog("Pull done.");
            fightTimer.Reset();
            fightTimer.Start();
            return;
        }

        public void BearTank()
        {

            if (!Me.Silenced)
            {
                if (Me.CurrentTarget != null)
                {

                    //multimobs
                    if (multimob)
                    {
                        List<WoWUnit> HostleList = ObjectManager.GetObjectsOfType<WoWUnit>(false).FindAll(unit =>
    unit.Guid != Me.Guid &&
    !unit.IsFriendly &&
    unit.Distance < 30 &&
    !Styx.Logic.Blacklist.Contains(unit.Guid));
                        foreach (WoWUnit Mob in HostleList)
                        {
                            AutoAttack();
                            Mob.Target();
                            if (ObjectManager.Me.CurrentTarget.Distance > 5)
                            {
                                int a = 0;
                                while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.Distance > 5)
                                {
                                    Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 2.5f));
                                    Thread.Sleep(100); //xxAhzz: Changed to 100
                                    FindClostestPlayer(8);
                                    ++a;
                                }
                                WoWMovement.Face(); //xxAhzz: Moved so face would occur after MoveTo occurs
                            }
                            if (getAdds().Count > 3)
                            {
                                break;
                            }
                        }
                    }
                    //Common();

                    double meleeRange = 5;
                    // xxAhzz: double growlRange = 20;

                    if (Me.CurrentTarget.Distance < 25 && Me.CurrentTarget.Distance > 6 && SpellManagerEx.CanCast("Feral Charge - Bear") && Druid._settings.FeralCharge)
                    {
                        SpellManagerEx.Cast("Feral Charge - Bear");
                    }
                    // xxAhzz ToDo: Need to sort Pulling for caster or Non-Caster
                    if (ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                    {
                        int a = 0;
                        while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                        {
                            if (Me.CurrentTarget.Distance < 25 && Me.CurrentTarget.Distance > 6 && SpellManagerEx.CanCast("Feral Charge - Bear") && Druid._settings.FeralCharge)
                            {
                                SpellManagerEx.Cast("Feral Charge - Bear");
                            }
                            Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 2.5f));
                            Thread.Sleep(100); //xxAhzz: Changed to 100
                            FindClostestPlayer(8);
                            ++a;
                        }
                        WoWMovement.Face(); //xxAhzz: Moved so face would occur after MoveTo occurs
                    }
                    // Use Maul as a rage-dump.
                    if (IsBear())
                    {
                        if (Me.CurrentRage > 15 && SpellManagerEx.CanCast("Maul"))
                        {
                            slog("Rage Dump: Casting Maul");
                            SpellManagerEx.Cast("Maul");
                        }
                    }
                    Enqueue(_FeralBear, 1);

                    if (_rotation.Count > 0)
                        Cast();
                    combatChecks();


                }
            }
        }

        public void CatDps()
        {
            if (IsBattleGround())
            {
                FindClostestPlayer(15);
            }
           
         if (Me.IsInParty && RaFHelper.Leader.IsMe && !InstanceBuddyEnabled())
         {
             foreach (WoWUnit Thing in getAdds())
             {
                 if (Thing.IsTargetingMyPartyMember)
                 {
                     slog("Is Targeting my Party Member. Targeting Mob");
                     Thing.Target();
                     break;
                 }
             }
         }
            if (!Me.Silenced)
            {
                if (Me.CurrentTarget != null)
                {
                    //Common();
                    if ((getAdds().Count > 2
                        || (Me.CurrentTarget.Level >= (Me.Level + 2) && getAdds().Count > 1) // Run as bear if the target is 2 or more levels higher than me, and i have a add.
                        || Me.CurrentTarget.Elite) && !IsInPartyOrRaid() && !Druid._settings.NoBear) // Be a bear if our target is an elite.
                    {
                        BearTank();
                        slog("Got Adds, Using Bear");
                        return;                     // This should fix the walk past the target.
                    }
                    double meleeRange = 5;

                    if (ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                    {
                        int a = 0;
                        while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.Distance > meleeRange)
                        {
                            if (eType == Druid.DruidType.Feral && Druid._settings.PouncePull && !Me.Combat)
                            {
                                if (!IsCat())
                                {
                                    CastNowSpell("Cat Form");
                                    CastNowSpell("Prowl");
                                    if (Me.CurrentTarget.Distance <= 6 && SpellManagerEx.CanCast("Pounce"))
                                    {
                                        SpellManagerEx.Cast("Pounce");
                                    }

                                }
                                else
                                    if (IsCat())
                                    {
                                        CastNowSpell("Prowl");
                                        if (Me.CurrentTarget.Distance <= 6 && SpellManagerEx.CanCast("Pounce"))
                                        {
                                            SpellManagerEx.Cast("Pounce");
                                        }
                                    }
                                    else
                                        if (IsCat() && Me.Shapeshift == ShapeshiftForm.Stealth)
                                        {
                                            if (Me.CurrentTarget.Distance <= 6 && SpellManagerEx.CanCast("Pounce"))
                                            {
                                                SpellManagerEx.Cast("Pounce");
                                            }
                                        }
                            }
                            WoWMovement.Face();
                            Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 2.5f));
                            Thread.Sleep(250);
                            FindClostestPlayer(8);
                            ++a;
                        }
                    }
                    Enqueue(_FeralCat, 1);

                    if (combatChecks())
                    {
                        if (_rotation.Count > 0)
                            Cast();
                    }

                }
            }
        }


    }
}
