﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using Styx;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

namespace Kaboomkin
{
    public partial class Druid
    {
        private delegate bool Condition();
        public static bool Wandon;
        public static bool AddDone;
        public static int AddCount;
        public static WoWUnit CTarget;
        public static WoWPoint WandLocation;
        public static WoWUnit WandTarget;
        public static bool TargetWasNull;
        public static bool TargetChanged;
        public static bool Resting;
        public static WoWPlayer FollowTarget;
        public static bool followingFlagCarrier;
        public static WoWUnit HealTarget;
        public static string HealSpell;
        public static bool LoadingScreen;
        //private readonly LocalPlayer Me = ObjectManager.Me;


        /// <summary>
        /// Returns true if my current target has a debuff
        /// </summary>
        /// <param name="name">string - name of the debuff</param>
        /// <returns>boolean indicating if debugg is present or not</returns>
        private static bool GotDebuff(string name)
        {
            if (Me.CurrentTarget == null)
            { return false; }

            return !(!Me.CurrentTarget.Buffs.ContainsKey(name) && SpellManager.KnownSpells.ContainsKey(name));
        }
        public static void DruidRest()
        {
            if (Me.ManaPercent < Druid._settings.DrinkAt && !Me.Buffs.ContainsKey("Food"))
            {
                Styx.Logic.Common.Rest.Feed();

            }
        }
        public static List<WoWUnit> getAdds()
        {
            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false).FindAll(unit =>
                unit.Guid != Me.Guid &&
                unit.IsTargetingMeOrPet &&
                !unit.IsFriendly &&
                !Styx.Logic.Blacklist.Contains(unit.Guid));

            if (mobList.Count > 1)
            {
                Logging.Write("Warning: there are " + mobList.Count.ToString() + " attackers.");
            }
            return mobList;

        }
        #region Added By xxAhzz

        private static bool isFeral = false;
        private static bool isCaster = false;

        //xxAhzz: noCombatMana uses an arbitrary number to setup a reserve mana pool
        //xxAhzz: The idea was not to let the Balance shape use up all mana therfore
        //xxAhzz: preventing us getting into Feral form.  The numbers used should be
        //xxAhzz: researched a bit more so that they scale accross levels well.
        //xxAhzz: I am using a buffer of Bear shift cost * 2.5.  So far so good.
        private static bool noCombatMana()
        {
            if (SpellManagerEx.HasSpell("Dire Bear Form"))
            {
                double bearMana = SpellManagerEx.Spells["Dire Bear Form"].PowerCost * 2;
                double costMana = SpellManagerEx.Spells["Healing Touch"].PowerCost * 2;
                double availableMana = Me.CurrentMana;
                double availableCombatMana = availableMana - costMana;
                Log("Available Mana for Balance Combat: " + availableCombatMana);
                if (availableMana < costMana)
                    return true;
            }
            else
            {
                double bearMana = SpellManagerEx.Spells["Bear Form"].PowerCost * 2;
                double costMana = SpellManagerEx.Spells["Healing Touch"].PowerCost * 2;
                double availableMana = Me.CurrentMana;
                double availableCombatMana = availableMana - costMana;
                Log("Available Mana for Balance Combat: " + availableCombatMana);
                if (availableMana < costMana)
                    return true;
            }

            return false;
        }

        private static bool healMana()
        {
            if (SpellManagerEx.HasSpell("Dire Bear Form"))
            {
                double bearMana = SpellManagerEx.Spells["Dire Bear Form"].PowerCost * 2;
                double costMana = SpellManagerEx.Spells["Healing Touch"].PowerCost * 2;
                double availableMana = Me.CurrentMana;
                double availableHealMana = availableMana - costMana;
                Log("Available Mana for Healing: " + availableHealMana);
                if (availableMana - costMana > bearMana)
                    return true;
            }
            else
            {
                double bearMana = SpellManagerEx.Spells["Bear Form"].PowerCost * 2;
                double costMana = SpellManagerEx.Spells["Healing Touch"].PowerCost * 2;
                double availableMana = Me.CurrentMana;
                double availableHealMana = availableMana - costMana;
                Log("Available Mana for Healing: " + availableHealMana);
                if (availableMana - costMana > bearMana)
                    return true;

            }
            return false;
        }
        /*
        private static bool healMana()
        {
            double bearMana = Me.MaxMana * .18;
            double costMana = Me.MaxMana * .15;
            double availableMana = Math.Round((Me.MaxMana * Me.ManaPercent) / 100, 2);
            double availableHealMana = availableMana - costMana;
            Log("Available Mana for Healing: " + availableHealMana);
            if (availableMana - costMana > bearMana)
                return true;

            return false;
        }*/
        public static bool HasEnoughMana(string name)
        {
            WoWSpell spell = SpellManager.KnownSpells[name];

            if (Me.GetCurrentPower(spell.PowerType) >= spell.PowerCost)
                return true;

            return false;
        }
        public static bool EnemyNearby()
        {
            List<WoWUnit> enemyList = ObjectManager.GetObjectsOfType<WoWUnit>(false).FindAll(unit =>
                            unit.Attackable &&
                            !unit.IsFriendly &&
                            unit != Me &&
                            unit.Distance < 7 &&
                            unit.IsPlayer);

            if (enemyList.Count > 0)
                return true;

            return false;
        }

        public static bool FriendNearby()
        {
            List<WoWUnit> friendList = ObjectManager.GetObjectsOfType<WoWUnit>(false).FindAll(unit =>
                            unit.IsFriendly &&
                            unit != Me &&
                            unit.Distance < 40 &&
                            unit.IsPlayer);

            if (friendList.Count > 0)
                return true;

            return false;
        }
        public static bool CanCast(string name)
        {
            if (SpellManager.KnownSpells.ContainsKey(name) && SpellManager.CanCastSpell(name) && HasEnoughMana(name) && !SpellManager.KnownSpells[name].Cooldown)
                return true;

            return false;
        }
        /* Credit to Bobby53
         * trys to determine if 'unit' points to a mob that is a Caster.  Currently
         * only see .Class as being able to help determine.  the big question marks
         * are Druids and Shamans for grinding purposes, so even though we try
         * to guess we still make routines able to adapt on pulls, etc. to fact
         * mob may not behave like we guessed
         */
        private static bool TargetIsCaster(WoWUnit unit)
        {
            bool targetisCaster = false;

            switch (unit.Class.ToString().ToLower())
            {

                default:
                    Log("UKNOWN MOB CLASS:  CONTACT CC DEVELOPER:  Please provide the class name '" + unit.Class + "' and name [" + unit.Name + "]");
                    break;

                case "paladin":
                case "druid":
                case "rogue":
                case "warrior":
                case "death knight":
                    break;

                case "mage":
                case "warlock":
                case "shaman":
                case "priest":
                case "hunter":
                    targetisCaster = true;
                    break;
            }

            // following test added because of "Unyielding Sorcerer" in Hellfire
            // .. having a class of Paladin, yet they fight as ranged casters

            if (!targetisCaster)
            {
                if (unit.Name.ToLower().Contains("sorcerer"))
                    targetisCaster = true;
                else if (unit.Name.ToLower().Contains("shaman"))
                    targetisCaster = true;
                else if (unit.Name.ToLower().Contains("mage"))
                    targetisCaster = true;
                else if (unit.Name.ToLower().Contains("warlock"))
                    targetisCaster = true;
                else if (unit.Name.ToLower().Contains("priest"))
                    targetisCaster = true;
                else if (unit.Name.ToLower().Contains("wizard"))
                    targetisCaster = true;
                else if (unit.Name.ToLower().Contains("adept"))
                    targetisCaster = true;
                else if (unit.Name.ToLower().Contains("stormer"))
                    targetisCaster = true;
            }

            return targetisCaster;
        }

        #endregion

        /// <summary>
        /// Returns true if i got this buff
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private static bool GotBuff(string name)
        {
            return Me != null ? Me.Buffs.ContainsKey(name) : false;
        }
        public static bool IsBear()
        {
            if (Me.Shapeshift == ShapeshiftForm.Bear)
            {
                return true;
            }
            return false;

        }
        public static bool IsCat()
        {
            if (Me.Shapeshift == ShapeshiftForm.Cat)
            {
                return true;
            }
            return false;

        }
        public static bool IsMoonkin()
        {
            if (Me.Shapeshift == ShapeshiftForm.Moonkin)
            {
                return true;
            }
            return false;

        }
        public static bool IsTree()
        {
            if (Me.Shapeshift == ShapeshiftForm.TreeOfLife)
            {
                return true;
            }
            return false;

        }
        private static bool GotBuff(string name, bool target)
        {
            if (target)
            {
                return Me != null
                           ?
                               Me.CurrentTarget != null
                                   ?
                                       Me.CurrentTarget.Buffs.ContainsKey(name)
                                   :
                                       false
                           :
                               false;
            }

            return GotBuff(name);
        }
        public void CombatModeCheck()
        {
           if (eType == DruidType.Balance && !noCombatMana())
           {
               DruidMode = CombatType.Moonkin;
           }
           else
               if(IsInPartyOrRaid())
               {
                   DruidMode = CombatType.Cat; 
               }
               else
            if (Druid._settings.isTank)
            {
                DruidMode = CombatType.Bear;
            }
            else  
            if (!SpellManagerEx.HasSpell("Cat Form"))
            {
                DruidMode = CombatType.Bear;
            }
            else
            {
                DruidMode = CombatType.Cat;
            }
        }
        enum CombatType
        {
            None,
            Cat,
            Bear,
            Moonkin
        }
        static CombatType DruidMode = CombatType.None;

        public static bool InstanceBuddyEnabled()
        {

            string[] enabledPlugins = Styx.Helpers.StyxSettings.Instance.EnabledPlugins;
            foreach (string pluginName in enabledPlugins)
            {
                if (pluginName == "Instancebuddy")
                {
                    return true;
                    break;
                }
            }
           return false;
        }

        private static void DoBuff(Dictionary<SpellPriority, CastRequirements> buffs)
        {
            if (Me.IsMoving)
            {
                WoWMovement.MoveStop();
            }

            var tempQueue = new Queue<WoWSpell>();

            foreach (var s in buffs)
            {
                if (Me != null)
                {
                    if (s.Value.Invoke(Me))
                    {
                        if (SpellManager.KnownSpells.ContainsKey(s.Key.Name))
                            tempQueue.Enqueue(SpellManager.KnownSpells[s.Key.Name]);
                    }
                }
            }

            while (tempQueue.Count > 0)
            {
                Log("Buffing#{0}", tempQueue.Peek().Name);
                SpellManager.CastSpell(tempQueue.Dequeue().Name);
            }
        }
        WoWPoint attackPointBuffer;
        WoWPoint attackPoint
        {
            get
            {
                if (Me.GotTarget)
                {
                    attackPointBuffer = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 1.0f);
                    return attackPointBuffer;
                }
                else
                {
                    WoWPoint noSpot = new WoWPoint();
                    return noSpot;
                }
            }
        }
        private static bool NeedBuffs(Dictionary<SpellPriority, CastRequirements> buffs)
        {
            foreach (var kvp in buffs)
            {
                if (kvp.Value.Invoke(null))
                {
                    return true;
                }
            }

            return false;
        }

        private static void DoAction(Dictionary<Condition, Action> actions)
        {
            foreach (var action in actions)
            {
                if (action.Key.Invoke())
                {
                    action.Value.Invoke();
                }
            }
        }

        private static bool NeedAction(Dictionary<Condition, Action> actions)
        {
            foreach (var action in actions)
            {
                if (action.Key.Invoke())
                    return true;
            }

            return false;
        }

        private static bool KnowsSpell(string name)
        {
            return SpellManager.KnownSpells.ContainsKey(name);
        }
        private static bool CastNowSpell(string name)
        {
            if (SpellManager.KnownSpells.ContainsKey(name) && SpellManager.CanCastSpell(name))
            {
                return SpellManager.CastSpell(name);
            }
            else
            {
                return false;
            }


        }
        public static bool IsInPartyOrRaid()
        {
            if (Me.PartyMembers.Count > 0)
                return true;

            return false;
        }

        public static void FindClostestPlayer(int Range)
        {
            List<WoWPlayer> PlrNearList2 = (from p in ObjectManager.GetObjectsOfType<WoWPlayer>() let d = p.Distance where d <= Range && !p.IsFriendly orderby d ascending select p).ToList();

            if (IsBattleGround() && Me.CurrentTarget.Distance > Range && PlrNearList2.Count > 0 && PlrNearList2[0].Guid != Me.CurrentTarget.Guid)
            {
                slog("My CurrentTarget Ran out of Range Switching to Closest");
                PlrNearList2[0].Target();
            }
        }
        public static bool NeedWildGrowth()
        {
            int count = 0;

            if (Me.PartyMembers.Count > 0)
            {
                foreach (WoWPlayer p in Me.PartyMembers)
                {
                    if (p.HealthPercent < Druid._settings.WildGrowth  && p.Distance < 14 && p.HealthPercent > 1)
                        count++;
                }
            }

            if (count >= Druid._settings.Num_TargetsWildGrowth)
                return true;

            return false;
        }

        public static bool NeedTranquility()
        {
            int count = 0;

            if (Me.PartyMembers.Count > 0)
            {
                foreach (WoWPlayer p in Me.PartyMembers)
                {
                    if (p.HealthPercent < Druid._settings.Tranquility && p.Distance < 30 && p.HealthPercent > 1)
                        count++;
                }
            }

            if (count >= Druid._settings.Num_TargetsTranquility)
                return true;

            return false;
        }
  
 

        private bool combatChecks()
        {
            if (Me.GotTarget &&
                !Me.CurrentTarget.IsValid)
            {
                Logging.WriteDebug("Target killed.");
                return false;
            }

            if (Me.Dead)
            {
                slog("I died.");
                return false;
            }
            //double targetDistance = Me.CurrentTarget.Distance;
            if (Me.CurrentTarget.Distance > 50 &&
                Me.CurrentTarget.Distance < 100)
            {
                slog("Out of range: " + Me.CurrentTarget.Name + " is " + System.Math.Round(Me.CurrentTarget.Distance).ToString() + " yards away.");
                if (ObjectManager.Me.IsMoving)
                    WoWMovement.MoveStop();
                return false;
            }


            Thread.Sleep(10);

            if (ObjectManager.Me.IsMoving)
                WoWMovement.MoveStop();

            WoWMovement.Face();

            return true;
        }
        public static int Lag()
        {
            float downkb, upkb;
            uint lag;
            StyxWoW.WoWClient.GetNetStats(out downkb, out upkb, out lag);
            return (int)lag + 50;
        }
        private static bool IsBattleGround()
        {
            return Styx.Logic.Battlegrounds.IsInsideBattleground;
        }
        public static bool WillChain(int Hits, int hitHpPercent, WoWPoint TargetLocal, bool Friendly)
        {
            List<WoWPlayer> hitList = new List<WoWPlayer>();
            if (Friendly)
            {

                if (Me.RaidMembers.Count > 0)
                {
                    foreach (WoWPlayer Plr in Me.RaidMembers)
                    {

                        if (TargetLocal.Distance(Plr.Location) <= 10 && Plr.HealthPercent <= hitHpPercent)
                        {
                            hitList.Add(Plr);
                        }

                    }
                }
                else if (Me.PartyMembers.Count > 0)
                {
                    foreach (WoWPlayer Plr in Me.PartyMembers)
                    {
                        if (TargetLocal.Distance(Plr.Location) <= 10 && Plr.HealthPercent <= hitHpPercent)
                        {
                            hitList.Add(Plr);
                        }

                    }
                }
            }
            else
            {
                if (IsBattleGround())
                {
                    List<WoWPlayer> enemyList = ObjectManager.GetObjectsOfType<WoWPlayer>(false).FindAll(unit =>
        unit.Attackable &&
        !unit.IsFriendly &&
        unit != Me);
                    foreach (WoWPlayer Plr in enemyList)
                    {
                        if (TargetLocal.Distance(Plr.Location) <= 10)
                        {
                            hitList.Add(Plr);
                        }

                    }
                }
                else
                {
                    List<WoWUnit> enemyList = ObjectManager.GetObjectsOfType<WoWUnit>(false).FindAll(unit =>
         unit.Attackable &&
         !unit.IsFriendly &&
         unit != Me &&
         unit.IsPlayer);
                    foreach (WoWPlayer Plr in enemyList)
                    {
                        if (TargetLocal.Distance(Plr.Location) <= 14)
                        {
                            hitList.Add(Plr);
                        }

                    }
                }


            }
            if (hitList.Count >= Hits)
            {
                slog("Found Targets Near Current Target, Returning True");
                hitList.Clear();
                return true;
            }
            else
            {
                hitList.Clear();
                return false;
            }
        }
        public static bool HasRegentGift()
        {
            if (Me.Level < 50)
            {
                foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false).Where(item => item.Name == "Wild Berries"))
                {
                    return true;
                }
                return false;
            }
            else if (Me.Level < 60)
            {
                foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false).Where(item => item.Name == "Wild Thornroot"))
                {
                    return true;
                }
                return false;
            }
            else if (Me.Level < 70)
            {
                foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false).Where(item => item.Name == "Wild Quillvine"))
                {
                    return true;
                }
                return false;
            }
            else
            {
                foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false).Where(item => item.Name == "Wild Spineleaf"))
                {
                    return true;
                }
                return false;
            }
        }
        public void PetCommand()
        {
            
            if (Me.GotAlivePet && IsBattleGround())
            {
                Lua.DoString("PetAttack()");
            }
            if (!Me.GotTarget && Me.Pet.GotTarget && Me.PetInCombat)
            {
                slog("{0} is Attacking: {1} But i Have No Target, Attacking Pet Target.", Me.Pet.Name.ToString(), Me.Pet.CurrentTarget.Name.ToString());
                Me.Pet.CurrentTarget.Target();

                WoWMovement.Face();
            }

            if (Me.Pet.CurrentTarget != Me.CurrentTarget)
            {
                Lua.DoString("PetAttack()");
                slog("Sending Pet to Attack");
            }
            if (Me.PetAggro && Me.CurrentTarget != Me.Pet.CurrentTarget && IsBattleGround())
            {
                Me.Pet.CurrentTarget.Target();
                slog("Pet in Combat, Targeting Pet's Target.");
            }
            if (Me.CurrentTarget.Distance > Styx.Helpers.LevelbotSettings.Instance.PullDistance || !Me.CurrentTarget.InLineOfSight)
            {
                slog("Current Target out of Range or out of line of sight Recalling Pet");

                Lua.DoString("RunMacroText(\"/petfollow\")");
                do
                {
                    Thread.Sleep(100);

                } while (Me.Pet.Distance > 20);

                Lua.DoString("PetAttack()");

            }
        }
        bool IsFacingAway
        {
            get
            {
                bool face = false;
                double bearing = Me.CurrentTarget.Rotation;
                //double Angle = bearing * 180 / Math.PI; 
                if (bearing > Math.PI / 2 || bearing < -Math.PI / 2)
                    face = true;
                return face;
            }
        }

 
        private void SafeMoveToPoint(WoWPoint point, int duration)
        {
            moveTimer.Reset();
            moveTimer.Start();

            while (Me.HealthPercent > 1)
            {
                Thread.Sleep(500);
                Navigator.MoveTo(point);
                if (!Me.Buffs.ContainsKey("Prowl") || moveTimer.ElapsedMilliseconds >= duration)
                {
                    break;
                }
                WoWMovement.MoveStop();
            }
            return;
        }

      

        //private static bool UseNavigator;
        //private WoWUnit _lastTarget;
        private WoWPoint _dest = WoWPoint.Zero;
        private WoWPoint GetTraceLinePos()
        {
            return new WoWPoint(Me.X, Me.Y, Me.Z + 2.132f);
        }

        private static Stopwatch movementTimer = new Stopwatch();

        private int SortByDistance(WoWUnit x, WoWUnit y)
        {
            int retval = Me.Location.Distance(x.Location).CompareTo(Me.Location.Distance(y.Location));
            return retval;
        }

      


        /// <summary>
        /// Small wrapper for Logging.Write(...)
        /// </summary>
        /// <param name="format">text to print</param>
        /// <param name="args">arguments</param>
        private static void Log(string format, params object[] args)
        {
         
                Logging.Write("[Kaboomkin: " + format, args);
        
            }
        }
    }

