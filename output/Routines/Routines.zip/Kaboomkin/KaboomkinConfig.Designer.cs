﻿namespace Kaboomkin
{
    partial class KaboomkinConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DrinkAt = new System.Windows.Forms.NumericUpDown();
            this.EatAt = new System.Windows.Forms.NumericUpDown();
            this.Save = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Rejuvenation = new System.Windows.Forms.NumericUpDown();
            this.HealingTouch = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.HighMana = new System.Windows.Forms.NumericUpDown();
            this.LowMana = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.RaidRotation = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Inntervate_Bal = new System.Windows.Forms.NumericUpDown();
            this.Huricane_Adds = new System.Windows.Forms.CheckBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.FeralCharge = new System.Windows.Forms.CheckBox();
            this.IsTanking = new System.Windows.Forms.CheckBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.PouncePull = new System.Windows.Forms.CheckBox();
            this.NoBear = new System.Windows.Forms.CheckBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.Num_TargetsTranquility = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.Tranquility = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.use_Tranquility = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.use_WildGrowth = new System.Windows.Forms.CheckBox();
            this.WildGrowth = new System.Windows.Forms.NumericUpDown();
            this.Num_TargetsWildGrowth = new System.Windows.Forms.NumericUpDown();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.abolishPosin = new System.Windows.Forms.CheckBox();
            this.removeCurse = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.HealingTouch_HL = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.sads = new System.Windows.Forms.Label();
            this.asdfH = new System.Windows.Forms.Label();
            this.Lifebloom_HL = new System.Windows.Forms.NumericUpDown();
            this.Swiftmend_HL = new System.Windows.Forms.NumericUpDown();
            this.Nourish_HL = new System.Windows.Forms.NumericUpDown();
            this.Regrowth_HL = new System.Windows.Forms.NumericUpDown();
            this.Innervate_HL = new System.Windows.Forms.NumericUpDown();
            this.Rejuv_HL = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.GiftoftheWild = new System.Windows.Forms.CheckBox();
            this.MarkOftheWild = new System.Windows.Forms.CheckBox();
            this.ThornsTank = new System.Windows.Forms.CheckBox();
            this.Rebirth = new System.Windows.Forms.CheckBox();
            this.Revive = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.DrinkAt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EatAt)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Rejuvenation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HealingTouch)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HighMana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LowMana)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inntervate_Bal)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Num_TargetsTranquility)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tranquility)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WildGrowth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Num_TargetsWildGrowth)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HealingTouch_HL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lifebloom_HL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Swiftmend_HL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nourish_HL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Regrowth_HL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Innervate_HL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rejuv_HL)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Eat At";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(94, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Drink At";
            // 
            // DrinkAt
            // 
            this.DrinkAt.Location = new System.Drawing.Point(96, 32);
            this.DrinkAt.Name = "DrinkAt";
            this.DrinkAt.Size = new System.Drawing.Size(63, 20);
            this.DrinkAt.TabIndex = 2;
            this.DrinkAt.ValueChanged += new System.EventHandler(this.DrinkAt_ValueChanged);
            // 
            // EatAt
            // 
            this.EatAt.Location = new System.Drawing.Point(9, 32);
            this.EatAt.Name = "EatAt";
            this.EatAt.Size = new System.Drawing.Size(63, 20);
            this.EatAt.TabIndex = 3;
            this.EatAt.ValueChanged += new System.EventHandler(this.EatAt_ValueChanged);
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(372, 329);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(96, 23);
            this.Save.TabIndex = 7;
            this.Save.Text = "Save Settings";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 39);
            this.label4.TabIndex = 8;
            this.label4.Text = "Change Drink At to 0 \r\nfor continuous Grinding\r\nAfter Getting Bear Form\r\n";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Revive);
            this.groupBox1.Controls.Add(this.Rebirth);
            this.groupBox1.Controls.Add(this.ThornsTank);
            this.groupBox1.Controls.Add(this.MarkOftheWild);
            this.groupBox1.Controls.Add(this.GiftoftheWild);
            this.groupBox1.Location = new System.Drawing.Point(223, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(234, 129);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Buffing and Reserection";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(1, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(471, 327);
            this.tabControl1.TabIndex = 38;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(463, 301);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Info";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(463, 301);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Common";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.Rejuvenation);
            this.groupBox3.Controls.Add(this.HealingTouch);
            this.groupBox3.Location = new System.Drawing.Point(179, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(281, 100);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Common Healing";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(129, 20);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(146, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Regrowth and Rejuvenate % ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Healing Touch";
            // 
            // Rejuvenation
            // 
            this.Rejuvenation.Location = new System.Drawing.Point(169, 36);
            this.Rejuvenation.Name = "Rejuvenation";
            this.Rejuvenation.Size = new System.Drawing.Size(67, 20);
            this.Rejuvenation.TabIndex = 1;
            this.Rejuvenation.ValueChanged += new System.EventHandler(this.Rejuvenation_ValueChanged);
            // 
            // HealingTouch
            // 
            this.HealingTouch.Location = new System.Drawing.Point(21, 37);
            this.HealingTouch.Name = "HealingTouch";
            this.HealingTouch.Size = new System.Drawing.Size(67, 20);
            this.HealingTouch.TabIndex = 0;
            this.HealingTouch.ValueChanged += new System.EventHandler(this.HealingTouch_ValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.EatAt);
            this.groupBox2.Controls.Add(this.DrinkAt);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(7, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(166, 100);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Resting Options";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.groupBox8);
            this.tabPage3.Controls.Add(this.RaidRotation);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.Inntervate_Bal);
            this.tabPage3.Controls.Add(this.Huricane_Adds);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(463, 301);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Balance";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(302, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 26);
            this.label5.TabIndex = 9;
            this.label5.Text = "Check to Disable Starfire Spam\r\nTill Better Solution can be found.";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.HighMana);
            this.groupBox8.Controls.Add(this.LowMana);
            this.groupBox8.Controls.Add(this.label16);
            this.groupBox8.Controls.Add(this.label15);
            this.groupBox8.Location = new System.Drawing.Point(7, 72);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(294, 117);
            this.groupBox8.TabIndex = 8;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Might not work after 1.3";
            // 
            // HighMana
            // 
            this.HighMana.Location = new System.Drawing.Point(9, 90);
            this.HighMana.Name = "HighMana";
            this.HighMana.Size = new System.Drawing.Size(65, 20);
            this.HighMana.TabIndex = 3;
            this.HighMana.ValueChanged += new System.EventHandler(this.HighMana_ValueChanged);
            // 
            // LowMana
            // 
            this.LowMana.Location = new System.Drawing.Point(6, 41);
            this.LowMana.Name = "LowMana";
            this.LowMana.Size = new System.Drawing.Size(68, 20);
            this.LowMana.TabIndex = 2;
            this.LowMana.ValueChanged += new System.EventHandler(this.LowMana_ValueChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 74);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(292, 13);
            this.label16.TabIndex = 6;
            this.label16.Text = "Mana Percent to come out of Cat or Bear Mode (High Mana)";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 25);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(268, 13);
            this.label15.TabIndex = 5;
            this.label15.Text = "Mana Percent to Turn on Cat or Bear Mode (LowMana)";
            // 
            // RaidRotation
            // 
            this.RaidRotation.AutoSize = true;
            this.RaidRotation.Location = new System.Drawing.Point(318, 39);
            this.RaidRotation.Name = "RaidRotation";
            this.RaidRotation.Size = new System.Drawing.Size(139, 17);
            this.RaidRotation.TabIndex = 7;
            this.RaidRotation.Text = "Use Raid Style Rotation";
            this.RaidRotation.UseVisualStyleBackColor = true;
            this.RaidRotation.CheckedChanged += new System.EventHandler(this.RaidRotation_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Innervate";
            // 
            // Inntervate_Bal
            // 
            this.Inntervate_Bal.Location = new System.Drawing.Point(16, 35);
            this.Inntervate_Bal.Name = "Inntervate_Bal";
            this.Inntervate_Bal.Size = new System.Drawing.Size(68, 20);
            this.Inntervate_Bal.TabIndex = 1;
            this.Inntervate_Bal.ValueChanged += new System.EventHandler(this.Inntervate_Bal_ValueChanged);
            // 
            // Huricane_Adds
            // 
            this.Huricane_Adds.AutoSize = true;
            this.Huricane_Adds.Location = new System.Drawing.Point(318, 15);
            this.Huricane_Adds.Name = "Huricane_Adds";
            this.Huricane_Adds.Size = new System.Drawing.Size(114, 17);
            this.Huricane_Adds.TabIndex = 0;
            this.Huricane_Adds.Text = "Hurricane on Adds";
            this.Huricane_Adds.UseVisualStyleBackColor = true;
            this.Huricane_Adds.CheckedChanged += new System.EventHandler(this.Huricane_Adds_CheckedChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.tabControl2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(463, 301);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Feral";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Location = new System.Drawing.Point(-4, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(471, 305);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.FeralCharge);
            this.tabPage6.Controls.Add(this.IsTanking);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(463, 279);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "Bear";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // FeralCharge
            // 
            this.FeralCharge.AutoSize = true;
            this.FeralCharge.Location = new System.Drawing.Point(6, 42);
            this.FeralCharge.Name = "FeralCharge";
            this.FeralCharge.Size = new System.Drawing.Size(114, 17);
            this.FeralCharge.TabIndex = 12;
            this.FeralCharge.Text = "Use Feral Charge?";
            this.FeralCharge.UseVisualStyleBackColor = true;
            this.FeralCharge.CheckedChanged += new System.EventHandler(this.FeralCharge_CheckedChanged);
            // 
            // IsTanking
            // 
            this.IsTanking.AutoSize = true;
            this.IsTanking.Location = new System.Drawing.Point(7, 6);
            this.IsTanking.Name = "IsTanking";
            this.IsTanking.Size = new System.Drawing.Size(76, 17);
            this.IsTanking.TabIndex = 11;
            this.IsTanking.Text = "Is Tanking";
            this.IsTanking.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.PouncePull);
            this.tabPage7.Controls.Add(this.NoBear);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(463, 279);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "Cat";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // PouncePull
            // 
            this.PouncePull.AutoSize = true;
            this.PouncePull.Location = new System.Drawing.Point(6, 42);
            this.PouncePull.Name = "PouncePull";
            this.PouncePull.Size = new System.Drawing.Size(83, 17);
            this.PouncePull.TabIndex = 1;
            this.PouncePull.Text = "Pounce Pull";
            this.PouncePull.UseVisualStyleBackColor = true;
            this.PouncePull.CheckedChanged += new System.EventHandler(this.PouncePull_CheckedChanged);
            // 
            // NoBear
            // 
            this.NoBear.AutoSize = true;
            this.NoBear.Location = new System.Drawing.Point(6, 18);
            this.NoBear.Name = "NoBear";
            this.NoBear.Size = new System.Drawing.Size(176, 17);
            this.NoBear.TabIndex = 0;
            this.NoBear.Text = "Do Not Drop into Bear on Adds.";
            this.NoBear.UseVisualStyleBackColor = true;
            this.NoBear.CheckedChanged += new System.EventHandler(this.NoBear_CheckedChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox7);
            this.tabPage5.Controls.Add(this.groupBox6);
            this.tabPage5.Controls.Add(this.groupBox5);
            this.tabPage5.Controls.Add(this.groupBox4);
            this.tabPage5.Controls.Add(this.groupBox1);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(463, 301);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Resto";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.Num_TargetsTranquility);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.Tranquility);
            this.groupBox7.Controls.Add(this.label9);
            this.groupBox7.Controls.Add(this.use_Tranquility);
            this.groupBox7.Controls.Add(this.label8);
            this.groupBox7.Location = new System.Drawing.Point(3, 195);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(214, 100);
            this.groupBox7.TabIndex = 40;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Tranquility";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(113, 45);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(78, 13);
            this.label18.TabIndex = 18;
            this.label18.Text = "Percent Health";
            // 
            // Num_TargetsTranquility
            // 
            this.Num_TargetsTranquility.Location = new System.Drawing.Point(48, 17);
            this.Num_TargetsTranquility.Name = "Num_TargetsTranquility";
            this.Num_TargetsTranquility.Size = new System.Drawing.Size(59, 20);
            this.Num_TargetsTranquility.TabIndex = 12;
            this.Num_TargetsTranquility.ValueChanged += new System.EventHandler(this.Num_TargetsTranquility_ValueChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 45);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(36, 13);
            this.label14.TabIndex = 17;
            this.label14.Text = "Below";
            // 
            // Tranquility
            // 
            this.Tranquility.Location = new System.Drawing.Point(46, 43);
            this.Tranquility.Name = "Tranquility";
            this.Tranquility.Size = new System.Drawing.Size(61, 20);
            this.Tranquility.TabIndex = 13;
            this.Tranquility.ValueChanged += new System.EventHandler(this.Tranquility_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(113, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Or More Players are";
            // 
            // use_Tranquility
            // 
            this.use_Tranquility.AutoSize = true;
            this.use_Tranquility.Location = new System.Drawing.Point(6, 67);
            this.use_Tranquility.Name = "use_Tranquility";
            this.use_Tranquility.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.use_Tranquility.Size = new System.Drawing.Size(96, 17);
            this.use_Tranquility.TabIndex = 14;
            this.use_Tranquility.Text = "Use Tranquility";
            this.use_Tranquility.UseVisualStyleBackColor = true;
            this.use_Tranquility.CheckedChanged += new System.EventHandler(this.use_Tranquility_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "When";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.use_WildGrowth);
            this.groupBox6.Controls.Add(this.WildGrowth);
            this.groupBox6.Controls.Add(this.Num_TargetsWildGrowth);
            this.groupBox6.Location = new System.Drawing.Point(222, 195);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(234, 100);
            this.groupBox6.TabIndex = 39;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Wild Growth";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(121, 45);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(78, 13);
            this.label20.TabIndex = 25;
            this.label20.Text = "Percent Health";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(14, 45);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(36, 13);
            this.label21.TabIndex = 24;
            this.label21.Text = "Below";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(121, 19);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(100, 13);
            this.label22.TabIndex = 23;
            this.label22.Text = "Or More Players are";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(14, 19);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(36, 13);
            this.label23.TabIndex = 22;
            this.label23.Text = "When";
            // 
            // use_WildGrowth
            // 
            this.use_WildGrowth.AutoSize = true;
            this.use_WildGrowth.Location = new System.Drawing.Point(14, 67);
            this.use_WildGrowth.Name = "use_WildGrowth";
            this.use_WildGrowth.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.use_WildGrowth.Size = new System.Drawing.Size(106, 17);
            this.use_WildGrowth.TabIndex = 21;
            this.use_WildGrowth.Text = "Use Wild Growth";
            this.use_WildGrowth.UseVisualStyleBackColor = true;
            this.use_WildGrowth.CheckedChanged += new System.EventHandler(this.use_WildGrowth_CheckedChanged);
            // 
            // WildGrowth
            // 
            this.WildGrowth.Location = new System.Drawing.Point(54, 43);
            this.WildGrowth.Name = "WildGrowth";
            this.WildGrowth.Size = new System.Drawing.Size(61, 20);
            this.WildGrowth.TabIndex = 20;
            this.WildGrowth.ValueChanged += new System.EventHandler(this.WildGrowth_ValueChanged);
            // 
            // Num_TargetsWildGrowth
            // 
            this.Num_TargetsWildGrowth.Location = new System.Drawing.Point(56, 17);
            this.Num_TargetsWildGrowth.Name = "Num_TargetsWildGrowth";
            this.Num_TargetsWildGrowth.Size = new System.Drawing.Size(59, 20);
            this.Num_TargetsWildGrowth.TabIndex = 19;
            this.Num_TargetsWildGrowth.ValueChanged += new System.EventHandler(this.Num_TargetsWildGrowth_ValueChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.abolishPosin);
            this.groupBox5.Controls.Add(this.removeCurse);
            this.groupBox5.Location = new System.Drawing.Point(223, 138);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(234, 51);
            this.groupBox5.TabIndex = 38;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Misc";
            // 
            // abolishPosin
            // 
            this.abolishPosin.AutoSize = true;
            this.abolishPosin.Location = new System.Drawing.Point(130, 18);
            this.abolishPosin.Name = "abolishPosin";
            this.abolishPosin.Size = new System.Drawing.Size(95, 17);
            this.abolishPosin.TabIndex = 1;
            this.abolishPosin.Text = "Abolish Poison";
            this.abolishPosin.UseVisualStyleBackColor = true;
            this.abolishPosin.CheckedChanged += new System.EventHandler(this.abolishPosin_CheckedChanged);
            // 
            // removeCurse
            // 
            this.removeCurse.AutoSize = true;
            this.removeCurse.Location = new System.Drawing.Point(6, 19);
            this.removeCurse.Name = "removeCurse";
            this.removeCurse.Size = new System.Drawing.Size(96, 17);
            this.removeCurse.TabIndex = 0;
            this.removeCurse.Text = "Remove Curse";
            this.removeCurse.UseVisualStyleBackColor = true;
            this.removeCurse.CheckedChanged += new System.EventHandler(this.removeCurse_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.HealingTouch_HL);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.sads);
            this.groupBox4.Controls.Add(this.asdfH);
            this.groupBox4.Controls.Add(this.Lifebloom_HL);
            this.groupBox4.Controls.Add(this.Swiftmend_HL);
            this.groupBox4.Controls.Add(this.Nourish_HL);
            this.groupBox4.Controls.Add(this.Regrowth_HL);
            this.groupBox4.Controls.Add(this.Innervate_HL);
            this.groupBox4.Controls.Add(this.Rejuv_HL);
            this.groupBox4.Location = new System.Drawing.Point(3, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(214, 183);
            this.groupBox4.TabIndex = 37;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Heal Spells";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(70, 131);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 13);
            this.label19.TabIndex = 13;
            this.label19.Text = "Healing Touch";
            // 
            // HealingTouch_HL
            // 
            this.HealingTouch_HL.Location = new System.Drawing.Point(73, 147);
            this.HealingTouch_HL.Name = "HealingTouch_HL";
            this.HealingTouch_HL.Size = new System.Drawing.Size(59, 20);
            this.HealingTouch_HL.TabIndex = 12;
            this.HealingTouch_HL.ValueChanged += new System.EventHandler(this.HealingTouch_HL_ValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(138, 93);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(73, 13);
            this.label13.TabIndex = 11;
            this.label13.Text = "Innervate Self";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 93);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 13);
            this.label12.TabIndex = 10;
            this.label12.Text = "Lifebloom";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(152, 53);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Regrowth";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 53);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 8;
            this.label10.Text = "Nourish";
            // 
            // sads
            // 
            this.sads.AutoSize = true;
            this.sads.Location = new System.Drawing.Point(152, 14);
            this.sads.Name = "sads";
            this.sads.Size = new System.Drawing.Size(56, 13);
            this.sads.TabIndex = 7;
            this.sads.Text = "Swiftmend";
            // 
            // asdfH
            // 
            this.asdfH.AutoSize = true;
            this.asdfH.Location = new System.Drawing.Point(8, 14);
            this.asdfH.Name = "asdfH";
            this.asdfH.Size = new System.Drawing.Size(70, 13);
            this.asdfH.TabIndex = 6;
            this.asdfH.Text = "Rejuvenation";
            // 
            // Lifebloom_HL
            // 
            this.Lifebloom_HL.Location = new System.Drawing.Point(9, 109);
            this.Lifebloom_HL.Name = "Lifebloom_HL";
            this.Lifebloom_HL.Size = new System.Drawing.Size(59, 20);
            this.Lifebloom_HL.TabIndex = 5;
            this.Lifebloom_HL.ValueChanged += new System.EventHandler(this.Lifebloom_HL_ValueChanged);
            // 
            // Swiftmend_HL
            // 
            this.Swiftmend_HL.Location = new System.Drawing.Point(141, 30);
            this.Swiftmend_HL.Name = "Swiftmend_HL";
            this.Swiftmend_HL.Size = new System.Drawing.Size(64, 20);
            this.Swiftmend_HL.TabIndex = 4;
            this.Swiftmend_HL.ValueChanged += new System.EventHandler(this.Swiftmend_HL_ValueChanged);
            // 
            // Nourish_HL
            // 
            this.Nourish_HL.Location = new System.Drawing.Point(9, 69);
            this.Nourish_HL.Name = "Nourish_HL";
            this.Nourish_HL.Size = new System.Drawing.Size(59, 20);
            this.Nourish_HL.TabIndex = 3;
            this.Nourish_HL.ValueChanged += new System.EventHandler(this.Nourish_HL_ValueChanged);
            // 
            // Regrowth_HL
            // 
            this.Regrowth_HL.Location = new System.Drawing.Point(141, 69);
            this.Regrowth_HL.Name = "Regrowth_HL";
            this.Regrowth_HL.Size = new System.Drawing.Size(64, 20);
            this.Regrowth_HL.TabIndex = 2;
            this.Regrowth_HL.ValueChanged += new System.EventHandler(this.Regrowth_HL_ValueChanged);
            // 
            // Innervate_HL
            // 
            this.Innervate_HL.Location = new System.Drawing.Point(141, 109);
            this.Innervate_HL.Name = "Innervate_HL";
            this.Innervate_HL.Size = new System.Drawing.Size(64, 20);
            this.Innervate_HL.TabIndex = 1;
            this.Innervate_HL.ValueChanged += new System.EventHandler(this.Innervate_HL_ValueChanged);
            // 
            // Rejuv_HL
            // 
            this.Rejuv_HL.Location = new System.Drawing.Point(11, 30);
            this.Rejuv_HL.Name = "Rejuv_HL";
            this.Rejuv_HL.Size = new System.Drawing.Size(59, 20);
            this.Rejuv_HL.TabIndex = 0;
            this.Rejuv_HL.ValueChanged += new System.EventHandler(this.Rejuv_HL_ValueChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(5, 334);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(135, 13);
            this.label17.TabIndex = 39;
            this.label17.Text = "A Druid CC by CodenameG";
            // 
            // GiftoftheWild
            // 
            this.GiftoftheWild.AutoSize = true;
            this.GiftoftheWild.Location = new System.Drawing.Point(7, 20);
            this.GiftoftheWild.Name = "GiftoftheWild";
            this.GiftoftheWild.Size = new System.Drawing.Size(96, 17);
            this.GiftoftheWild.TabIndex = 0;
            this.GiftoftheWild.Text = "Gift of the Wild";
            this.GiftoftheWild.UseVisualStyleBackColor = true;
            this.GiftoftheWild.CheckedChanged += new System.EventHandler(this.GiftoftheWild_CheckedChanged);
            // 
            // MarkOftheWild
            // 
            this.MarkOftheWild.AutoSize = true;
            this.MarkOftheWild.Location = new System.Drawing.Point(7, 43);
            this.MarkOftheWild.Name = "MarkOftheWild";
            this.MarkOftheWild.Size = new System.Drawing.Size(104, 17);
            this.MarkOftheWild.TabIndex = 1;
            this.MarkOftheWild.Text = "Mark of the Wild";
            this.MarkOftheWild.UseVisualStyleBackColor = true;
            this.MarkOftheWild.CheckedChanged += new System.EventHandler(this.MarkOftheWild_CheckedChanged);
            // 
            // ThornsTank
            // 
            this.ThornsTank.AutoSize = true;
            this.ThornsTank.Location = new System.Drawing.Point(55, 69);
            this.ThornsTank.Name = "ThornsTank";
            this.ThornsTank.Size = new System.Drawing.Size(102, 17);
            this.ThornsTank.TabIndex = 2;
            this.ThornsTank.Text = "Thorns on Tank";
            this.ThornsTank.UseVisualStyleBackColor = true;
            this.ThornsTank.CheckedChanged += new System.EventHandler(this.ThornsTank_CheckedChanged);
            // 
            // Rebirth
            // 
            this.Rebirth.AutoSize = true;
            this.Rebirth.Location = new System.Drawing.Point(123, 43);
            this.Rebirth.Name = "Rebirth";
            this.Rebirth.Size = new System.Drawing.Size(60, 17);
            this.Rebirth.TabIndex = 3;
            this.Rebirth.Text = "Rebirth";
            this.Rebirth.UseVisualStyleBackColor = true;
            this.Rebirth.CheckedChanged += new System.EventHandler(this.Rebirth_CheckedChanged);
            // 
            // Revive
            // 
            this.Revive.AutoSize = true;
            this.Revive.Location = new System.Drawing.Point(123, 20);
            this.Revive.Name = "Revive";
            this.Revive.Size = new System.Drawing.Size(60, 17);
            this.Revive.TabIndex = 4;
            this.Revive.Text = "Revive";
            this.Revive.UseVisualStyleBackColor = true;
            this.Revive.CheckedChanged += new System.EventHandler(this.Revive_CheckedChanged);
            // 
            // KaboomkinConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 356);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.Save);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "KaboomkinConfig";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "KaboomkinConfig";
            ((System.ComponentModel.ISupportInitialize)(this.DrinkAt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EatAt)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Rejuvenation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HealingTouch)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HighMana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LowMana)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Inntervate_Bal)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Num_TargetsTranquility)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tranquility)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.WildGrowth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Num_TargetsWildGrowth)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HealingTouch_HL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Lifebloom_HL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Swiftmend_HL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Nourish_HL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Regrowth_HL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Innervate_HL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Rejuv_HL)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown DrinkAt;
        private System.Windows.Forms.NumericUpDown EatAt;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown Rejuvenation;
        private System.Windows.Forms.NumericUpDown HealingTouch;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label sads;
        private System.Windows.Forms.Label asdfH;
        private System.Windows.Forms.NumericUpDown Lifebloom_HL;
        private System.Windows.Forms.NumericUpDown Swiftmend_HL;
        private System.Windows.Forms.NumericUpDown Nourish_HL;
        private System.Windows.Forms.NumericUpDown Regrowth_HL;
        private System.Windows.Forms.NumericUpDown Innervate_HL;
        private System.Windows.Forms.NumericUpDown Rejuv_HL;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox use_Tranquility;
        private System.Windows.Forms.NumericUpDown Tranquility;
        private System.Windows.Forms.NumericUpDown Num_TargetsTranquility;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox abolishPosin;
        private System.Windows.Forms.CheckBox removeCurse;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown HighMana;
        private System.Windows.Forms.NumericUpDown LowMana;
        private System.Windows.Forms.NumericUpDown Inntervate_Bal;
        private System.Windows.Forms.CheckBox Huricane_Adds;
        private System.Windows.Forms.CheckBox RaidRotation;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.CheckBox use_WildGrowth;
        private System.Windows.Forms.NumericUpDown WildGrowth;
        private System.Windows.Forms.NumericUpDown Num_TargetsWildGrowth;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.CheckBox IsTanking;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox FeralCharge;
        private System.Windows.Forms.CheckBox NoBear;
        private System.Windows.Forms.CheckBox PouncePull;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown HealingTouch_HL;
        private System.Windows.Forms.CheckBox Revive;
        private System.Windows.Forms.CheckBox Rebirth;
        private System.Windows.Forms.CheckBox ThornsTank;
        private System.Windows.Forms.CheckBox MarkOftheWild;
        private System.Windows.Forms.CheckBox GiftoftheWild;
    }
}