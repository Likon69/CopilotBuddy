﻿using System;
using System.Collections.Generic;
using System.Threading;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
namespace Kaboomkin
{
    public partial class Druid
    {

        private readonly Dictionary<SpellPriority, CastRequirements> _BalanceAdds = new Dictionary<SpellPriority, CastRequirements>
        { 
            {new SpellPriority("Moonkin Form", 100), unit => SpellManager.CanCastSpell("Moonkin Form") && !IsMoonkin() && Me.ManaPercent > 2},
            {new SpellPriority("Moonfire", 99), unit => SpellManager.CanCastSpell("Moonfire") && !Me.CurrentTarget.Buffs.ContainsKey("Moonfire") && Me.CurrentTarget.HealthPercent < 20},
             {new SpellPriority("Starfire", 99), unit => SpellManager.CanCastSpell("Starfire") && LastCast == "None"},
	       {new SpellPriority("Typhoon", 60), unit => SpellManager.CanCastSpell("Typhoon")},
             {new SpellPriority("Wrath", 11), unit => SpellManager.CanCastSpell("Wrath") && Me.Buffs.ContainsKey("Eclipse (Solar)")},
            {new SpellPriority("Starfire", 11), unit => SpellManager.CanCastSpell("Starfire")},
             {new SpellPriority("Wrath", 11), unit => SpellManager.CanCastSpell("Wrath")},


        };
        private readonly Dictionary<SpellPriority, CastRequirements> _Balance = new Dictionary<SpellPriority, CastRequirements>
        { 
            //xxAhzz: Modified the spell rotations and added healMana() to preserve mana for feral form
            //{new SpellPriority("Seal of Righteousness", 102), unit => SpellManager.CanCastSpell("Seal of Righteousness") && !Me.Buffs.ContainsKey("Seal of Righteousness")},
            {new SpellPriority("Healing Touch", 103), unit => healMana() && SpellManager.CanCastSpell("Healing Touch") && Me.HealthPercent < Druid._settings.HealingTouch },
            {new SpellPriority("Regrowth", 102), unit => healMana() && SpellManager.CanCastSpell("Regrowth") && Me.HealthPercent < Druid._settings.Rejuvenation && !Me.Buffs.ContainsKey("Regrowth") },
            {new SpellPriority("Rejuvenation", 101), unit => healMana() && SpellManager.CanCastSpell("Rejuvenation") && Me.HealthPercent < Druid._settings.Rejuvenation && !Me.Buffs.ContainsKey("Rejuvenation") },
            {new SpellPriority("Entangling Roots", 100), unit => healMana() && SpellManager.CanCastSpell("Entangling Roots") && !Me.CurrentTarget.Buffs.ContainsKey("Entangling Roots") && Me.CurrentTarget.HealthPercent > 40 && Me.CurrentTarget.Distance > 20 && LastCast != "Entangling Roots" && !isCaster},
            {new SpellPriority("Wrath", 99), unit => SpellManager.CanCastSpell("Wrath") && healMana() && !Me.Combat},
            {new SpellPriority("Moonfire", 98), unit => SpellManager.CanCastSpell("Moonfire") && !Me.CurrentTarget.Buffs.ContainsKey("Moonfire") && healMana()},
            {new SpellPriority("Wrath", 11), unit => SpellManager.CanCastSpell("Wrath") && healMana() },
        };

        private readonly Dictionary<SpellPriority, CastRequirements> _Balance20Plus = new Dictionary<SpellPriority, CastRequirements>
        { 
             {new SpellPriority("Rejuvenation", 103), unit => SpellManager.CanCastSpell("Rejuvenation") && LastCast == "Regrowth" },
            {new SpellPriority("Moonkin Form", 100), unit => SpellManager.CanCastSpell("Moonkin Form") && !IsMoonkin() && Me.ManaPercent > 2},
 {new SpellPriority("Regrowth", 101), unit => SpellManager.CanCastSpell("Regrowth") && Me.HealthPercent < Druid._settings.Rejuvenation && !Me.Buffs.ContainsKey("Regrowth") },
            //{new SpellPriority("Healing Touch", 102), unit => SpellManager.CanCastSpell("Healing Touch") && Me.HealthPercent < Druid._settings.HealingTouch },
            {new SpellPriority("Moonfire", 99), unit => SpellManager.CanCastSpell("Moonfire") && !Me.CurrentTarget.Buffs.ContainsKey("Moonfire") && Me.CurrentTarget.HealthPercent < 20},
            {new SpellPriority("Starfire", 10), unit => SpellManager.CanCastSpell("Starfire") },
             {new SpellPriority("Wrath", 11), unit => SpellManager.CanCastSpell("Wrath") && Me.Buffs.ContainsKey("Eclipse (Solar)")},
             {new SpellPriority("Wrath", 11), unit => SpellManager.CanCastSpell("Wrath")},
            {new SpellPriority("Innervate", 103), unit => SpellManager.CanCastSpell("Innetvate") && Me.ManaPercent < 20},
            //{new SpellPriority("Arcane Missiles", 9), unit => SpellManager.CanCastSpell("Arcane Missiles") && Mage._settings.Com_Low_ArcMissiles}
        };
        private readonly Dictionary<SpellPriority, CastRequirements> _BalanceLevel = new Dictionary<SpellPriority, CastRequirements>
        { 
            {new SpellPriority("Moonkin Form", 100), unit => SpellManager.CanCastSpell("Moonkin Form") && !IsMoonkin() && Me.ManaPercent > 2},
	{new SpellPriority("Starfall", 105), unit => SpellManager.CanCastSpell("Starfall") && getAdds().Count > 1},
            {new SpellPriority("Moonfire", 99), unit => SpellManager.CanCastSpell("Moonfire") && !Me.CurrentTarget.Buffs.ContainsKey("Moonfire") && Me.CurrentTarget.HealthPercent < 20},
             {new SpellPriority("Starfire", 99), unit => SpellManager.CanCastSpell("Starfire") && LastCast == "None"},
 {new SpellPriority("Insect Swarm", 98), unit => SpellManager.CanCastSpell("Insect Swarm") && !Me.CurrentTarget.Buffs.ContainsKey("Insect Swarm") && Me.CurrentTarget.HealthPercent > 79},
	{new SpellPriority("Typhoon", 60), unit => SpellManager.CanCastSpell("Typhoon") && Me.CurrentTarget.Distance < 8},
             {new SpellPriority("Wrath", 11), unit => SpellManager.CanCastSpell("Wrath") && Me.Buffs.ContainsKey("Eclipse (Solar)")},
            {new SpellPriority("Starfire", 11), unit => SpellManager.CanCastSpell("Starfire")},
             {new SpellPriority("Wrath", 11), unit => SpellManager.CanCastSpell("Wrath")},
            {new SpellPriority("Innervate", 110), unit => SpellManager.CanCastSpell("Innetvate") && Me.ManaPercent < 20},

        };
        private readonly Dictionary<SpellPriority, CastRequirements> _BalanceRaid = new Dictionary<SpellPriority, CastRequirements>
        { 

            {new SpellPriority("Moonkin Form", 100), unit => SpellManager.CanCastSpell("Moonkin Form") && !IsMoonkin() && Me.ManaPercent > 2},
            {new SpellPriority("Moonfire", 99), unit => SpellManager.CanCastSpell("Moonfire") && !Me.CurrentTarget.Buffs.ContainsKey("Moonfire") && Me.Combat}, //keep dot up
            {new SpellPriority("Insect Swarm", 80), unit => SpellManager.CanCastSpell("Insect Swarm") && !Me.CurrentTarget.Buffs.ContainsKey("Insect Swarm") && Me.Combat}, // keep dot up
            {new SpellPriority("Moonfire", 95), unit => SpellManager.CanCastSpell("Moonfire") && !Me.CurrentTarget.Buffs.ContainsKey("Moonfire") && !Me.Combat}, //pull spell
            {new SpellPriority("Starfire", 10), unit => SpellManager.CanCastSpell("Starfire") && Me.Buffs.ContainsKey("Eclipse (Lunar)")},
            {new SpellPriority("Wrath", 11), unit => SpellManager.CanCastSpell("Wrath") && Me.Buffs.ContainsKey("Eclipse (Solar)") && !Me.Buffs.ContainsKey("Eclipse (Lunar)")},
            {new SpellPriority("Wrath", 5), unit => SpellManager.CanCastSpell("Wrath")},
            {new SpellPriority("Starfall", 105), unit => SpellManager.CanCastSpell("Starfall") && getAdds().Count > 1},
            {new SpellPriority("Typhoon", 60), unit => SpellManager.CanCastSpell("Typhoon") && Me.CurrentTarget.Distance < 7},
            {new SpellPriority("Innervate", 110), unit => SpellManager.CanCastSpell("Innetvate") && Me.ManaPercent < 20},
           
            
        };

   
        public void PullBalance()
        {
            if (!InstanceBuddyEnabled() && Me.CurrentTarget == null && IsInPartyOrRaid() && RaFHelper.Leader.CurrentTarget != null)
            {
                RaFHelper.Leader.CurrentTarget.Target();
            }
            FindClostestPlayer(29);
            if (Me.CurrentTarget.Distance > 29)
            {
                double RangedRange = 28;

                if (ObjectManager.Me.CurrentTarget.Distance > RangedRange)
                {
                    int a = 0;
                    while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.Distance > RangedRange)
                    {
                        WoWMovement.Face();
                        Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 2.5f));
                        Thread.Sleep(250);
                        FindClostestPlayer(29);
                        ++a;
                    }
                }
            }
            if (Me.CurrentTarget.Distance < 29)
            {
                Me.CurrentTarget.Face();
                if (noCombatMana()) //xxAhzz: Replaced OOM with "noCombatMana()" if true the go feral
                {
                    CombatModeCheck();
                    switch (DruidMode)
                    {
                        case CombatType.Bear:
                            BearTank();
                            break;
                        case CombatType.Cat:
                            CatDps();
                            break;
                        case CombatType.Moonkin:
                            CombatBalance();
                            break;

                    }
                }
                else
                {
                    
                    WoWMovement.MoveStop();
                    if (getAdds().Count < 2 && SpellManager.KnownSpells.ContainsKey("Starfire"))
                    {
                        Enqueue(_BalanceAdds, 1);

                    }
                    else
                        if (getAdds().Count > 2 && SpellManager.KnownSpells.ContainsKey("Starfire"))
                        {
                            Enqueue(_BalanceLevel, 1);
                        }
                        else
                    {
                        Enqueue(_Balance, 1);
                    }
                    

                    if (_rotation.Count > 0)
                        Cast();
                }
                Combat();

            }

            //Combat();
        }
        private void CombatBalance()
        {
            if (!InstanceBuddyEnabled() && Me.CurrentTarget == null && IsInPartyOrRaid() && RaFHelper.Leader.CurrentTarget != null)
            {
                RaFHelper.Leader.CurrentTarget.Target();
            }
            FindClostestPlayer(29);
            if (!Me.Silenced)
            {
                if (Me.CurrentTarget != null)
                {
                    if (Me.ManaPercent < Druid._settings.Inntervate_Bal)
                    {
                        if (SpellManager.CanCastSpell("Innervate"))
                        {
                            CastNowSpell("Innervate");
                        }
                    }

                    if (Me.CurrentTarget.Distance > 29)
                    {
                        double RangedRange = 28;

                        if (ObjectManager.Me.CurrentTarget.Distance > RangedRange)
                        {
                            int a = 0;
                            while (a < 50 && ObjectManager.Me.IsAlive && ObjectManager.Me.GotTarget && ObjectManager.Me.CurrentTarget.Distance > RangedRange)
                            {
                                WoWMovement.Face();
                                Navigator.MoveTo(WoWMovement.CalculatePointFrom(ObjectManager.Me.CurrentTarget.Location, 2.5f));
                                Thread.Sleep(250);
                                FindClostestPlayer(29);
                                ++a;
                            }
                        }
                    }

                    Common();



                    if (SpellManager.CanCastSpell("Force of Nature"))
                    {
                        
                        CastNowSpell("Force of Nature");
                        Thread.Sleep(Lag());
                        SpellManager.ClickRemoteLocation(Me.Location);
                    }

                    if (getAdds().Count > 1)
                    {
                        if (SpellManagerEx.CanCast("Hurricane") && Druid._settings.Huricane_Adds)
                        {
                            CastNowSpell("Barkskin");
                            CastNowSpell("Hurricane");
                            Thread.Sleep(Lag());
                            SpellManager.ClickRemoteLocation(Me.Location);
                            while (Me.Casting != 0)
                            {
                                Thread.Sleep(100);
                            }
                        }
                    }

                    if (noCombatMana()) //xxAhzz: Replaced OOM with "noCombatMana()" if true the go feral
                    {
                        CombatModeCheck();
                        switch (DruidMode)
                        {
                            case CombatType.Bear:
                                slog("Dropped into Bear");
                                BearTank();
                                break;
                            case CombatType.Cat:
                                slog("Droped into Cat");
                                CatDps();
                                break;
                            case CombatType.Moonkin:

                                CombatBalance();
                                break;

                        }
                        return;
                    }
                    else
                    {
                 
                        WoWMovement.MoveStop();
                        if (Druid._settings.RaidRotation)
                        {
                            Enqueue(_BalanceRaid, 1);
                        }
                        else
                        if (getAdds().Count < 2 && SpellManager.KnownSpells.ContainsKey("Starfire"))
                        {
                            Enqueue(_BalanceAdds, 1);

                        }
                        else
                        if (getAdds().Count > 2 && SpellManager.KnownSpells.ContainsKey("Starfire"))
                        {
                            Enqueue(_BalanceLevel, 1);
                        }
                        else
                        {
                            Enqueue(_Balance, 1);
                        }
                        if (_rotation.Count > 0)
                            Cast(); 
                    }


                    combatChecks();
                }
            }
        }
    }
}
