﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Kaboomkin
{
    public partial class KaboomkinConfig : Form
    {
        public KaboomkinConfig()
        {
            InitializeComponent();
            EatAt.Value = new decimal(Druid._settings.EatAt);
            DrinkAt.Value = new decimal(Druid._settings.DrinkAt);
         
           
            HealingTouch.Value = new decimal(Druid._settings.HealingTouch);
            Rejuvenation.Value = new decimal(Druid._settings.Rejuvenation);

            Rejuv_HL.Value = new decimal(Druid._settings.Rejuv_HL);
            Swiftmend_HL.Value = new decimal(Druid._settings.Swiftmend_HL);
            Nourish_HL.Value = new decimal(Druid._settings.Nourish_HL);
            Regrowth_HL.Value = new decimal(Druid._settings.Regrowth_HL);
            Lifebloom_HL.Value = new decimal(Druid._settings.Lifebloom_HL);
            Innervate_HL.Value = new decimal(Druid._settings.Innervate_HL);

            Tranquility.Value = new decimal(Druid._settings.Tranquility);
            Num_TargetsTranquility.Value = new decimal(Druid._settings.Num_TargetsTranquility);
            use_Tranquility.Checked = Druid._settings.use_Tranquility;
            removeCurse.Checked = Druid._settings.removeCurse;
            abolishPosin.Checked = Druid._settings.abolishPosin;

            RaidRotation.Checked = Druid._settings.RaidRotation;
            Huricane_Adds.Checked = Druid._settings.Huricane_Adds;
            Inntervate_Bal.Value = new decimal(Druid._settings.Inntervate_Bal);
            LowMana.Value = new decimal(Druid._settings.LowMana);
            HighMana.Value = new decimal(Druid._settings.HighMana);

            WildGrowth.Value = new decimal(Druid._settings.WildGrowth);
            Num_TargetsWildGrowth.Value = new decimal(Druid._settings.Num_TargetsWildGrowth);
            use_WildGrowth.Checked = Druid._settings.use_WildGrowth;

            FeralCharge.Checked = Druid._settings.FeralCharge;
            NoBear.Checked = Druid._settings.NoBear;
            PouncePull.Checked = Druid._settings.PouncePull;
            HealingTouch_HL.Value = new decimal(Druid._settings.HealingTouch_HL);

            ThornsTank.Checked = Druid._settings.ThornsTank;
            Revive.Checked = Druid._settings.Revive;
            Rebirth.Checked = Druid._settings.Rebirth;
            GiftoftheWild.Checked = Druid._settings.GiftOfTheWild;
            MarkOftheWild.Checked = Druid._settings.MarkOfTheWild;
        }

        private void EatAt_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.EatAt = int.Parse(EatAt.Value.ToString());
        }

        private void DrinkAt_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.DrinkAt = int.Parse(DrinkAt.Value.ToString());
        }

        private void Save_Click(object sender, EventArgs e)
        {
            MessageBox.Show(@"Config Saved");
            Druid._settings.Save();
        }

        private void HealingTouch_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.HealingTouch = int.Parse(HealingTouch.Value.ToString());
        }

        private void Rejuvenation_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.Rejuvenation = int.Parse(Rejuvenation.Value.ToString());
        }

        private void Rejuv_HL_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.Rejuv_HL = int.Parse(Rejuv_HL.Value.ToString());
        }

        private void Swiftmend_HL_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.Swiftmend_HL = int.Parse(Swiftmend_HL.Value.ToString());
        }

        private void Nourish_HL_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.Nourish_HL = int.Parse(Nourish_HL.Value.ToString());
        }

        private void Regrowth_HL_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.Regrowth_HL = int.Parse(Regrowth_HL.Value.ToString());
        }

        private void Lifebloom_HL_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.Lifebloom_HL = int.Parse(Lifebloom_HL.Value.ToString());
        }

        private void Innervate_HL_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.Innervate_HL = int.Parse(Innervate_HL.Value.ToString());
        }

        private void Num_TargetsTranquility_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.Num_TargetsTranquility = int.Parse(Num_TargetsTranquility.Value.ToString());
        }

        private void Tranquility_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.Tranquility = int.Parse(Tranquility.Value.ToString());
        }

        private void use_Tranquility_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.use_Tranquility = use_Tranquility.Checked;
        }

        private void removeCurse_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.removeCurse = removeCurse.Checked;
        }

        private void abolishPosin_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.abolishPosin = abolishPosin.Checked;
        }

        private void Inntervate_Bal_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.Inntervate_Bal = int.Parse(Inntervate_Bal.Value.ToString());
        }

        private void Huricane_Adds_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.Huricane_Adds = Huricane_Adds.Checked;
        }

        private void LowMana_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.LowMana = int.Parse(LowMana.Value.ToString());
        }

        private void HighMana_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.HighMana = int.Parse(HighMana.Value.ToString());
        }

        private void RaidRotation_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.RaidRotation = RaidRotation.Checked;
        }

        private void Num_TargetsWildGrowth_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.Num_TargetsWildGrowth = int.Parse(Num_TargetsWildGrowth.Value.ToString());
        }

        private void WildGrowth_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.WildGrowth = int.Parse(WildGrowth.Value.ToString());
        }

        private void use_WildGrowth_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.use_WildGrowth = use_WildGrowth.Checked;
        }

        private void FeralCharge_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.FeralCharge = FeralCharge.Checked;
        }

        private void NoBear_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.NoBear = NoBear.Checked;
        }

        private void PouncePull_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.PouncePull = PouncePull.Checked;
        }

        private void HealingTouch_HL_ValueChanged(object sender, EventArgs e)
        {
            Druid._settings.HealingTouch_HL = int.Parse(HealingTouch_HL.Value.ToString());
        }

        private void GiftoftheWild_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.GiftOfTheWild = GiftoftheWild.Checked;
        }

        private void MarkOftheWild_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.MarkOfTheWild = MarkOftheWild.Checked;
        }

        private void ThornsTank_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.ThornsTank = ThornsTank.Checked;
        }

        private void Revive_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.Revive = Revive.Checked;
        }

        private void Rebirth_CheckedChanged(object sender, EventArgs e)
        {
            Druid._settings.Rebirth = Rebirth.Checked;
        }


    }
}
