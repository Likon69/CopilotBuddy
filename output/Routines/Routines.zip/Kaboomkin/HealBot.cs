﻿using System;
using System.Collections.Generic;
using System.Threading;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System.Diagnostics;

namespace Kaboomkin
{
    public partial class Druid
    {
        private readonly Dictionary<SpellPriority, CastRequirements> HealRotation = new Dictionary<SpellPriority, CastRequirements> 
        {
            {new SpellPriority("Rebirth", 1), (unit => Me.Combat && !IsBattleGround() && RaFHelper.Leader != null && unit == RaFHelper.Leader && !unit.IsAlive && CanCast("Rebirth") && Druid._settings.Rebirth)},
            {new SpellPriority("Rejuvenation", Druid._settings.Rejuv_HL), (unit => unit.HealthPercent <= Druid._settings.Rejuv_HL && SpellManager.CanCastSpell("Rejuvenation") && !unit.Buffs.ContainsKey("Rejuvenation"))},
            {new SpellPriority("Swiftmend", Druid._settings.Swiftmend_HL), (unit => unit.HealthPercent <= Druid._settings.Swiftmend_HL && (unit.Auras.ContainsKey("Rejuvenation") || unit.Auras.ContainsKey("Regrowth")) && SpellManager.CanCastSpell("Swiftmend") )},
            {new SpellPriority("Nourish", Druid._settings.Nourish_HL), (unit => unit.HealthPercent <= Druid._settings.Nourish_HL && SpellManager.CanCastSpell("Nourish") )},
            {new SpellPriority("Regrowth",Druid._settings.Regrowth_HL), (unit => unit.HealthPercent <= Druid._settings.Regrowth_HL && SpellManager.CanCastSpell("Regrowth") && !unit.Buffs.ContainsKey("Regrowth"))},
            {new SpellPriority("Lifebloom", Druid._settings.Lifebloom_HL), (unit => unit.HealthPercent <= Druid._settings.Lifebloom_HL && SpellManager.CanCastSpell("Lifebloom") && (!unit.Buffs.ContainsKey("Lifebloom") || unit.Buffs["Lifebloom"].StackCount < 3))},
            {new SpellPriority("Tranquility", Druid._settings.Tranquility), (unit =>SpellManager.CanCastSpell("Tranquility") && Druid._settings.use_Tranquility && NeedTranquility())},
            {new SpellPriority("Wild Growth", Druid._settings.WildGrowth), (unit =>SpellManager.CanCastSpell("Wild Growth") && Druid._settings.use_WildGrowth && WillChain(Druid._settings.Num_TargetsWildGrowth, Druid._settings.WildGrowth, unit.Location, true))},
			{new SpellPriority("Healing Touch", Druid._settings.HealingTouch_HL), (unit =>SpellManager.CanCastSpell("Healing Touch") && unit.HealthPercent <= Druid._settings.HealingTouch_HL)},
        };

        private readonly Dictionary<SpellPriority, CastRequirements> _partyBuffs = new Dictionary<SpellPriority, CastRequirements> 
        {
			{new SpellPriority("Revive", 110), (unit => unit.Dead && unit.Distance < 30 && SpellManager.CanCastSpell("Revive") && Me.ManaPercent >= SpellManager.KnownSpells["Revive"].ManaCostPercent && Druid._settings.Revive)},
			{new SpellPriority("Gift of the Wild", 100), (unit => Druid._settings.GiftOfTheWild && HasRegentGift() && !unit.Buffs.ContainsKey("Gift of the Wild") &&  SpellManager.CanCastSpell("Gift of the Wild") && Me.ManaPercent >= 50)},
			{new SpellPriority("Mark of the Wild", 90), (unit => Druid._settings.MarkOfTheWild && !unit.Buffs.ContainsKey("Mark of the Wild") && !unit.Buffs.ContainsKey("Gift of the Wild") && SpellManager.CanCastSpell("Mark of the Wild") && Me.ManaPercent >= 50)},
			{new SpellPriority("Thorns", 85), (unit => Druid._settings.ThornsTank && !unit.Buffs.ContainsKey("Thorns") && !unit.Buffs.ContainsKey("Thorns") && SpellManager.CanCastSpell("Thorns") && RaFHelper.Leader != null && unit == RaFHelper.Leader && Me.ManaPercent >= 50)},
        };	
        private readonly Dictionary<SpellPriority, CastRequirements> _healbotBehavior = new Dictionary<SpellPriority, CastRequirements>
        {
			{new SpellPriority("Tree of Life", 100), unit => Me.Shapeshift != ShapeshiftForm.TreeOfLife && SpellManagerEx.CanCast("Tree of Life") && !Me.Mounted},
            {new SpellPriority("Innervate", 90), unit => Me.ManaPercent < Druid._settings.Innervate_HL && SpellManagerEx.CanCast("Innervate")},
            {new SpellPriority("Every Man for Himself", 80), unit => Me.Race == WoWRace.Human && (Me.Fleeing || Me.Stunned) && SpellManagerEx.CanCast("Every Man for Himself")}
        };

        private void Healbot()
        {
            // Check for behaviors to cast
            Enqueue(_healbotBehavior, 1);

            if (_rotation.Count > 0)
            {
                Cast();
                return;
            }
            // Potions
            if (Me.ManaPercent <= 10 && Me.Combat)
                Healing.UseManaPotion();

            if (Me.HealthPercent <= 10 && Me.Combat)
                Healing.UseHealthPotion();

            if (!Me.Silenced && !Me.Stunned && !Me.Fleeing && !Me.Pacified)
            {
                if (Me.HealthPercent > 1 && !Me.Combat && Me.ManaPercent <= _settings.DrinkAt)
                {
                    Rest();
                }

                if (eType == Druid.DruidType.Restoration)
                {
                    CheckForHeal(HealRotation);
                }
                if (HealTarget != null)
                {
                    Heal();
                    return;
                }
                else if (!IsInPartyOrRaid() && Me.CurrentTarget != null && !Me.CurrentTarget.IsFriendly &&
                         Me.CurrentTarget.HealthPercent > 1)
                {
                    if (Me.CurrentTarget.Distance >= 30 || !Me.CurrentTarget.InLineOfSight)
                    {
                        WoWPoint movePoint;

                        if (Me.CurrentTarget.InLineOfSight)
                        {
                            movePoint = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 27);
                        }
                        else
                        {
                            movePoint = Me.CurrentTarget.Location;
                        }

                        Navigator.MoveTo(movePoint);
                        Thread.Sleep(100);
                        return;
                    }
                    else if (!Me.Combat)
                    {
                        WoWMovement.MoveStop();
                        Thread.Sleep(250);
                    }

                    Enqueue(_HealbotCombat, 1);

                    if (_rotation.Count > 0)
                    {
                        Cast();
                        return;
                    }
                }
                Dispel();
            }
        }
    }
}