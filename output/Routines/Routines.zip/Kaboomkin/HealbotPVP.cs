﻿using System;
using System.Collections.Generic;
using System.Threading;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System.Diagnostics;


namespace Kaboomkin
{
    public partial class Druid
    {
        private readonly Dictionary<SpellPriority, CastRequirements> _HealbotCombat = new Dictionary<SpellPriority, CastRequirements>
        { 
            {new SpellPriority("Moonfire", 99), unit => SpellManager.CanCastSpell("Moonfire") && !Me.CurrentTarget.Buffs.ContainsKey("Moonfire") && Me.Combat}, //keep dot up
            {new SpellPriority("Moonfire", 95), unit => SpellManager.CanCastSpell("Moonfire") && !Me.CurrentTarget.Buffs.ContainsKey("Moonfire") && !Me.Combat}, //pull spell
            {new SpellPriority("Wrath", 11), unit => SpellManager.CanCastSpell("Wrath") && Me.Buffs.ContainsKey("Eclipse (Solar)") && !Me.Buffs.ContainsKey("Eclipse (Lunar)")},
            {new SpellPriority("Wrath", 5), unit => SpellManager.CanCastSpell("Wrath")}, 
        };




        private Stopwatch buffTimer = new Stopwatch();
        private Stopwatch pointTimer = new Stopwatch();

        private void HealbotPvP()
        {
            // Check for behaviors to cast
            Enqueue(_healbotBehavior, 1);

            if (_rotation.Count > 0)
            {
                Cast();
            }

            if (!Me.Silenced && !Me.Stunned && !Me.Fleeing && !Me.Pacified && Me.HealthPercent > 1)
            {
                if (eType == Druid.DruidType.Restoration)
                {
                    CheckForHeal(HealRotation);

                    if (HealTarget != null)
                    {
                        Heal();
                        return;
                    }
                    else if (Me.CurrentTarget != null && !Me.CurrentTarget.IsFriendly && Me.CurrentTarget.Distance < 30)
                    {
                        Enqueue(_HealbotCombat, 1);

                        if (_rotation.Count > 0)
                        {
                            Cast();
                            return;
                        }
                    }
					else
					{
						Dispel();
					}
                }
            }

            if (Battlegrounds.GetCurrentBattleground() == BattlegroundType.WSG || Battlegrounds.GetCurrentBattleground() == BattlegroundType.AV || Battlegrounds.GetCurrentBattleground() == BattlegroundType.AB || Battlegrounds.GetCurrentBattleground() == BattlegroundType.EotS)
            {
                List<WoWPlayer> pList = new List<WoWPlayer>();

                if (Me.RaidMembers.Count > 0)
                {
                    foreach (WoWPlayer p in Me.RaidMembers)
                    {
                        if (p != null && p.IsValid && p.Distance < 80 && p.InLineOfSight && p.HealthPercent > 1 && p != Me && !Styx.Logic.Blacklist.Contains(p.Guid) && p.Class != WoWClass.Rogue && p.Class != WoWClass.Druid)
                            pList.Add(p);
                    }
                }

                if (pList.Count > 1)
                {
                    pList.Sort(delegate(WoWPlayer p1, WoWPlayer p2)
                    { return p2.MaxHealth.CompareTo(p1.MaxHealth); });
                }

                if (!buffTimer.IsRunning)
                    buffTimer.Start();

                if (Me.HealthPercent < 2 || Me.Auras.ContainsKey("Preparation"))
                    buffTimer.Reset();

                if (FollowTarget == null && pList.Count > 0 && Me.HealthPercent > 1 && buffTimer.ElapsedMilliseconds >= 6000)
                {
                    FollowTarget = pList[0];
                    Log("Following {0} with MaxHP: {1}", FollowTarget.Name, FollowTarget.MaxHealth);
                }


                while (ObjectManager.IsInGame && Me != null && Me.IsValid && IsBattleGround() && FollowTarget != null && !Battlegrounds.Finished)
                {
                    List<WoWPlayer> flagList = new List<WoWPlayer>();

                    foreach (WoWPlayer p in Me.RaidMembers)
                    {
                        if (p != null && p.IsValid && p.IsFriendly && p != Me && p.Distance < 80 && p.HealthPercent > 1 && p.MaxHealth > FollowTarget.MaxHealth && !followingFlagCarrier && !Styx.Logic.Blacklist.Contains(p.Guid) && p.Class != WoWClass.Rogue && p.Class != WoWClass.Druid)
                        {
                            Log("Better follow target detected. Reseting");
                            FollowTarget = p;
                            Log("Following {0} with MaxHP: {1}", FollowTarget.Name, FollowTarget.MaxHealth);
                        }

                        if (p != null && p.IsValid && p.IsFriendly && p != Me && p.Distance < 80 && (p.Auras.ContainsKey("Netherstorm Flag") || p.Auras.ContainsKey("Silverwing Flag") || p.Auras.ContainsKey("Warsong Flag")))
                            flagList.Add(p);
                    }

                    if (flagList.Count > 0 && followingFlagCarrier != true)
                    {
                        followingFlagCarrier = true;
                        FollowTarget = flagList[0];
                        Log("Flag Carrier detected !");
                        Log("Following flag carrier: {0} with MaxHP: {1}", FollowTarget.Name, FollowTarget.MaxHealth);
                    }
                    else if (flagList.Count == 0 && followingFlagCarrier == true)
                    {
                        followingFlagCarrier = false;
                        Log("Follow target is no longer a flag carrier. Reseting");
                        FollowTarget = null;
                        return;
                    }

                    //Potions
                    if (Me.ManaPercent <= 10 && Me.Combat)
                        Healing.UseManaPotion();

                    if (Me.HealthPercent <= 10 && Me.Combat)
                        Healing.UseHealthPotion();

                    if (Battlegrounds.Finished)
                    {
                        Log("Battleground has ended. Terminating Healbot");
                        FollowTarget = null;
                        followingFlagCarrier = false;
                        return;
                    }
                    if (FollowTarget.HealthPercent < 2)
                    {
                        Log("Follow Target is dead. Reseting");
                        FollowTarget = null;
                        followingFlagCarrier = false;
                        return;
                    }
                    if (Me.HealthPercent < 2)
                    {
                        Log("You are dead. Reseting");
                        FollowTarget = null;
                        followingFlagCarrier = false;
                        return;
                    }

                    if (Me.HealthPercent > 1 && (FollowTarget.Distance > 35 || !FollowTarget.InLineOfSight) && HealTarget == null)
                    {

                        if (Me != null && !Me.Mounted && !Me.Combat && !Me.Stunned && !Me.Fleeing && !Me.Pacified && Mount.CanMount() && !Me.IsCasting && !SpellManager.GlobalCooldown)
                        {
                            Mount.MountUp();
                            Thread.Sleep(500);
                        }

                        WoWPoint movePoint = WoWMovement.CalculatePointFrom(FollowTarget.Location, 25.0f);

                        if (Navigator.GeneratePath(Me.Location, movePoint).Length == 0)
                        {
                            Log("Can not generate navigation path to follow target. Reseting");
                            Blacklist.Add(FollowTarget.Guid, TimeSpan.FromMinutes(1));
                            FollowTarget = null;
                            followingFlagCarrier = false;
                            return;
                        }
                        else
                        {
                            Navigator.MoveTo(movePoint);
                            Thread.Sleep(100);
                        }
                    }
					

                    if (Me.HealthPercent > 1 && !Me.Combat && Me.ManaPercent <= 10)
                    {
                        Rest();
                    }

                    // Check for behaviors to cast
                    Enqueue(_healbotBehavior, 1);

                    if (_rotation.Count > 0)
                    {
                        Cast();
                    }

                    if (!Me.Silenced && !Me.Stunned && !Me.Fleeing && !Me.Pacified && Me.HealthPercent > 1)
                    {
            
                        if (eType == Druid.DruidType.Restoration)
                        {
                            CheckForHeal(HealRotation);

                            if (HealTarget != null)
                            {
                                Heal();
                                continue;
                            }
                            else if (!FriendNearby() && Me.CurrentTarget != null && !Me.CurrentTarget.IsFriendly && Me.CurrentTarget.Distance < 30)
                            {
                                Enqueue(_HealbotCombat, 1);

                                if (_rotation.Count > 0)
                                {
                                    Cast();
                                    continue;
                                }
                            }
							else
							{							
								Dispel();
							}
                        }
                    }
                }
            }			
		}    
    }
}