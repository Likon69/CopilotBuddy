﻿using System;
using System.Collections.Generic;
using System.Threading;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
namespace Kaboomkin
{
    public partial class Druid
    {
        private readonly Dictionary<SpellPriority, CastRequirements> _PveHeal = new Dictionary<SpellPriority, CastRequirements> 
        {
            {new SpellPriority("Healing Touch", 100), unit => !isFeral && SpellManager.CanCastSpell("Healing Touch") && Me.HealthPercent < Druid._settings.HealingTouch },
            {new SpellPriority("Rejuvenation", 90), unit => !isFeral && SpellManager.CanCastSpell("Rejuvenation") && !Me.Buffs.ContainsKey("Rejuvenation") && Me.HealthPercent < Druid._settings.Rejuvenation && LastCast == "None" },
            {new SpellPriority("Rejuvenation", 80), unit => !isFeral && SpellManager.CanCastSpell("Rejuvenation") && LastCast == "Regrowth" },
            {new SpellPriority("Regrowth", 70), unit => !isFeral && SpellManager.CanCastSpell("Regrowth") && Me.HealthPercent < Druid._settings.Rejuvenation && !Me.Buffs.ContainsKey("Regrowth") },

            //Feral Entries
            {new SpellPriority("Healing Touch", 100), unit => isFeral && healMana() && SpellManager.CanCastSpell("Healing Touch") && Me.HealthPercent < Druid._settings.HealingTouch },
            //{new SpellPriority("Rejuvenation", 90), unit => isFeral && healMana() && SpellManager.CanCastSpell("Rejuvenation") && !Me.Buffs.ContainsKey("Rejuvenation") && Me.HealthPercent < Druid._settings.Rejuvenation && Me.HealthPercent > Druid._settings.HealingTouch },
            {new SpellPriority("Rejuvenation", 80), unit => isFeral && healMana() && SpellManager.CanCastSpell("Rejuvenation") && LastCast == "Regrowth" },
            {new SpellPriority("Regrowth", 70), unit => isFeral && healMana() && SpellManager.CanCastSpell("Regrowth") && Me.HealthPercent < Druid._settings.Rejuvenation && !Me.Buffs.ContainsKey("Regrowth") },
        };

        public void PullCommon()
        {
            if (!Me.CurrentTarget.InLineOfSight && !Me.Combat)
            {
                slog(Me.CurrentTarget.Name + " is not in line of sight, blacklisting for now.");
                Styx.Logic.Blacklist.Add(Me.CurrentTargetGuid, TimeSpan.FromSeconds(10));
                Me.ClearTarget();
                return;
            }
            if (SpellManager.KnownSpells.ContainsKey("Starfire"))
            {
                Enqueue(_PveHeal, 1);
                if (_rotation.Count > 0)
                    Cast();
            }
        }
        public void Common()
        {

            if (Me.Shapeshift == ShapeshiftForm.Bear || Me.Shapeshift == ShapeshiftForm.Cat)
            {
                isFeral = true;
            }
            else
            {
                isFeral = false;
            }

            if (SpellManager.KnownSpells.ContainsKey("Starfire"))
            {
                Enqueue(_PveHeal, 1);
                if (_rotation.Count > 0)
                    Cast(); 
            }
            WoWMovement.Face();
            AutoAttack();
           // Enqueue(_shadowHealPvP, 1);

            //if (_rotation.Count > 0)
            //{
             //   Log("Need a heal !");
             //   Cast();
            //}
        }
    }

}
