﻿using System;
using System.Collections.Generic;
using System.Threading;
using CommonBehaviors.Actions;
using Styx;
using Amplify.Talents;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Sequence = TreeSharp.Sequence;
using System.Linq;
using Action = TreeSharp.Action;

namespace Amplify
{
    public partial class Amplify
    {


        private Composite Frost_rotation()
        {
            return new PrioritySelector(

               new Decorator(ret => AmplifySettings.Instance.Use_ManaGems && GetGemCount() >= 1 && Me.ManaPercent <= AmplifySettings.Instance.ManaGems_MP_Percent,
                   new Action(ctx => useManaGem())),

               new Decorator(ret => AmplifySettings.Instance.Use_Polymorph && NeedToSheep,
                   new Action(ctx => SheepLogic())),

                //Should only be run at low level.
               new Decorator(ret => !HasSheeped() && Me.CurrentTarget.Distance < 6 && SpellManagerEx.CanCast("Frost Nova") && AmplifySettings.Instance.Use_FrostNova,
                   new Sequence(
                       new Action(ret => SpellManagerEx.Cast("Frost Nova")),
                       new Action(ctx => Strafe())

                           )),

             new Decorator(ret => AmplifySettings.Instance.Use_CounterSpell && SpellManagerEx.HasSpell("Counterspell") && SpellManagerEx.CanCast("Counterspell") && Me.CurrentTarget.IsCasting,
                   new PrioritySelector(
                       CreateSpellCheckAndCast("Counterspell"))),

             new Decorator(ret => AmplifySettings.Instance.Use_ManaShield && !Me.Auras.ContainsKey("Mana Shield") && Me.HealthPercent <= AmplifySettings.Instance.ManaShield_Hp_Percent && SpellManagerEx.HasSpell("Mana Shield") && SpellManagerEx.CanCast("Mana Shield"),
                   new PrioritySelector(
                       CreateSpellCheckAndCast("Mana Shield"))),

            new Decorator(ret => SpellManager.KnownSpells.ContainsKey("Evocation") && SpellManagerEx.CanCast("Evocation") && Me.ManaPercent < AmplifySettings.Instance.Evocation_MP_Percent && (Me.Auras.ContainsKey("Mana Shield") || Me.Auras.ContainsKey("Ice Barrier")),
                   new PrioritySelector(
                       CreateSpellCheckAndCast("Evocation"))),

               new Decorator(ret => !SpellManagerEx.HasSpell("Frostbolt"),
                   new PrioritySelector(
                       CreateSpellCheckAndCast("Fireball"))),

               new Decorator(ret => SpellManagerEx.CanCast("Fire Blast") && Me.CurrentTarget.HealthPercent <= AmplifySettings.Instance.FireBlast_Hp_Percent && Me.CurrentTarget.Distance < SpellManagerEx.Spells["Fire Blast"].MaxRange && AmplifySettings.Instance.Use_FireBlast,
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Fire Blast")
                        )),
               new Decorator(ret => SpellManagerEx.CanCast("Frostbolt") && AmplifySettings.Instance.Use_Frostbolt_Low,
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Frostbolt")
                        )),
               new Decorator(ret => SpellManagerEx.CanCast("Fireball") && AmplifySettings.Instance.Use_Fireball_Low,
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Fireball")
                        )),
               new Decorator(ret => SpellManagerEx.CanCast("Arcane Missiles") && AmplifySettings.Instance.Use_ArcaneMissles_Low,
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Arcane Missiles")
                        )),

               new Decorator(ret => SpellManagerEx.CanCast("Shoot") && IsNotWanding() && AmplifySettings.Instance.Use_Wand,
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Shoot")
                        ))
                        );
        }

        
    }
}
