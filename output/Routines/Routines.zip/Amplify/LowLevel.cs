﻿using System;
using System.Collections.Generic;
using System.Threading;
using CommonBehaviors.Actions;
using Styx;
using Amplify.Talents;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Sequence = TreeSharp.Sequence;
using System.Linq;
using Action = TreeSharp.Action;

namespace Amplify
{
    public partial class Amplify
    {


        private Composite Low_rotation()
        {
            return new PrioritySelector(

                
                //Should only be run at low level.
               new Decorator(ret => Me.CurrentTarget != null && !HasSheeped() && Me.CurrentTarget.Distance < 6 && SpellManagerEx.CanCast("Frost Nova") && AmplifySettings.Instance.Use_FrostNova,
                   new Sequence(
                       new Action(ret => SpellManagerEx.Cast("Frost Nova")),
                       new Action(ctx => Strafe())

                           )),
               new Decorator(ret => !SpellManagerEx.HasSpell("Frostbolt"),
                   new PrioritySelector(
                       CreateSpellCheckAndCast("Fireball"))),

               new Decorator(ret => Me.CurrentTarget != null && SpellManagerEx.CanCast("Fire Blast") && Me.CurrentTarget.HealthPercent <= AmplifySettings.Instance.FireBlast_Hp_Percent && AmplifySettings.Instance.Use_FireBlast,
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Fire Blast")
                        )),
               new Decorator(ret => SpellManagerEx.CanCast("Frostbolt") && AmplifySettings.Instance.Use_Frostbolt_Low,
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Frostbolt")
                        )),
               new Decorator(ret => SpellManagerEx.CanCast("Fireball") && AmplifySettings.Instance.Use_Fireball_Low,
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Fireball")
                        )),
               new Decorator(ret => SpellManagerEx.CanCast("Arcane Missiles") && AmplifySettings.Instance.Use_ArcaneMissles_Low,
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Arcane Missiles")
                        ))
                        );
        }
    }
}
