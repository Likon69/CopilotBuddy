﻿using System.Linq;
using System.Threading;
using Styx;
using Styx.Helpers;
using Styx.Logic.Combat;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;

namespace Amplify
{
    public class ActionIdle : Action
    {
        protected override RunStatus Run(object context)
        {
            if (Parent is Selector || Parent is Decorator)
                return RunStatus.Success;

            return RunStatus.Failure;
        }
    }

    public partial class Amplify
    {
        private Composite _restBehavior;
        public override Composite RestBehavior
        {
            get
            {
                if (_restBehavior == null)
                {
                    Log("Creating 'Rest' behavior");
                    _restBehavior = CreateRestBehavior();
                }

                return _restBehavior;
            }
        }

        /// <summary>
        /// Creates the behavior used for resting. Eating/Drinking
        /// </summary>
        /// <returns></returns>
        private Composite CreateRestBehavior()
        {
            return new PrioritySelector(

                // If our health and mana is 100 we make it return failure to make sure 'NeedRest' returns false and allow it to proceed executing other code!
                // also cacel any existing food/drink buff.
                new Decorator(ret => Me.HealthPercent == 100 && Me.ManaPercent == 100,
                              new Action(
                                  delegate
                                  {
                                      if (Me.HasAura("Food") || Me.HasAura("Drink"))
                                          Lua.DoString("CancelUnitBuff('player', 'Food') CancelUnitBuff('player', 'Drink')");

                                      return RunStatus.Failure;
                                  })),

                new Decorator(ctx => Me.IsCasting || Me.Casting != 0 || Me.HasAura("Food") || Me.HasAura("Drink"),
                    new ActionIdle()),

                // Don't rest if we are mounted or swimming
                new Decorator(ctx => !Me.Mounted && !Me.IsSwimming,
                // Decide what and if to do          
                    new PrioritySelector(
                // Check if we need to  take a drink or bite
                        new Decorator(ret => Me.ManaPercent <= AmplifySettings.Instance.RestManaPercentage || Me.HealthPercent <= AmplifySettings.Instance.RestHealthPercentage,
                            new Sequence(
                // Clear our target
                                new Action(ctx => Me.ClearTarget()),
                // Stop moving if we are moving
                                new Action(
                                    delegate
                                    {
                                        WoWMovement.MoveStop();
                                        return Me.IsMoving ? RunStatus.Running : RunStatus.Success;
                                    }),

                                    new Action(ctx => MageRest(null)))
                                    ),

                        new Decorator(ctx => !StyxWoW.Me.NormalBagsFull,
                            new PrioritySelector(
                // Do we need to make Refreshments?
                                new Decorator(ctx => SpellManagerEx.HasSpell("Conjure Refreshment") && RefreshmentCount <= 15,
                                    new Action(ctx => ConjureRefreshment())),

                                    // Do we need to make water?, don't create any if we got refreshments!
                                    new Decorator(ctx => SpellManagerEx.HasSpell("Conjure Water") && WaterCount <= 15 && RefreshmentCount == 0,
                                        new Action(ctx => ConjureWater())),

                                    // Do we need to make food?, don't create any if we got refreshments!
                                    new Decorator(ctx => SpellManagerEx.HasSpell("Conjure Food") && FoodCount <= 15 && RefreshmentCount == 0,
                                        new Action(ctx => ConjureFood()))
                                        )),
                                    // Do we need to make a Gem?, don't create any if we got refreshments!
                                    new Decorator(ctx => AmplifySettings.Instance.Use_ManaGems && GetGemCount() < 1 && SpellManagerEx.CanCast(_gemId),
                                        new Action(ctx => ConjureManaGem()))
                                        )),
                                  // Return 'Success' if we have the food or drink buff as then we should already be drinking
                                  new Decorator(ret => Me.HasAura("Food") || Me.HasAura("Drink"),
                                                new ActionIdle())
                                  );
        }

        private static RunStatus MageRest(object context)
        {
            if (SpellManager.GlobalCooldown)
                return RunStatus.Running;

            if (SpellManagerEx.HasSpell("Conjure Refreshment"))
            {
                if (RefreshmentCount >= 1)
                    SpellManagerEx.Cast(RefreshmentItemId);
            }
            else
            {
                if (Me.ManaPercent <= AmplifySettings.Instance.RestManaPercentage && !Me.HasAura("Drink"))
                {
                    if (WaterCount >= 1)
                    {
                        Styx.Helpers.LevelbotSettings.Instance.DrinkName = WaterItemId.ToString();
                        Styx.Logic.Common.Rest.Feed();
                    }
                    else
                        Styx.Logic.Common.Rest.Feed();
                }

                if (Me.HealthPercent <= AmplifySettings.Instance.RestHealthPercentage && !Me.HasAura("Food"))
                {
                    if (FoodCount >= 1)
                    {
                        Styx.Helpers.LevelbotSettings.Instance.FoodName = FoodItemId.ToString();
                        Styx.Logic.Common.Rest.Feed();
                    }
                    else
                        Styx.Logic.Common.Rest.Feed();
                }
            }

            return RunStatus.Success;
        }

        #region Food & Water / Rest

        private struct MageItemInfo
        {
            private readonly MageItemType _type;
            public int Count { get; private set; }
            public int Spellid { get; private set; }
            public int ItemId { get; private set; }

            public MageItemInfo(MageItemType type)
                : this()
            {
                _type = type;
                int count, spellid, itemid;
                GetMageItemInfo(type, out count, out spellid, out itemid);

                Count = count;
                Spellid = spellid;
                ItemId = itemid;
            }

            private static void GetMageItemInfo(MageItemType type, out int count, out int spellid, out int itemid)
            {
                string spellname = "";
                count = 0;
                itemid = 0;
                spellid = 0;

                switch (type)
                {
                    case MageItemType.Food:
                        spellname = "Conjure Food";
                        break;

                    case MageItemType.Water:
                        spellname = "Conjure Water";
                        break;

                    case MageItemType.Gem:
                        spellname = "Conjure Mana Gem";
                        break;

                    case MageItemType.Refreshment:
                        spellname = "Conjure Refreshment";
                        break;
                }

                if (!string.IsNullOrEmpty(spellname) && SpellManagerEx.HasSpell(spellname))
                {
                    WoWSpell spell = SpellManager.KnownSpells[spellname];
                    int creates = spell.CreatesItemId;
                    itemid = spell.CreatesItemId;
                    spellid = spell.Id;

                    var items = ObjectManager.GetObjectsOfType<WoWItem>().Where(item => item.Entry == creates).ToList();
                    count = items.Aggregate(count, (current, item) => current + (int)item.StackCount);
                }
            }

            public override string ToString()
            {
                return string.Format("[{0}]: Count:{1} SpellId:{2} ItemId:{3}", _type, Count, Spellid, ItemId);
            }
        }

        private static int GetItemCount(MageItemType type)
        {
            var item = new MageItemInfo(type);
            return item.Count;
        }
        private static int GetItemId(MageItemType type)
        {
            var item = new MageItemInfo(type);
            return item.ItemId;
        }
        private static int GetItemSpellId(MageItemType type)
        {
            var item = new MageItemInfo(type);
            return item.Spellid;
        }

        private static int RefreshmentItemId { get { return GetItemId(MageItemType.Refreshment); } }
        private static int FoodItemId { get { return GetItemId(MageItemType.Food); } }
        private static int WaterItemId { get { return GetItemId(MageItemType.Water); } }
        private static int ManaGemItemId { get { return GetItemId(MageItemType.Gem); } }

        private static int RefreshmentSpellId { get { return GetItemSpellId(MageItemType.Refreshment); } }
        private static int FoodSpellId { get { return GetItemSpellId(MageItemType.Food); } }
        private static int WaterSpellId { get { return GetItemSpellId(MageItemType.Water); } }
        private static int ManaGemSpellId { get { return GetItemSpellId(MageItemType.Gem); } }

        private static int RefreshmentCount { get { return GetItemCount(MageItemType.Refreshment); } }
        private static int FoodCount { get { return GetItemCount(MageItemType.Food); } }
        private static int WaterCount { get { return GetItemCount(MageItemType.Water); } }
        private static int ManaGemCount { get { return GetItemCount(MageItemType.Gem); } }

        private static void CreateItem(MageItemType type)
        {
            string spellname = "";

            switch (type)
            {
                case MageItemType.Food:
                    spellname = "Conjure Food";
                    break;
                case MageItemType.Water:
                    spellname = "Conjure Water";
                    break;
                case MageItemType.Gem:
                    spellname = "Conjure Mana Gem";
                    break;
                case MageItemType.Refreshment:
                    spellname = "Conjure Refreshment";
                    break;
            }

            if (!string.IsNullOrEmpty(spellname) && SpellManagerEx.HasSpell(spellname))
                SpellManagerEx.Cast(spellname);
        }

        private void ConjureManaGem()
        {
            Log("Make Mana Gem.");
            SpellManagerEx.Cast(_gemId);
        }
        private static void ConjureFood()
        {
            Log("Conjuring Food");
            CreateItem(MageItemType.Food);
        }
        private static void ConjureWater()
        {
            Log("Conjuring Water");
            CreateItem(MageItemType.Water);
        }
        private static void ConjureRefreshment()
        {
            Log("Conjuring Refreshment");
            CreateItem(MageItemType.Refreshment);
        }

        public enum MageItemType
        {
            Food,
            Refreshment,
            Water,
            Gem
        }

        #endregion
    }
}
