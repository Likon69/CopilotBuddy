﻿using Styx.Logic.Combat;
using TreeSharp;

namespace Amplify
{
    public partial class Amplify
    {
        private Composite _preCombatBuffBehavior;
        public override Composite PreCombatBuffBehavior
        {
            get
            {
                if (_preCombatBuffBehavior == null)
                {
                    Log("Creating 'PreCombatBuff' behavior");
                    _preCombatBuffBehavior = CreatePreCombatBuffsBehavior();
                }

                return _preCombatBuffBehavior;
            }
        }

        /// <summary>
        /// Creates the behavior used for buffing with regular buffs. eg; 'Power Word: Fortitude', 'Inner Fire' etc...
        /// </summary>
        /// <returns></returns>
        private Composite CreatePreCombatBuffsBehavior()
        {
            return new PrioritySelector(

                new Decorator(ret => !Me.Mounted && SpellManager.KnownSpells.ContainsKey("Arcane Intellect") && !Me.Auras.ContainsKey("Arcane Intellect") && !Me.Auras.ContainsKey("Fel Intelligence") && !Me.Auras.ContainsKey("Dalaran Intellect") && !Me.Auras.ContainsKey("Arcane Brilliance") && !Me.Auras.ContainsKey("Dalaran Brilliance") && !Me.Auras.ContainsKey("Wisdom of Agamaggan"),
                              new PrioritySelector(
                                  CreateBuffCheckAndCast("Arcane Intellect")
                                  )),

                new Decorator(ret => !Me.Mounted && !SpellManager.KnownSpells.ContainsKey("Ice Armor") && !Me.Mounted && SpellManager.KnownSpells.ContainsKey("Frost Armor") && AmplifySettings.Instance.ArmorSelect == 0 || AmplifySettings.Instance.ArmorSelect == 1,
                              new PrioritySelector(
                                  CreateBuffCheckAndCast("Frost Armor", true)
                                  )),

                new Decorator(ret => !Me.Mounted && !SpellManager.KnownSpells.ContainsKey("Mage Armor") && !Me.Mounted && SpellManager.KnownSpells.ContainsKey("Ice Armor") && SpellManager.KnownSpells.ContainsKey("Frost Armor") && AmplifySettings.Instance.ArmorSelect == 0 || AmplifySettings.Instance.ArmorSelect == 2,
                              new PrioritySelector(
                                  CreateBuffCheckAndCast("Ice Armor", true)
                                  )),


                new Decorator(ret => !Me.Mounted && !SpellManager.KnownSpells.ContainsKey("Molten Armor") && !Me.Mounted && SpellManager.KnownSpells.ContainsKey("Mage Armor") && SpellManager.KnownSpells.ContainsKey("Ice Armor") && SpellManager.KnownSpells.ContainsKey("Frost Armor") && AmplifySettings.Instance.ArmorSelect == 0 || AmplifySettings.Instance.ArmorSelect == 3,
                              new PrioritySelector(
                                  CreateBuffCheckAndCast("Mage Armor", true)
                                  )),

                new Decorator(ret => !Me.Mounted && SpellManager.KnownSpells.ContainsKey("Molten Armor") && !Me.Mounted && SpellManager.KnownSpells.ContainsKey("Mage Armor") && SpellManager.KnownSpells.ContainsKey("Ice Armor") && SpellManager.KnownSpells.ContainsKey("Frost Armor") && AmplifySettings.Instance.ArmorSelect == 0 || AmplifySettings.Instance.ArmorSelect == 4,
                              new PrioritySelector(
                                  CreateBuffCheckAndCast("Molten Armor", true)
                                  )),

                 new Decorator(ret => AmplifySettings.Instance.AmplifyMagic && SpellManagerEx.CanCast("Amplify Magic") && !Me.Mounted && !Me.Auras.ContainsKey("Amplify Magic"),
                              new PrioritySelector(
                                  CreateBuffCheckAndCast("Amplify Magic", true)
                                  )),


                 new Decorator(ret => AmplifySettings.Instance.DampenMagic && SpellManagerEx.CanCast("Dampen Magic") && !Me.Mounted && !Me.Auras.ContainsKey("Dampen Magic"),
                              new PrioritySelector(
                                  CreateBuffCheckAndCast("Dampen Magic", true)
                                  )),

                    new Decorator(ret => Me.GotAlivePet && SpellManager.KnownSpells.ContainsKey("Focus Magic") && !Me.Mounted && SpellManagerEx.CanCast("Focus Magic") && !Me.Pet.Auras.ContainsKey("Focus Magic") && AmplifySettings.Instance.FocusMagicPet,
                              new Action(delegate
                              {
                                  Me.Pet.Target();
                                  Log("Water Elemental does not have Buff Buffing Focus Magic");
                                  SpellManagerEx.Cast("Focus Magic");
                                  Me.ClearTarget();
                              }))

                );
        }
    }
}
