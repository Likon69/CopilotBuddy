﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
//using Merlin.Gui;
using Amplify.Talents;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Helpers;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Action = TreeSharp.Action;
using Color = System.Drawing.Color;

namespace Amplify
{
    public partial class Amplify : CombatRoutine
    {
        private readonly Version _version = new Version(1, 0, 0);
        private readonly TalentManager _talentManager = new TalentManager();
        private static LocalPlayer Me { get { return StyxWoW.Me; } }
        public override string Name { get { return "Amplify " + _version; } }
        public override WoWClass Class { get { return WoWClass.Mage; } }
        public new double? PullDistance
        {
            get
            {
                if (!SpellManagerEx.HasSpell("Frostbolt"))
                {
                    return SpellManagerEx.Spells["Fireball"].MaxRange;
                }
                else
                if (SpellManagerEx.HasSpell("Fireball") && AmplifySettings.Instance.Pull_Fireball)
                {
                    return SpellManagerEx.Spells["Fireball"].MaxRange;
                }
                else
                if (SpellManagerEx.HasSpell("Frostbolt") && AmplifySettings.Instance.Pull_Frostbolt)
                {
                    return SpellManagerEx.Spells["Frostbolt"].MaxRange;
                }
                else
                if (SpellManagerEx.HasSpell("Arcane Missiles") && AmplifySettings.Instance.Pull_ArcaneMissles)
                {
                    return SpellManagerEx.Spells["Arcane Missiles"].MaxRange;
                }
                else

               return 30;
 
            }
        }

        public override void Initialize()
        {
            Logging.Write(Color.DarkSlateBlue, "------------------------------------------------------------------------------------------------------------------");
            Logging.Write(Color.DarkSlateBlue, "[{0}] is a BT Mage Routine.!", Name);
            Logging.Write(Color.DarkSlateBlue, "Localplayer is a, level {0} {1} {2}-{3} currently in {4}", Me.Level, Me.Race, _talentManager.Spec, Me.Class, Me.RealZoneText);
            Logging.Write(Color.DarkSlateBlue, "------------------------------------------------------------------------------------------------------------------");
        }

        public override bool WantButton { get { return true; } }
    
        private Form _configForm;
        public override void OnButtonPress()
        {
            if (_configForm == null || _configForm.IsDisposed || _configForm.Disposing)
                _configForm = new AmplifyConfig();

            _configForm.ShowDialog();
        }
        public Amplify()
        {
          if (_talentManager.Spec == MageTalentSpec.Lowbie)
          {
                Log("You have no Current Spec");
          }
          if (_talentManager.Spec == MageTalentSpec.Arcane)
          {
              Log("Current Spec is Aracne.");
          }
          if (_talentManager.Spec == MageTalentSpec.Frost)
          {
              Log("Current Spec is Frost.");
          }
          if (_talentManager.Spec == MageTalentSpec.Fire)
          {
              Log("Current Spec is Fire.");
          }
        }
    }

    public partial class Amplify
    {
        private static string _logSpam;
        private static void Log(string format, params object[] args)
        {
            string s = Utilities.FormatString(format, args);

            if (s != _logSpam)
            {
                Logging.Write(Color.DarkSlateBlue, "[Amplify]: {0}", string.Format(format, args));
                _logSpam = s;
            }
        }

        private static void Log(string format)
        {
            Log(format, new object());
        }

        #region Behavior Tree Composite Helpers

        public delegate WoWUnit UnitSelectDelegate(object context);
        public Composite CreateBuffCheckAndCast(string name)
        {
            return new Decorator(ret => SpellManagerEx.CanBuff(name),
                                 new Action(ret => SpellManagerEx.Buff(name)));
        }

        public Composite CreateBuffCheckAndCast(string name, UnitSelectDelegate onUnit)
        {
            return new Decorator(ret => SpellManagerEx.CanBuff(name, onUnit(ret)),
                                 new Action(ret => SpellManagerEx.Buff(name, onUnit(ret))));
        }

        public Composite CreateBuffCheckAndCast(string name, CanRunDecoratorDelegate extra)
        {
            return new Decorator(ret => extra(ret) && SpellManagerEx.CanBuff(name),
                                 new Action(ret => SpellManagerEx.Buff(name)));
        }
        public Composite CreateBuffCheckAndCast(string name, bool OnMe)
        {
            return new Decorator(ret => !Me.Auras.ContainsKey(name),
                                  new Action(ret => SpellManagerEx.Buff(name)));
        }
        public Composite CreateBuffCheckAndCast(string name, UnitSelectDelegate onUnit, CanRunDecoratorDelegate extra)
        {
            return CreateBuffCheckAndCast(name, onUnit, extra, false);
        }

        public Composite CreateBuffCheckAndCast(string name, UnitSelectDelegate onUnit, CanRunDecoratorDelegate extra, bool targetLast)
        {
            return new Decorator(ret => extra(ret) && SpellManagerEx.CanBuff(name, onUnit(ret)),
                                 new Action(ret => SpellManagerEx.Buff(name, onUnit(ret))));
        }

        public static Composite CreateSpellCheckAndCast(string name)
        {
            return new Decorator(ret => SpellManagerEx.CanCast(name),
                                 new Action(ret => SpellManagerEx.Cast(name))
                                 );
        }

        public Composite CreateSpellCheckAndCast(string name, WoWUnit onUnit)
        {
            return new Decorator(ret => SpellManagerEx.CanCast(name),
                                 new Action(ret => SpellManagerEx.Cast(name, onUnit)));
        }

        public Composite CreateSpellCheckAndCast(string name, CanRunDecoratorDelegate extra)
        {
            return new Decorator(ret => extra(ret) && SpellManagerEx.CanCast(name),
                                 new Action(ret => SpellManagerEx.Cast(name)));
        }

        public Composite CreateSpellCheckAndCast(string name, bool checkRange)
        {
            return new Decorator(ret => SpellManagerEx.CanCast(name, checkRange),
                                 new Action(ret => SpellManagerEx.Cast(name)));
        }

        public Composite CreateSpellCheckAndCast(string name, CanRunDecoratorDelegate extra, ActionDelegate extraAction)
        {
            return new Decorator(ret => extra(ret) && SpellManagerEx.CanCast(name),
                                 new Action(delegate(object ctx)
                                 {
                                     SpellManagerEx.Cast(name);
                                     extraAction(ctx);
                                     return RunStatus.Success;
                                 }));
        }
        public Composite CreateSpellCheckAndCast(string name, string Buffname)
        {
        
            return new Decorator(ret => SpellManagerEx.CanCast(name),
                                 new Action(delegate
                                 {
                                     SpellManagerEx.Cast(name);
                                     StyxWoW.SleepForLagDuration();
                                     if (Me.CurrentTarget.Auras.ContainsKey(Buffname))
                                     {
                                         SpellManagerEx.StopCasting();
                                     }
                                     return RunStatus.Success;
                                 })
                                 );
        }
        public Composite CreateSpellCheckAndCast(string name, CanRunDecoratorDelegate extra, ActionDelegate extraAction, WoWUnit onUnit)
        {
            return new Decorator(ret => extra(ret) && SpellManagerEx.CanCast(name),
                                 new Action(delegate(object ctx)
                                 {
                                     SpellManagerEx.Cast(name, onUnit);
                                     extraAction(ctx);
                                     return RunStatus.Success;
                                 }));
        }

        public Composite SummonPet(string PetSpellName)
        {

            return new Decorator(ret => SpellManagerEx.CanCast(PetSpellName) && !Me.GotAlivePet,
                                 new Action(delegate
                                 {
                                     SpellManagerEx.Cast(PetSpellName);
                                     StyxWoW.SleepForLagDuration();
                                     if (Me.GotAlivePet)
                                     {
                                         SpellManagerEx.StopCasting();
                                     }
                                     return RunStatus.Success;
                                 })
                                 );
        }

        #endregion
    }
}
