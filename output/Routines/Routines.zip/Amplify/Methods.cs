﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Linq;
using Styx;
using Styx.Helpers;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Action = System.Action;
using Sequence = TreeSharp.Sequence;


namespace Amplify
{
    public partial class Amplify
    {
      
            public static bool GotSheep
            {
                get
                {
                    List<WoWUnit> sheepList =
                        (from o in ObjectManager.ObjectList
                         where o is WoWUnit
                         let p = o.ToUnit()
                         where p.Distance < 30
                               && p.HasAura("Polymorph")
                         select p).ToList();

                    return sheepList.Count > 0;
                }
            }

            public static WoWUnit SheepedMob
            {
                get
                {
                    List<WoWUnit> sheepList =
                        (from o in ObjectManager.ObjectList
                         where o is WoWUnit
                         let p = o.ToUnit()
                         where p.Distance < 30
                               && p.HasAura("Polymorph")
                         select p).ToList();

                    return sheepList[0];
                }
            }

            private static WoWUnit PolyTarget
            {
                get
                {
                    List<WoWUnit> sheepList =
                        (from o in ObjectManager.ObjectList
                         where o is WoWUnit
                         let p = o.ToUnit()
                         where p.Distance < 31
                               && p.Guid != Me.Guid
                               && p.Aggro
                               && (p.CreatureType == WoWCreatureType.Humanoid || p.CreatureType == WoWCreatureType.Beast)
                               && !p.Dead
                               && p.InLineOfSight
                               && p.HealthPercent > 92
                         //&& p.Guid != Me.CurrentTargetGuid
                         //&& !p.HasAura("Mark of the Wild")
                         orderby p.HealthPercent descending
                         select p).ToList();

                    return sheepList.Count > 0 ? sheepList[0] : null;
                }
            }

            public static WoWUnit NonSheepedMob
            {
                get
                {
                    ObjectManager.Update();

                    List<WoWUnit> mobList =
                        (from o in ObjectManager.ObjectList
                         where o is WoWUnit
                         let p = o.ToUnit()
                         where p.Distance < 35
                               && p.Guid != Me.Guid
                               && p.Aggro
                             //&& (p.CreatureType == WoWCreatureType.Humanoid || p.CreatureType == WoWCreatureType.Beast)
                               && !p.Dead
                               && p.InLineOfSight
                             //&& p.HealthPercent > 95
                             //&& p.Guid != Me.CurrentTargetGuid
                         && !p.HasAura("Polymorph")
                         orderby p.HealthPercent ascending, p.Distance ascending
                         select p).ToList();

                    return mobList.Count > 0 ? mobList[0] : null;
                }
            }

            public static bool NeedToSheep
            {
                get
                {
                    if (GotSheep) return false;
                    if (!Adds()) return false;
                    if (!SpellManagerEx.HasSpell("Polymorph")) return false;

                    if (PolyTarget != null) return true;
                    return false;
                }
            }

  

        public static void SheepLogic()
        {
            List<WoWUnit> AddList = ObjectManager.GetObjectsOfType<WoWUnit>(false).FindAll(unit =>
       unit.Guid != Me.Guid &&
       unit.IsTargetingMeOrPet &&
       !unit.IsFriendly &&
       unit != Me.CurrentTarget &&
       !Styx.Logic.Blacklist.Contains(unit.Guid));

            if (AddList.Count > 0 && !GotSheep)
            {
                Log("Got adds Lets Polymorph a Target");
                WoWUnit SheepAdd = AddList[0].ToUnit();
                Log("Casting Poly on {0}", SheepAdd.Name);
                SpellManagerEx.Cast("Polymorph", SheepAdd);
                Thread.Sleep(300);
            }
        }
            public static void SheepMob()
            {

                if (PolyTarget == null)
                {
                    if (Me.IsCasting)
                    {
                        //Lua.DoString("SpellStopCasting()");
                        SpellManagerEx.StopCasting();
                        Log("Interrupting spell casting to cast Polymorph! ", System.Drawing.Color.FromName("DarkRed"));
                    }
                    Log("Casting Sheep on " + PolyTarget.Name + " - protect the sheep from the Australians");
                    //WoWUnit originalTarget = Me.CurrentTarget;

                    PolyTarget.Target();
                    Thread.Sleep(850);
                    SpellManagerEx.Cast("Polymorph");
                    Thread.Sleep(1000);
                    while (Me.IsCasting)
                    {
                        Thread.Sleep(250);
                    }

                    ObjectManager.Update();
                    Thread.Sleep(300);
                    //Thread.Sleep(250);

                    WoWUnit NewMobTarget = NonSheepedMob;
                    NewMobTarget.Target();
                    NewMobTarget.Face();

                }
            }

        public static void retargetSheep()
        {
            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false);

            foreach (WoWUnit sheep in mobList)
            {
                if (sheep.Auras.ContainsKey("Polymorph"))
                {
                    sheep.Target();
                    Thread.Sleep(200);
                }
            }
        }

        public static bool IsInPartyOrRaid()
        {
            if (Me.PartyMembers.Count > 0)
                return true;

            return false;
        }
        public static List<WoWUnit> getAdds()
        {
            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false).FindAll(unit =>
                unit.Guid != Me.Guid &&
                unit.IsTargetingMeOrPet &&
                !unit.IsFriendly &&
                !Styx.Logic.Blacklist.Contains(unit.Guid));

            return mobList;

        }
        public static bool Adds()
        {
            List<WoWUnit> mobList = ObjectManager.GetObjectsOfType<WoWUnit>(false).FindAll(unit =>
                unit.Guid != Me.Guid &&
                unit.IsTargetingMeOrPet &&
                !unit.IsFriendly &&
                !Styx.Logic.Blacklist.Contains(unit.Guid));

            if (mobList.Count > 0)
            {
                return true;
            }
            else
                return false;

        }
        public static bool HasSheeped()
        {
            List<WoWUnit> SheepedList = ObjectManager.GetObjectsOfType<WoWUnit>(false).FindAll(unit =>
unit.Guid != Me.Guid &&
unit.Auras.ContainsKey("Polymorph"));
            if (SheepedList.Count > 0)
            {
                Log("Sheeped Target Detected disabling Frostnova");
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool IsNotWanding()
        {
            if (Me.AuthRepeatingSpellId != 5019)
            {
                return true;
            }
            else
            {

                return false;
            }

        }
        private int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }



        private void Strafe()
        {

            WoWMovement.Move(WoWMovement.MovementDirection.StrafeRight);
            WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
            WoWMovement.Face();
            ConeOfCold();
            WoWMovement.MoveStop(WoWMovement.MovementDirection.StrafeRight);
            WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
            Log("Strife Jump");
            if (Me.CurrentTarget != null)
            {
                if (Me.CurrentTarget.BoundingRadius < Me.CurrentTarget.Distance)
                {
                    Log("Im still in hitting Range strife jumping again.");
                    WoWMovement.Move(WoWMovement.MovementDirection.StrafeRight);
                    WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                    Thread.Sleep(50);
                    WoWMovement.MoveStop(WoWMovement.MovementDirection.StrafeRight);
                    WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
                }
            }
            WoWMovement.Face();
        }
        private void ConeOfCold()
        {
            if (Me.CurrentTarget != null)
            {
                if (Me.GotTarget && SpellManagerEx.CanCast("Cone of Cold"))
                {
                    if (Me.CurrentTarget.Distance < 10)
                    {
                        WoWMovement.Face();
                        Log("Cone of Cold.");
                        SpellManagerEx.Cast("Cone of Cold");
                    }
                }
            }
        }



        private WoWItem myManaGems
        {
            get
            {
                return HaveItemCheck(_NewGemEntryId);
            }
        }
        private bool useManaGemCooldown
        {
            get
            {
                if (Equals(null, myManaGems))
                    return false;

                if (isItemInCooldown(myManaGems))
                {
                    return false;
                }


                return true;
            }

        }
        public bool isItemInCooldown(WoWItem item)
        {
            if (Equals(null, item))
                return true;

            string cd_st;
            Lua.DoString("s=GetItemCooldown(" + item.Entry + ")");
            cd_st = Lua.GetLocalizedText("s", ObjectManager.Me.BaseAddress);
            if (cd_st == "0")
                return false;

            return true;

        }
        private static Dictionary<int, int> _gem =
new Dictionary<int, int>() //Mana gem dictionary, DONT EDIT!
        {
            //Mana Gem
            //(uint spellId, uint itemId)
            {42985, 33312},             //77
            {27101, 22044},             //68
            {10054, 8008},              //58
            {10053, 8007},              //48
            {3552, 5513},               //38
            {759, 5514},                //28

        };

     private WoWItem HaveItemCheck(List<int> listId)
        {
            foreach (WoWItem item in ObjectManager.GetObjectsOfType<WoWItem>(false))
            {
                if (listId.Contains(Convert.ToInt32(item.Entry)))
                {
                   
                    return item;
                }
            }
            return null;
        }

        private static int GetGemCount() //Name speaks for itself, modify with caution.
        {
            int managemcount = 0;

            foreach (KeyValuePair<int, int> spellgem in _gem)
            {
                if (SpellManagerEx.CanCast(spellgem.Key))
                {
                    managemEntryId = spellgem.Value;

                    _gemId = spellgem.Key;
                    break;
                }
            }

            if (managemEntryId > 0)
            {
                managemcount = Convert.ToInt32(Lua.LuaGetReturnValue("return GetItemCount(\"" + managemEntryId.ToString() + "\")", "hawker.lua")[0]);
            }

            if (!Equals(null, managemcount))
            {
                return managemcount;
            }

            // stop it spamming if lua fails for some reason
            return 1;
        }
        private readonly List<int> _NewGemEntryId = new List<int>
        {
            33312, 22044, 8008, 8007, 5513, 5514,
        };
        private void useManaGem() //your choice.
        {
            if (GetGemCount() >= 1 && useManaGemCooldown == true)
            {
                Lua.DoString("UseItemByName(\"" + myManaGems.Name + "\")");
                Log("Poping a ManaGem by Command.");
            }

        }

         private static int managemEntryId = 0;
        private static int _gemId = 0;



    }
}
