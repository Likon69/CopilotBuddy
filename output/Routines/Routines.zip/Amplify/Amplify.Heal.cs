﻿
using Styx.Logic.Combat;
using TreeSharp;
using Action = TreeSharp.Action;

namespace Amplify
{
    public partial class Amplify
    {
        private Composite _healBehavior;
        public override Composite HealBehavior
        {
            get
            {
                if (_healBehavior == null)
                {
                    Log("Creating 'Heal' behavior");
                    _healBehavior = CreateHealBehavior();
                }

                return _healBehavior;
            }
        }

        /// <summary>
        /// Creates the behavior used for healing
        /// </summary>
        /// <returns></returns>
        private static Composite CreateHealBehavior()
        {
            return new PrioritySelector(

                // Cast lifeblood if we have it
                new Decorator(ret => SpellManagerEx.HasSpell("Lifeblood") && SpellManagerEx.CanCast("Lifeblood"),
                              new Action(ret => SpellManagerEx.Cast("Lifeblood")))

               
                );
        }
    }
}
