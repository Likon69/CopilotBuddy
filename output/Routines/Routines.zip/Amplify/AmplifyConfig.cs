﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Amplify
{
    public partial class AmplifyConfig : Form
    {
        public AmplifyConfig()
        {
            InitializeComponent();
        }

        private void AmplifyConfig_Load(object sender, EventArgs e)
        {

            AmplifySettings.Instance.Load();
            propertyGrid1.SelectedObject = AmplifySettings.Instance;

        }
        private void FormConfig_FormClosing(object sender, FormClosingEventArgs e)
        {
            var dr = MessageBox.Show(
                "Save before closing?",
                "Warning",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Information);

            if (dr == DialogResult.Yes)
                AmplifySettings.Instance.Save();
        }

        private void SaveClose_Click(object sender, EventArgs e)
        {
            var dr = MessageBox.Show(
    "Save before closing?",
    "Warning",
    MessageBoxButtons.YesNo,
    MessageBoxIcon.Information);

            if (dr == DialogResult.Yes)
                AmplifySettings.Instance.Save();
        }
    }
}
