﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Xml;
using Hera.Helpers;
using Styx.Helpers;

namespace Hera.Config
{
   
    public static class Settings
    {
        private const string FileName = @"CustomClasses\Fpsware Mage\Class Specific\Config\Settings.xml";
        private static string _fullFileNameAndPath = "";

        // Common settings template
        public static bool DirtyData { get; set; }
        public static int RestHealth { get; set; }
        public static int RestMana { get; set; }
        public static string Debug { get; set; }
        public static string RAFTarget { get; set; }
        public static string ShowUI { get; set; }
        public static string SmartEatDrink { get; set; }
        public static int CombatTimeout { get; set; }
        public static int HealthPotion { get; set; }
        public static string Cleanse { get; set; }






        public static void Save()
        {
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(_fullFileNameAndPath);
                string currentXMLKey = "NO KEY READ YET";

                Type type = typeof(Settings); PropertyInfo[] props = type.GetProperties();
                foreach (var p in props)
                {
                    if (p.Name == "DirtyData") continue;

                    PropertyInfo pInfo = type.GetProperty(p.Name);
                    object propValue = pInfo.GetValue(p.Name, null);

                    currentXMLKey = "//Mage/" + p.Name;
                    xmlDoc.SelectSingleNode(currentXMLKey).InnerText = propValue.ToString();
                }

                xmlDoc.Save(_fullFileNameAndPath);
                Utils.Log("Settings have been updated");
            }
            catch (Exception e)
            {
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug(" ");
                Logging.WriteDebug(" ");
                Logging.WriteDebug(String.Format("Exception in XML Save {0}", e.Message));
                Logging.WriteDebug(" ");
                Logging.WriteDebug(" ");
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug("**********************************************************************");
            }
        }

        public static void Load()
        {
            string currentXMLKey = "NO KEY READ YET";

            try
            {
                XmlTextReader reader; XmlNode xvar;

                string sPath = Process.GetCurrentProcess().MainModule.FileName;
                sPath = Path.GetDirectoryName(sPath);
                sPath = Path.Combine(sPath, FileName);
                _fullFileNameAndPath = sPath;

                Utils.Log("Loading settings from the config file...");

                try { reader = new XmlTextReader(sPath); } catch (Exception e) { Logging.WriteDebug(String.Format("Error loading configuration file: {0}", e.Message)); return; }
                XmlDocument xml = new XmlDocument();
                xml.Load(reader);

                Type type = typeof(Settings); PropertyInfo[] props = type.GetProperties();
                foreach (var p in props)
                {
                    if (p.Name == "DirtyData") continue;

                    PropertyInfo pInfo = type.GetProperty(p.Name);
                    //object propValue = pInfo.GetValue(p.Name, null);

                    currentXMLKey = "//Mage/" + p.Name;
                    xvar = xml.SelectSingleNode(currentXMLKey);

                    switch (pInfo.PropertyType.Name)
                    {
                        case "Boolean": if (xvar != null) { bool tmp = Convert.ToBoolean(xvar.InnerText); p.SetValue(type, tmp, null); } break; 
                        case "String": if (xvar != null) { string tmp = Convert.ToString(xvar.InnerText); p.SetValue(type, tmp, null); } break; 
                        case "Int32": if (xvar != null) { int tmp = Convert.ToInt16(xvar.InnerText); p.SetValue(type, tmp, null); } break;  
                    }

                    Utils.Log("-Setting: " + p.Name + "  Value: " + xvar.InnerText.ToString());
                }

                reader.Close();
                Utils.Log("Finished loading settings");
            }
            
            catch (Exception e)
            {
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug(" ");
                Logging.WriteDebug(" ");
                Logging.WriteDebug(String.Format("Exception in XML Load: {0}", e.Message)); Logging.WriteDebug("-- Attempted to read: " + currentXMLKey);
                Logging.WriteDebug(" ");
                Logging.WriteDebug(" ");
                Logging.WriteDebug("**********************************************************************");
                Logging.WriteDebug("**********************************************************************");
            }
        }
    }
}