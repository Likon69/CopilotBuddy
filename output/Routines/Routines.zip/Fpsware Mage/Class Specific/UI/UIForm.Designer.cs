﻿namespace Hera.UI
{
    partial class UIForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BottomPanel = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.lblCCName = new System.Windows.Forms.Label();
            this.SaveSettings = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ArcaneExplosion = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ArcaneShot = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.KillCommand = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BlackArrow = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ExplosiveShot = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SerpentSting = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.FeignDeathHealth = new System.Windows.Forms.ProgressBar();
            this.MendPetHealth = new System.Windows.Forms.ProgressBar();
            this.label13 = new System.Windows.Forms.Label();
            this.HealthPotion = new System.Windows.Forms.ProgressBar();
            this.label12 = new System.Windows.Forms.Label();
            this.RestHealth = new System.Windows.Forms.ProgressBar();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.RAFTarget = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Debug = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.BottomPanel.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // BottomPanel
            // 
            this.BottomPanel.BackColor = System.Drawing.Color.White;
            this.BottomPanel.Controls.Add(this.label20);
            this.BottomPanel.Controls.Add(this.lblCCName);
            this.BottomPanel.Controls.Add(this.SaveSettings);
            this.BottomPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BottomPanel.Location = new System.Drawing.Point(0, 526);
            this.BottomPanel.Name = "BottomPanel";
            this.BottomPanel.Size = new System.Drawing.Size(639, 47);
            this.BottomPanel.TabIndex = 0;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.DimGray;
            this.label20.Location = new System.Drawing.Point(5, 32);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 13);
            this.label20.TabIndex = 54;
            this.label20.Text = "by Fpsware";
            // 
            // lblCCName
            // 
            this.lblCCName.AutoSize = true;
            this.lblCCName.BackColor = System.Drawing.Color.Transparent;
            this.lblCCName.Font = new System.Drawing.Font("Impact", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCCName.ForeColor = System.Drawing.Color.Gray;
            this.lblCCName.Location = new System.Drawing.Point(1, -1);
            this.lblCCName.Name = "lblCCName";
            this.lblCCName.Size = new System.Drawing.Size(81, 39);
            this.lblCCName.TabIndex = 53;
            this.lblCCName.Text = "HERA";
            // 
            // SaveSettings
            // 
            this.SaveSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.SaveSettings.Location = new System.Drawing.Point(507, 12);
            this.SaveSettings.Name = "SaveSettings";
            this.SaveSettings.Size = new System.Drawing.Size(120, 23);
            this.SaveSettings.TabIndex = 0;
            this.SaveSettings.Text = "Save && Close";
            this.SaveSettings.UseVisualStyleBackColor = true;
            this.SaveSettings.Click += new System.EventHandler(this.SaveSettings_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(639, 526);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(631, 500);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Common";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ArcaneExplosion);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.ArcaneShot);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.KillCommand);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.BlackArrow);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.ExplosiveShot);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.SerpentSting);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(8, 149);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(305, 345);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Combat";
            // 
            // ArcaneExplosion
            // 
            this.ArcaneExplosion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ArcaneExplosion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ArcaneExplosion.FormattingEnabled = true;
            this.ArcaneExplosion.Items.AddRange(new object[] {
            "... always",
            "... never"});
            this.ArcaneExplosion.Location = new System.Drawing.Point(119, 19);
            this.ArcaneExplosion.Name = "ArcaneExplosion";
            this.ArcaneExplosion.Size = new System.Drawing.Size(180, 21);
            this.ArcaneExplosion.Sorted = true;
            this.ArcaneExplosion.TabIndex = 69;
            this.ArcaneExplosion.SelectedIndexChanged += new System.EventHandler(this.CommonDropDown_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 13);
            this.label1.TabIndex = 70;
            this.label1.Text = "Arcane Explosion (IB)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ArcaneShot
            // 
            this.ArcaneShot.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ArcaneShot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ArcaneShot.FormattingEnabled = true;
            this.ArcaneShot.Items.AddRange(new object[] {
            "... always",
            "... never",
            "... only on adds"});
            this.ArcaneShot.Location = new System.Drawing.Point(119, 46);
            this.ArcaneShot.Name = "ArcaneShot";
            this.ArcaneShot.Size = new System.Drawing.Size(180, 21);
            this.ArcaneShot.Sorted = true;
            this.ArcaneShot.TabIndex = 67;
            this.ArcaneShot.SelectedIndexChanged += new System.EventHandler(this.CommonDropDown_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 68;
            this.label2.Text = "Arcane Shot";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // KillCommand
            // 
            this.KillCommand.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.KillCommand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.KillCommand.FormattingEnabled = true;
            this.KillCommand.Items.AddRange(new object[] {
            "... always",
            "... never",
            "... only on adds"});
            this.KillCommand.Location = new System.Drawing.Point(119, 100);
            this.KillCommand.Name = "KillCommand";
            this.KillCommand.Size = new System.Drawing.Size(180, 21);
            this.KillCommand.Sorted = true;
            this.KillCommand.TabIndex = 67;
            this.KillCommand.SelectedIndexChanged += new System.EventHandler(this.CommonDropDown_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 68;
            this.label3.Text = "Kill Command";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BlackArrow
            // 
            this.BlackArrow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BlackArrow.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.BlackArrow.FormattingEnabled = true;
            this.BlackArrow.Items.AddRange(new object[] {
            "... always",
            "... never",
            "... only on adds"});
            this.BlackArrow.Location = new System.Drawing.Point(119, 154);
            this.BlackArrow.Name = "BlackArrow";
            this.BlackArrow.Size = new System.Drawing.Size(180, 21);
            this.BlackArrow.Sorted = true;
            this.BlackArrow.TabIndex = 67;
            this.BlackArrow.SelectedIndexChanged += new System.EventHandler(this.CommonDropDown_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(48, 157);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 13);
            this.label8.TabIndex = 68;
            this.label8.Text = "Black Arrow";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ExplosiveShot
            // 
            this.ExplosiveShot.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ExplosiveShot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ExplosiveShot.FormattingEnabled = true;
            this.ExplosiveShot.Items.AddRange(new object[] {
            "... always",
            "... never",
            "... only on adds"});
            this.ExplosiveShot.Location = new System.Drawing.Point(119, 127);
            this.ExplosiveShot.Name = "ExplosiveShot";
            this.ExplosiveShot.Size = new System.Drawing.Size(180, 21);
            this.ExplosiveShot.Sorted = true;
            this.ExplosiveShot.TabIndex = 67;
            this.ExplosiveShot.SelectedIndexChanged += new System.EventHandler(this.CommonDropDown_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 13);
            this.label5.TabIndex = 68;
            this.label5.Text = "Explosive Shot";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // SerpentSting
            // 
            this.SerpentSting.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SerpentSting.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SerpentSting.FormattingEnabled = true;
            this.SerpentSting.Items.AddRange(new object[] {
            "... always",
            "... never",
            "... only on adds"});
            this.SerpentSting.Location = new System.Drawing.Point(119, 73);
            this.SerpentSting.Name = "SerpentSting";
            this.SerpentSting.Size = new System.Drawing.Size(180, 21);
            this.SerpentSting.Sorted = true;
            this.SerpentSting.TabIndex = 67;
            this.SerpentSting.SelectedIndexChanged += new System.EventHandler(this.CommonDropDown_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 68;
            this.label6.Text = "Serpent Sting";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.FeignDeathHealth);
            this.groupBox4.Controls.Add(this.MendPetHealth);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.HealthPotion);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.RestHealth);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Location = new System.Drawing.Point(8, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(304, 137);
            this.groupBox4.TabIndex = 35;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Rest / Health";
            // 
            // FeignDeathHealth
            // 
            this.FeignDeathHealth.Cursor = System.Windows.Forms.Cursors.Default;
            this.FeignDeathHealth.Location = new System.Drawing.Point(118, 100);
            this.FeignDeathHealth.Name = "FeignDeathHealth";
            this.FeignDeathHealth.Size = new System.Drawing.Size(180, 21);
            this.FeignDeathHealth.TabIndex = 71;
            this.FeignDeathHealth.Value = 10;
            this.FeignDeathHealth.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CommonProgressBar_MouseAction);
            this.FeignDeathHealth.MouseMove += new System.Windows.Forms.MouseEventHandler(this.CommonProgressBar_MouseAction);
            // 
            // MendPetHealth
            // 
            this.MendPetHealth.Cursor = System.Windows.Forms.Cursors.Default;
            this.MendPetHealth.Location = new System.Drawing.Point(118, 73);
            this.MendPetHealth.Name = "MendPetHealth";
            this.MendPetHealth.Size = new System.Drawing.Size(180, 21);
            this.MendPetHealth.TabIndex = 71;
            this.MendPetHealth.Value = 10;
            this.MendPetHealth.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CommonProgressBar_MouseAction);
            this.MendPetHealth.MouseMove += new System.Windows.Forms.MouseEventHandler(this.CommonProgressBar_MouseAction);
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 105);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 13);
            this.label13.TabIndex = 68;
            this.label13.Text = "Feign Death Health";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // HealthPotion
            // 
            this.HealthPotion.Cursor = System.Windows.Forms.Cursors.Default;
            this.HealthPotion.Location = new System.Drawing.Point(118, 46);
            this.HealthPotion.Name = "HealthPotion";
            this.HealthPotion.Size = new System.Drawing.Size(180, 21);
            this.HealthPotion.TabIndex = 71;
            this.toolTip1.SetToolTip(this.HealthPotion, "Use a mana potion when your mana is below (%)");
            this.HealthPotion.Value = 10;
            this.HealthPotion.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CommonProgressBar_MouseAction);
            this.HealthPotion.MouseMove += new System.Windows.Forms.MouseEventHandler(this.CommonProgressBar_MouseAction);
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(25, 78);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 13);
            this.label12.TabIndex = 68;
            this.label12.Text = "Mend Pet Health";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // RestHealth
            // 
            this.RestHealth.Cursor = System.Windows.Forms.Cursors.Default;
            this.RestHealth.Location = new System.Drawing.Point(118, 19);
            this.RestHealth.Name = "RestHealth";
            this.RestHealth.Size = new System.Drawing.Size(180, 21);
            this.RestHealth.TabIndex = 71;
            this.toolTip1.SetToolTip(this.RestHealth, "Drink when your mana is below (%)");
            this.RestHealth.Value = 25;
            this.RestHealth.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CommonProgressBar_MouseAction);
            this.RestHealth.MouseMove += new System.Windows.Forms.MouseEventHandler(this.CommonProgressBar_MouseAction);
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(41, 51);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 13);
            this.label19.TabIndex = 68;
            this.label19.Text = "Health Potion";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(50, 23);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(63, 13);
            this.label18.TabIndex = 68;
            this.label18.Text = "Rest Health";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(631, 500);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Advanced";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.RAFTarget);
            this.groupBox7.Controls.Add(this.label24);
            this.groupBox7.Location = new System.Drawing.Point(8, 90);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(305, 84);
            this.groupBox7.TabIndex = 35;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "RAF Party";
            // 
            // RAFTarget
            // 
            this.RAFTarget.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RAFTarget.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.RAFTarget.FormattingEnabled = true;
            this.RAFTarget.Items.AddRange(new object[] {
            "... always",
            "... never"});
            this.RAFTarget.Location = new System.Drawing.Point(119, 19);
            this.RAFTarget.Name = "RAFTarget";
            this.RAFTarget.Size = new System.Drawing.Size(180, 21);
            this.RAFTarget.Sorted = true;
            this.RAFTarget.TabIndex = 67;
            this.RAFTarget.SelectedIndexChanged += new System.EventHandler(this.CommonDropDown_SelectedIndexChanged);
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(20, 22);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(93, 13);
            this.label24.TabIndex = 68;
            this.label24.Text = "Use leaders target";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.Controls.Add(this.Debug);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Location = new System.Drawing.Point(8, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(305, 78);
            this.groupBox5.TabIndex = 35;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Debugging";
            // 
            // Debug
            // 
            this.Debug.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Debug.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Debug.FormattingEnabled = true;
            this.Debug.Items.AddRange(new object[] {
            "... do not show debug",
            "... show debug level 1",
            "... show debug level 2",
            "... show debug level 3"});
            this.Debug.Location = new System.Drawing.Point(119, 19);
            this.Debug.Name = "Debug";
            this.Debug.Size = new System.Drawing.Size(180, 21);
            this.Debug.Sorted = true;
            this.Debug.TabIndex = 67;
            this.Debug.SelectedIndexChanged += new System.EventHandler(this.CommonDropDown_SelectedIndexChanged);
            // 
            // label27
            // 
            this.label27.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(68, 22);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(45, 13);
            this.label27.TabIndex = 68;
            this.label27.Text = "Logging";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 400;
            this.toolTip1.AutoPopDelay = 6000;
            this.toolTip1.InitialDelay = 400;
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ReshowDelay = 80;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip1.ToolTipTitle = "Karis Settings";
            // 
            // UIForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 573);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.BottomPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "UIForm";
            this.Text = "My CC UI";
            this.Load += new System.EventHandler(this.UIForm_Load);
            this.BottomPanel.ResumeLayout(false);
            this.BottomPanel.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel BottomPanel;
        private System.Windows.Forms.Button SaveSettings;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lblCCName;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ProgressBar HealthPotion;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ProgressBar RestHealth;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox Debug;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.ComboBox RAFTarget;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox ArcaneExplosion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox ArcaneShot;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox KillCommand;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox SerpentSting;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ProgressBar MendPetHealth;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ProgressBar FeignDeathHealth;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox BlackArrow;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox ExplosiveShot;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TabControl tabControl1;
        public System.Windows.Forms.GroupBox groupBox4;
        public System.Windows.Forms.GroupBox groupBox1;
    }
}