﻿using Hera.Helpers;
using Hera.SpellsMan;
using TreeSharp;
using System.Threading;

namespace Hera
{
    public partial class Fpsware
    {
        // ******************************************************************************************
        // This is where the pull action takes place

        #region Pull
        // _pullBehavior is a class that will hold our logic. 
        private Composite _pullBehavior;
        public override Composite PullBehavior
        {
            get { if (_pullBehavior == null) { Utils.Log("Creating 'Pull' behavior"); _pullBehavior = CreatePullBehavior(); }  return _pullBehavior; }
        }

        private PrioritySelector CreatePullBehavior()
        {
            return new PrioritySelector(

                // All spells are checked in the order listed below, a prioritised order
                // Put the most important spells at the top of the list

                // If we can't reach the target blacklist it.
                new Decorator(ret => !Target.CanGenerateNavPath, new Action(ret => Target.BlackList(1000))),

                // Check if the target is suitable for pulling, if not blacklist it
                new NeedToBlacklistPullTarget(new BlacklistPullTarget()),

                // Check pull timers and blacklist bad pulls where required
                new NeedToCheckPullTimer(new BlacklistPullTarget()),

                new Decorator(ret=> Movement.NeedToCheck,new Action(ret => Movement.DistanceCheck(ClassHelper.MaximumDistance,ClassHelper.MinimumDistance))),


                // *******************************************************

                // Face Target Pull
                new NeedToFaceTargetPull(new FaceTargetPull()),

                // Frostbolt
                new NeedToFrostbolt(new Frostbolt()),

                // Arcane Missiles
                new NeedToArcaneMissiles(new ArcaneMissiles()),

                // Fireball
                new NeedToFireball(new Fireball()),




                // Finally just move to the target.
                new Action(ret => Movement.DistanceCheck(ClassHelper.MaximumDistance,ClassHelper.MinimumDistance))
                );
        }
        #endregion

        #region Pull Timer / Timeout
        public class NeedToCheckPullTimer : Decorator
        {
            public NeedToCheckPullTimer(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                return Target.PullTimerExpired;
            }
        }

        public class CheckPullTimer : Action
        {
            protected override RunStatus Run(object context)
            {
                Utils.Log(string.Format("Unable to pull {0}, blacklisting and finding another target.", Me.CurrentTarget.Name), System.Drawing.Color.FromName("Red"));
                Target.BlackList(1200);
                Me.ClearTarget();

                return RunStatus.Success;
            }
        }
        #endregion

        #region Combat Timer / Timeout
        public class NeedToCheckCombatTimer : Decorator
        {
            public NeedToCheckCombatTimer(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                Debug.Log("NeedToCheckCombatTimer", 1);
                if (!Me.GotTarget || Me.CurrentTarget.Dead) return false;
                if (Target.IsElite) return false;                           // Elites are going to take more of a beating so ignore this check
                if (CT.Name.Contains("Training")) return false;             // Don't time out on training dummies
                

                return Target.CombatTimerExpired && Target.IsHealthAbove(95);
            }
        }

        public class CheckCombatTimer : Action
        {
            protected override RunStatus Run(object context)
            {
                Utils.Log(string.Format("Combat with {0} is bugged, blacklisting and finding another target.", Me.CurrentTarget.Name), System.Drawing.Color.FromName("Red"));
                Target.BlackList(1200);
                Utils.LagSleep();

                return RunStatus.Success;
            }
        }
        #endregion


        // ******************************************************************************************
        // Pull spells are here

        #region Face Target Pull

        public class NeedToFaceTargetPull : Decorator
        {
            public NeedToFaceTargetPull(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                if (!Utils.IsCommonChecksOk("", false)) return false;
                if (Me.IsMoving) return false;
                if (Me.IsSafelyFacing(Me.CurrentTarget.Location)) return false;

                return true;
            }
        }

        public class FaceTargetPull : Action
        {
            protected override RunStatus Run(object context)
            {
                Target.Face();
                Thread.Sleep(750);
                return RunStatus.Failure;
            }
        }

        #endregion


    }
}