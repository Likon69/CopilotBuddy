﻿using System.Diagnostics;
using Hera.Config;
using Hera.Helpers;
using Hera.SpellsMan;
using Styx;
using Styx.Logic;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.World;
using System.Threading;
using TreeSharp;
using Debug = Hera.Helpers.Debug;

namespace Hera
{
    public partial class Fpsware
    {

        // ******************************************************************************************
        //
        // All our BTs and logic will be in here - LET THE GAMES BEGIN!
        //
        // Everything we tell HB to do will be in here:
        //   * Rest
        //   * Heal
        //   * Buffs
        //   * Pull
        //   * Combat
        //
        // ******************************************************************************************



        // Combat. 
        // Today is a good day to die!
        #region Combat!
        // _combatBehavior is a class that will hold our logic. 
        private Composite _combatBehavior;
        public override Composite CombatBehavior
        {
            get
            {
                if (_combatBehavior == null) { Utils.Log("Creating 'Combat' behavior"); _combatBehavior = CreateCombatBehavior(); }  
                
                return _combatBehavior;
            }
        }

        // Our entire combat sequence takes place in here
        //
        private PrioritySelector CreateCombatBehavior()
        {
            return new PrioritySelector(

                // All spells are checked in the order listed below, a prioritised order
                // Put the most important spells at the top of the list

                // Make sure we always have a target. If we don't have a target, take the pet's target - if they have one.
                new Decorator(ret => !Me.GotTarget && Me.GotAlivePet && Me.Pet.GotTarget, new Action(ret => Me.Pet.CurrentTarget.Target())),

                // Check if we get aggro during the pull
                // This is in here and not the pull because we are in combat at this point
                new NeedToCheckAggroOnPull(new CheckAggroOnPull()),

                // Abort combat is the target's health is 95% + after 30 seconds of combat
                new NeedToCheckCombatTimer(new CheckCombatTimer()),

                // Kind of important that we face the target
                new NeedToFaceTarget(new FaceTarget()),

                // LOS Check
                new NeedToLOSCheck(new LOSCheck()),

                // Distance check. Make sure we are in attacking range at all times
                new NeedToCheckDistance(new CheckDistance()),

                // Face Target
                new NeedToFaceTarget(new FaceTarget()),

                // Backup - if closer than 5 yards
                //new NeedToBackup(new Backup()),

                // Mage Ward
                new NeedToMageWard(new MageWard()),

                // Mirror Image
                new NeedToMirrorImage(new MirrorImage()),


                // Brain Freeze
                new NeedToBrainFreeze(new BrainFreeze()),

                // Hot Streak
                new NeedToHotStreak(new HotStreak()),

                // ************************************************************************************
                // Important/time sensative spells here
                // These are spells that need to be case asap

                // Blast Wave In Instance
                new NeedToBlastwaveInInstance(new BlastwaveInInstance()),

                // Blizzard In Instance
                new NeedToBlizzardInInstance(new BlizzardInInstance()),

                // Pet Attack
                new NeedToPetAttack(new PetAttack()),

                // Frost Nova + Runaway logic
                new NeedToFrostNova(new FrostNova()),

                // Pyroblast (ony on Frost Nova)
                new NeedToPyroblastOnNova(new PyroblastOnNova()),
                
                // Ice Lance
                new NeedToIceLance(new IceLance()),

                // Cone Of Cold
                new NeedToConeofCold(new ConeofCold()),

                // Dragon's Breath
                new NeedToDragonsBreath(new DragonsBreath()),

                // Arcane Missiles
                new NeedToArcaneMissiles(new ArcaneMissiles()),

                // Fire Blast
                new NeedToFireBlast(new FireBlast()),

                // Counterspell
                new NeedToCounterspell(new Counterspell()),

                // Move Away - Frost Nova
                //new NeedToMoveAwayFrostNova(new MoveAwayFrostNova()),

                // ************************************************************************************
                // Other spells here

                // Scorch
                new NeedToScorch(new Scorch()),


                // Primary DPS Spell
                new NeedToPrimaryDPSSpell(new PrimaryDPSSpell())

                                
                // Backup - if closer than 5 yards
                //new NeedToBackup(new Backup())

                );
        }
        #endregion


        // ******************************************************************************************
        //
        // This is where the priority selectors start
        //

        #region Auto Attack
        public class NeedToAutoAttack : Decorator
        {
            public NeedToAutoAttack(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                Debug.Log("NeedToAutoAttack", 1);
                return (Me.GotTarget && CT.IsAlive && !Me.IsAutoAttacking);
            }
        }

        public class AutoAttack : Action
        {
            protected override RunStatus Run(object context)
            {
                Utils.AutoAttack(true);
                return RunStatus.Failure;

            }
        }
        #endregion

        #region Backup
        public class NeedToBackup : Decorator
        {
            public NeedToBackup(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                if (Target.IsDistanceMoreThan(5.5)) return false;
                if (!Utils.IsCommonChecksOk("", false)) return false;
                if (!Me.GotTarget) return false;
                if (CT.CurrentTargetGuid == Me.Guid) return false;

                if (CT.CurrentTargetGuid == Me.Pet.Guid) return true;
                if (CT.CurrentTargetGuid != Me.Guid && Me.IsInInstance) return true;

                return false;
            }
        }

        public class Backup : Action
        {
            protected override RunStatus Run(object context)
            {
                Stopwatch t = new Stopwatch();

                t.Start();
                WoWMovement.Move(WoWMovement.MovementDirection.Backwards);
                WoWMovement.Face();

                while (t.ElapsedMilliseconds <1500)
                {
                    System.Threading.Thread.Sleep(100);
                    if (Me.GotTarget && Target.Distance > 6)
                    {
                        break;
                    }
                }

                
                WoWMovement.MoveStop(WoWMovement.MovementDirection.Backwards);
                return RunStatus.Success;
            }
        }
        #endregion

        #region LOS Check
        public class NeedToLOSCheck : Decorator
        {
            public NeedToLOSCheck(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                if (!Me.GotTarget || CT.Dead) return false;
                bool result = !GameWorld.IsInLineOfSight(Me.Location, Me.CurrentTarget.Location);

                return result;
            }
        }

        public class LOSCheck : Action
        {
            protected override RunStatus Run(object context)
            {
                if (Me.IsInInstance)
                {
                    //Utils.Log(string.Format("We don't have LOS on {0} moving closer...", CT.Name),System.Drawing.Color.FromName("DarkRed"));
                    Movement.MoveTo(1);
                    Thread.Sleep(250);
                    while (!GameWorld.IsInLineOfSight(Me.Location, Me.CurrentTarget.Location))
                    {
                        Movement.MoveTo(1);
                        Thread.Sleep(250);
                    }
                }
                else
                {
                    float distance = (float)CT.Distance2D * 0.5f;

                    Utils.Log(string.Format("We don't have LOS on {0} moving closer...", CT.Name),System.Drawing.Color.FromName("DarkRed"));
                    Movement.MoveTo(distance);

                    Thread.Sleep(250);
                    while (Me.IsMoving)
                    {
                        Thread.Sleep(250);
                    }
                }

                return RunStatus.Success;
            }
        }
        #endregion



        #region Primary DPS Spell
        public class NeedToPrimaryDPSSpell : Decorator
        {
            public NeedToPrimaryDPSSpell(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string DPSSpell = "";

                if (!Utils.IsCommonChecksOk(DPSSpell, false)) return false;
                if (ClassHelper.ClassSpec == ClassType.Fire && Spell.CanCast("Fireball")) DPSSpell = "Fireball";
                if (ClassHelper.ClassSpec == ClassType.Frost && Spell.CanCast("Frostbolt")) DPSSpell = "Frostbolt";
                if (ClassHelper.ClassSpec == ClassType.Arcane && Spell.CanCast("Arcane Barrage")) DPSSpell = "Arcane Barrage";
                
                if (DPSSpell == "")
                {
                    if (ClassHelper.ClassSpec == ClassType.Fire && Spell.CanCast("Frostbolt")) DPSSpell = "Frostbolt";
                    else if (ClassHelper.ClassSpec == ClassType.Frost && Spell.CanCast("Fireball")) DPSSpell = "Fireball";
                    else if (ClassHelper.ClassSpec == ClassType.Arcane && Spell.CanCast("Fireball")) DPSSpell = "Fireball";
                }

                if (ClassHelper.ClassSpec == ClassType.None) DPSSpell = "Fireball";
                ClassHelper.PrimaryDPSSpell = DPSSpell;

                return (Spell.CanCast(DPSSpell));
            }
        }

        public class PrimaryDPSSpell : Action
        {
            protected override RunStatus Run(object context)
            {
                //if (RaFHelper.Leader !=null && !Utils.IsInLineOfSight(RaFHelper.Leader.Location)) Utils.MoveToLineOfSight(RaFHelper.Leader.Location);
                Target.Face();
                bool result = Spell.Cast(ClassHelper.PrimaryDPSSpell);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion


        #region Scorch
        public class NeedToScorch : Decorator
        {
            public NeedToScorch(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Scorch";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                //if (!Me.IsInInstance) return false;
                if (Target.IsDistanceMoreThan(Spell.MaxDistance(spellName))) return false;
                if (Target.IsHealthAbove(30)) return false;
                if (ClassHelper.ClassSpec != ClassType.Fire) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class Scorch : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Scorch";

                //if (RaFHelper.Leader != null && !Utils.IsInLineOfSight(RaFHelper.Leader.Location)) Utils.MoveToLineOfSight(RaFHelper.Leader.Location);
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Fireball
        public class NeedToFireball : Decorator
        {
            public NeedToFireball(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Fireball";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Spell.IsEnoughMana(spellName)) return false;
                if (Target.IsDistanceMoreThan(Spell.MaxDistance(spellName))) return false;
                if (ClassHelper.ClassSpec == ClassType.Frost && !Spell.IsOnCooldown("Frostbolt")) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class Fireball : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Fireball";
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Fire Blast
        public class NeedToFireBlast : Decorator
        {
            public NeedToFireBlast(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Fire Blast";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Spell.IsEnoughMana(spellName)) return false;
                if (Target.IsDistanceMoreThan(Spell.MaxDistance(spellName))) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class FireBlast : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Fire Blast";
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Arcane Missiles
        public class NeedToArcaneMissiles : Decorator
        {
            public NeedToArcaneMissiles(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Arcane Missiles";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Spell.IsEnoughMana(spellName)) return false;
                if (Target.IsDistanceMoreThan(Spell.MaxDistance(spellName))) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class ArcaneMissiles : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Arcane Missiles";

                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Arcane Barrage
        public class NeedToArcaneBarrage : Decorator
        {
            public NeedToArcaneBarrage(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Arcane Barrage";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Spell.IsEnoughMana(spellName)) return false;
                if (Target.IsDistanceMoreThan(Spell.MaxDistance(spellName))) return false;
                if (ClassHelper.ClassSpec != ClassType.Arcane) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class ArcaneBarrage : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Arcane Barrage";
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Counterspell
        public class NeedToCounterspell : Decorator
        {
            public NeedToCounterspell(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Counterspell";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Spell.IsEnoughMana(spellName)) return false;
                if (Target.IsDistanceMoreThan(Spell.MaxDistance(spellName))) return false;
                if (!Target.IsCasting) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class Counterspell : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Counterspell";
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Mage Ward
        public class NeedToMageWard : Decorator
        {
            public NeedToMageWard(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Mage Ward";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Target.IsCasting) return false;
                if (!Target.IsTargetingMe) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class MageWard : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Mage Ward";
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Mirror Image
        public class NeedToMirrorImage : Decorator
        {
            public NeedToMirrorImage(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Mirror Image";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Spell.IsEnoughMana(spellName)) return false;
                if (!Utils.Adds && !Me.IsInInstance) return false;
                if (!RAF.AddsInstance && Me.IsInInstance) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class MirrorImage : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Mirror Image";
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Flamestrike
        public class NeedToFlamestrike : Decorator
        {
            public NeedToFlamestrike(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Flamestrike";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Spell.IsEnoughMana(spellName)) return false;
                if (Target.IsDistanceMoreThan(Spell.MaxDistance(spellName))) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class Flamestrike : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Flamestrike";

                bool result = Spell.Cast(spellName, CT.Location);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Cone of Cold
        public class NeedToConeofCold : Decorator
        {
            public NeedToConeofCold(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Cone of Cold";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (Target.IsDistanceMoreThan(11)) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class ConeofCold : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Cone of Cold";
                Target.Face();
                Thread.Sleep(400);
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Dragon's Breath
        public class NeedToDragonsBreath: Decorator
        {
            public NeedToDragonsBreath(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Dragon's Breath";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (Target.IsDistanceMoreThan(11)) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class DragonsBreath : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Dragon's Breath";
                Target.Face();
                Thread.Sleep(400);
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Ice Barrier
        public class NeedToIceBarrier : Decorator
        {
            public NeedToIceBarrier(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Ice Barrier";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Spell.IsEnoughMana(spellName)) return false;
                if (!Utils.Adds || Self.IsHealthAbove(50)) return false;
                if (Self.IsBuffOnMe(spellName)) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class IceBarrier : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Ice Barrier";

                Spell.Cast(spellName, Me);
                Utils.LagSleep();

                bool result = Self.IsBuffOnMe(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Blizzard
        public class NeedToBlizzard : Decorator
        {
            public NeedToBlizzard(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Blizzard";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Spell.IsEnoughMana(spellName)) return false;
                if (Target.IsDistanceMoreThan(Spell.MaxDistance(spellName))) return false;
                if (!Utils.Adds) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class Blizzard : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Blizzard";

                bool result = Spell.Cast(spellName, CT.Location);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Blink
        public class NeedToBlink : Decorator
        {
            public NeedToBlink(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Blink";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Spell.IsEnoughMana(spellName)) return false;
                if (Target.IsDistanceMoreThan(6)) return false;
                if (Target.IsCaster) return false;

                return (Spell.CanCast(spellName));

            }
        }

        public class Blink : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Blink";

                bool result = Spell.Cast(spellName);
                if (result)
                {
                    Utils.LagSleep();
                    Target.Face();
                    System.Threading.Thread.Sleep(800);
                }

                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Evocation
        public class NeedToEvocation : Decorator
        {
            public NeedToEvocation(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Evocation";

                if (!Utils.IsCommonChecksOk(spellName, true)) return false;
                if (Self.IsManaAbove(40)) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class Evocation : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Evocation";

                bool result = Spell.Cast(spellName);
                Utils.LagSleep();
                Utils.WaitWhileCasting();
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Frostbolt
        public class NeedToFrostbolt : Decorator
        {
            public NeedToFrostbolt(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Frostbolt";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Spell.IsEnoughMana(spellName)) return false;
                if (Target.IsDistanceMoreThan(Spell.MaxDistance(spellName))) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class Frostbolt : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Frostbolt";

                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Frost Nova
        public class NeedToFrostNova : Decorator
        {
            public NeedToFrostNova(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string dpsSpell = "Frost Nova";

                if (Me.IsInInstance) return false;
                if (!Utils.IsCommonChecksOk(dpsSpell, false)) return false;
                if (!Target.IsDistanceLessThan(10)) return false;
                //if (Target.IsDebuffOnTarget("Frostbite")) return false;
                if (!Utils.Adds && !Target.IsHealthAbove(45) && Self.IsHealthAbove(65)) return false;
                if (Target.IsLowLevel) return false;
                
                //if (Utils.Adds) return false;

                return (Spell.CanCast(dpsSpell));
            }
        }

        public class FrostNova : Action
        {
            protected override RunStatus Run(object context)
            {
                double distanceFrom = 15;
                WoWPoint pointToGo = Movement.FindSafeLocation(distanceFrom);
                
                WoWMovement.ClickToMove(pointToGo);
                if (Spell.CanCast("Frost Nova")) Spell.Cast("Frost Nova");

                Thread.Sleep(1500);
                if (!Spell.CanCast("Blink"))
                {
                    while (Me.IsMoving)
                    {
                        WoWMovement.ClickToMove(pointToGo);
                        Thread.Sleep(250);
                        if (!Target.IsDebuffOnTarget("Frost Nova")) break;
                    }
                }
                else
                {
                    Thread.Sleep(250);
                    if (!Target.IsDebuffOnTarget("Frost Nova"))
                    {
                        Spell.Cast("Blink");
                        Thread.Sleep(500);
                    }
                }

                WoWMovement.MoveStop();
                WoWMovement.Face(CT.Guid);
                Thread.Sleep(500);

                ObjectManager.Update();
                bool result = Target.IsDebuffOnTarget("Frost Nova");
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Ice Lance
        public class NeedToIceLance : Decorator
        {
            public NeedToIceLance(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Ice Lance";
                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (Target.IsDistanceMoreThan(Spell.MaxDistance(spellName))) return false;
                if (Target.IsDebuffOnTarget("Frostbite")) return true;
                if (Target.IsDebuffOnTarget("Frost Nova")) return true;
                //if (Me.Auras.ContainsKey("Fingers of Frost") && Me.Auras["Fingers of Frost"].StackCount > 0) return true;
                if (Me.Auras.ContainsKey("Fingers of Frost") && Me.Auras["Fingers of Frost"].TimeLeft.TotalSeconds > 0) return true;
                return false;
            }
        }

        public class IceLance : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Ice Lance";

                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Blizzard - Instance / RAF
        public class NeedToBlizzardInInstance : Decorator
        {
            public NeedToBlizzardInInstance(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string dpsSpell = "Blizzard";
                if (!Me.IsInInstance) return false;
                if (!Utils.IsCommonChecksOk(dpsSpell, false)) return false;
                if (!Spell.IsEnoughMana(dpsSpell)) return false;
                if (!RAF.CanAoEInstance) return false;
                if (RaFHelper.Leader != null && RaFHelper.Leader.IsMoving) return false;

                return (Spell.CanCast(dpsSpell));
            }
        }

        public class BlizzardInInstance : Action
        {
            protected override RunStatus Run(object context)
            {
                string dpsSpell = "Blizzard";
                double maxDistance = Spell.MaxDistance(dpsSpell) - 1;

                while (RaFHelper.Leader.Distance2D > maxDistance)
                {
                    // if we're out of Blizzard range then move closer
                    Movement.MoveTo(RaFHelper.Leader.Location);
                    Utils.Log("Out of range for Blizzard, moving closer");

                }

                if (!Utils.IsInLineOfSight(RaFHelper.Leader.Location)) Utils.MoveToLineOfSight(RaFHelper.Leader.Location);
                if (Me.IsMoving) Movement.StopMoving();

                // Once we finally get here, if the tank is moving then just bail out
                if (RaFHelper.Leader.IsMoving) return RunStatus.Failure;

                // Cast AoE at this location
                WoWPoint AoELocation = RaFHelper.Leader.Location;

                bool result = Spell.Cast(dpsSpell, AoELocation);
                Thread.Sleep(500);
                while (Me.IsCasting)
                {
                    // If the tank is not within 6 yards of our original casting location then bail out (assuming mobs won't be there either)
                    // If we're out of combat bail out (assuming mobs are all dead)
                    if (RaFHelper.Leader.Location.Distance(AoELocation) > 6 || !Me.Combat)
                    {
                        Utils.Log("** Stop casting Blizzard **");
                        WoWMovement.Move(WoWMovement.MovementDirection.JumpAscend);
                        WoWMovement.MoveStop(WoWMovement.MovementDirection.JumpAscend);
                        break;
                    }

                    Thread.Sleep(250);

                }
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Blastwave - Instance / RAF
        public class NeedToBlastwaveInInstance : Decorator
        {
            public NeedToBlastwaveInInstance(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string dpsSpell = "Blast Wave";
                if (!Me.IsInInstance) return false;
                if (!Utils.IsCommonChecksOk(dpsSpell, false)) return false;
                if (!RAF.CanAoEInstance) return false;
                if (RaFHelper.Leader != null && RaFHelper.Leader.IsMoving) return false;

                return (Spell.CanCast(dpsSpell));
            }
        }

        public class BlastwaveInInstance : Action
        {
            protected override RunStatus Run(object context)
            {
                string dpsSpell = "Blast Wave";
                double maxDistance = Spell.MaxDistance(dpsSpell) - 1;

                while (RaFHelper.Leader.Distance2D > maxDistance)
                {
                    // if we're out of Blast Wave range then move closer
                    Movement.MoveTo(RaFHelper.Leader.Location);
                    Utils.Log("Out of range for Blast Wave, moving closer");
                }

                if (!Utils.IsInLineOfSight(RaFHelper.Leader.Location)) Utils.MoveToLineOfSight(RaFHelper.Leader.Location);
                if (Me.IsMoving) Movement.StopMoving();

                // Once we finally get here, if the tank is moving then just bail out
                if (RaFHelper.Leader.IsMoving) return RunStatus.Failure;

                // Cast AoE at this location
                WoWPoint AoELocation = RaFHelper.Leader.Location;
                bool result = Spell.Cast(dpsSpell, AoELocation);
                Thread.Sleep(500);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Molten Armor
        public class NeedToMoltenArmor : Decorator
        {
            public NeedToMoltenArmor(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Molten Armor";

                if (!Utils.IsCommonChecksOk(spellName, true)) return false;
                if (Self.IsBuffOnMe("Molten Armor")) return false;
                if (Me.Mounted) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class MoltenArmor : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Molten Armor";

                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Arcane Brilliance
        public class NeedToArcaneBrilliance: Decorator
        {
            public NeedToArcaneBrilliance(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Arcane Brilliance";

                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (Self.IsBuffOnMe("Arcane Brilliance")) return false;
                if (Me.Mounted) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class ArcaneBrilliance : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Arcane Brilliance";

                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region PetAttack
        public class NeedToPetAttack : Decorator
        {
            public NeedToPetAttack(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                if (!Utils.IsCommonChecksOk("", false)) return false;
                if (!Me.GotAlivePet) return false;
                if (!Me.GotTarget) return false;
                
                if (Me.GotTarget && !Me.Pet.GotTarget) return true;
                if (Me.Pet.CurrentTargetGuid != Me.CurrentTargetGuid) return true;


                return false;
            }
        }

        public class PetAttack : Action
        {
            protected override RunStatus Run(object context)
            {
                bool result = false;
                ClassHelper.WaterElemental.Attack();
                Thread.Sleep(250);

                result = Me.Pet.CurrentTargetGuid == Me.CurrentTargetGuid;

                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Brain Freeze Proc
        public class NeedToBrainFreeze : Decorator
        {
            public NeedToBrainFreeze(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Fireball";
                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Me.Auras.ContainsKey("Brain Freeze")) return false;
                if (Me.Auras["Brain Freeze"].TimeLeft.TotalSeconds > 0) return true;

                return false;
            }
        }

        public class BrainFreeze : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = Spell.IsKnown("Frostfire Bolt") ? "Frostfire Bolt" : "Fireball";
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Hot Streak Proc
        public class NeedToHotStreak: Decorator
        {
            public NeedToHotStreak(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Pyroblast";
                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (!Me.Auras.ContainsKey("Hot Streak")) return false;
                if (Me.Auras["Hot Streak"].TimeLeft.TotalSeconds > 0) return true;

                return false;
            }
        }

        public class HotStreak : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Pyroblast";
                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Living Bomb
        public class NeedToLivingBomb : Decorator
        {
            public NeedToLivingBomb(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Living Bomb";
                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (Target.IsDebuffOnTarget(spellName)) return false;
                if (Target.IsLowLevel) return false;

                return (Spell.CanCast(spellName));
            }
        }

        public class LivingBomb : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Living Bomb";
                Spell.Cast(spellName);
                Utils.LagSleep();
                
                bool result = Target.IsDebuffOnTarget(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        #region Pyroblast - Frost Nova
        public class NeedToPyroblastOnNova : Decorator
        {
            public NeedToPyroblastOnNova(Composite child) : base(child) { }

            protected override bool CanRun(object context)
            {
                string spellName = "Pyroblast";
                if (!Utils.IsCommonChecksOk(spellName, false)) return false;
                if (Me.IsInInstance) return false;
                if (Utils.Adds) return false;
                if (Target.IsDistanceMoreThan(Spell.MaxDistance(spellName))) return false;
                if (Target.IsDebuffOnTarget("Frost Nova")) return true;

                return false;
            }
        }

        public class PyroblastOnNova : Action
        {
            protected override RunStatus Run(object context)
            {
                string spellName = "Pyroblast";

                bool result = Spell.Cast(spellName);
                return result ? RunStatus.Success : RunStatus.Failure;
            }
        }
        #endregion

        


    }
}