﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Hera.Config;
using Hera.SpellsMan;
using Styx;
using Styx.Combat.CombatRoutine;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.POI;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

namespace Hera.Helpers
{
    public enum ClassType
    {
        None = 0,
        Arcane,
        Fire,
        Frost
    }

    public static class ClassHelper
    {
        private static LocalPlayer Me { get { return ObjectManager.Me; } }
        public static ClassType ClassSpec { get; set; }

        public static string PrimaryDPSSpell { get; set; }

        // Maximum pull distance for this class
        private static double _maximumDistance = 40;
        /// <summary>
        /// Maximum distance for casting spells or melee. If you are a caster set this to the maximum distance of your spell
        /// If you are melee set this to 5.5
        /// </summary>
        public static double MaximumDistance
        {
            get { return _maximumDistance; }
            set { _maximumDistance = value; }
        }

        // Move to distance for this class
        // If the target is more than MaxDistance away, the character will move to this (minimumDistance) distance
        // Useful for pulling thats at max range that are moving away from you, or fleeing targets
        private static double _minimumDistance = 35;
        /// <summary>
        /// If your distance from the target is greater than MaxDistance, it will move to this distance
        /// Set this to a few yards less than MaxDistance
        /// </summary>
        public static double MinimumDistance
        {
            get { return _minimumDistance; }
            set { _minimumDistance = value; }
        }

        public static bool AllMobsAttackingPetOrOther
        {
            get
            {
                //if (Targeting.Instance.TargetList.Count == 1)
                //if (!Utils.Adds && Me.GotTarget && Me.CurrentTargetGuid != Me.Guid) return true;
                
                if (Targeting.Instance.TargetList.Any(u => u.CurrentTargetGuid == Me.Guid))
                {
                    return false;
                }

                return true;
            }
        }

        public static WoWUnit MobAttackingMe
        {
            get
            {
                List<WoWUnit> hlist =
                    (from o in ObjectManager.ObjectList
                     where o is WoWUnit
                     let p = o.ToUnit()
                     where p.Distance2D < 40
                           && !p.Dead
                           //&& p.CurrentTargetGuid == Me.Guid
                           //&& Me.Pet.CurrentTargetGuid != p.Guid
                           && p != Me
                           && p.Attackable
                     orderby p.Distance2D ascending
                     select p).ToList();


                foreach (WoWUnit u in hlist)
                {
                    if (Me.Pet.CurrentTargetGuid == u.Guid) return null;
                }

                return hlist.FirstOrDefault();
            }
        }


        public static WoWUnit NeedToDecursePlayer
        {
            get
            {
                if (Me.IsInParty)
                {
                    foreach (WoWPlayer p in Me.PartyMembers)
                    {
                        foreach (KeyValuePair<string, WoWAura> aura in Me.Auras)
                        {
                            if (!aura.Value.IsHarmful) continue;
                            if (aura.Value.Spell.DispelType == WoWDispelType.Curse) return p;
                        }
                    }
                }
                else
                {
                    foreach (KeyValuePair<string, WoWAura> aura in Me.Auras)
                    {
                        if (!aura.Value.IsHarmful) continue;
                        if (aura.Value.Spell.DispelType == WoWDispelType.Curse) return Me;
                    }
                }

                return null;
            }
        }

        public static class WaterElemental
        {
            public static bool NeedToCall
            {
                get
                {
                    if (Me.Mounted) return false;
                    if (ClassSpec != ClassType.Frost) return false;
                    if (Me.GotAlivePet) return false;

                    return Spell.CanCast("Summon Water Elemental");
                }
            }

            public static void Call()
            {
                Spell.Cast("Summon Water Elemental");
                Thread.Sleep(1000);
            }

            public static void Attack()
            {
                Utils.Log("-Elemental Attacking " + Me.CurrentTarget.Name, Utils.Colour("Blue"));
                Lua.DoString("PetAttack()");
            }

        }



    }
}