﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Zerfall
{
    public partial class ZerfallConfig : Form
    {
        public ZerfallConfig()
        {
            InitializeComponent();
        }

        private void ZerfallConfig_Load(object sender, EventArgs e)
        {
            WarlockSettings.Instance.Load();
            propertyGrid1.SelectedObject = WarlockSettings.Instance;
        }

        private void FormConfig_FormClosing(object sender, FormClosingEventArgs e)
        {
            var dr = MessageBox.Show(
                "Save before closing?",
                "Warning",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Information);

            if (dr == DialogResult.Yes)
                WarlockSettings.Instance.Save();
        }

    }
}
