﻿using System.Collections.Generic;
using System.Threading;
using CommonBehaviors.Actions;
using Styx;
using Zerfall.Talents;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Logic.Pathing;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;
using Sequence = TreeSharp.Sequence;
using System.Linq;

namespace Zerfall
{
    public partial class Zerfall
    {
        private Composite _combatBehavior;
        public override Composite CombatBehavior
        {
            get
            {
                if (_combatBehavior == null)
                {
                    Log("Creating 'Combat' behavior");
                    _combatBehavior = CreateCombatBehavior();
                }

                return _combatBehavior;
            }
        }

        /// <summary>s
        /// Creates the behavior used for combat. Castsequences, add management, crowd control etc.
        /// </summary>
        /// <returns></returns>
        private Composite CreateCombatBehavior()
        {
            return new PrioritySelector(

                    CreateLowCombat()
                );
        }


        private Composite CreateLowCombat()
        {

            return new PrioritySelector(

                new Decorator(ret => RaFHelper.Leader != null,
                // Use leaders target
                              new Decorator(ret =>

                                            (RaFHelper.Leader.GotTarget && Me.GotTarget &&
                                             Me.CurrentTarget.Guid != RaFHelper.Leader.CurrentTargetGuid &&
                                             !RaFHelper.Leader.CurrentTarget.Dead &&
                                             RaFHelper.Leader.CurrentTarget.Attackable &&
                                             !RaFHelper.Leader.CurrentTarget.IsFriendly) ||

                                            (!Me.GotTarget &&
                                             RaFHelper.Leader.GotTarget &&
                                             !RaFHelper.Leader.CurrentTarget.Dead &&
                                             RaFHelper.Leader.CurrentTarget.Attackable &&
                                             !RaFHelper.Leader.CurrentTarget.IsFriendly),

                                            new Sequence(
                                                new Action(delegate
                                                {
                                                    RaFHelper.Leader.CurrentTarget.Target();
                                                }),

                                                new Wait(3, ret => Me.GotTarget,
                                                    new ActionIdle())
                                                ))),

                // Make sure we got a proper target
                new Decorator(ret => (Me.GotTarget && Targeting.Instance.FirstUnit != null && Me.CurrentTarget != Targeting.Instance.FirstUnit) || !Me.GotTarget,
                    new Sequence(

                        // Set Target!
                        new Action(ret => Targeting.Instance.FirstUnit.Target()),

                        // Wait until we got a target
                        new Wait(3, ret => Me.GotTarget,
                            new ActionIdle()))
                    ),
                

                //If we have an active pet, make it attack the same target we are.
               // new Decorator( (ret => (Me.GotTarget && Me.GotAlivePet && (!Me.Pet.GotTarget || Me.Pet.CurrentTarget != Me.CurrentTarget,
                    //new Action( ret => Lua.DoString("PetAttack()")))))),
                // Face thege tart if we aren't
                new Decorator(ret => Me.GotTarget && !Me.IsFacing(Me.CurrentTarget),
                              new Action(ret => WoWMovement.Face())),

                new Decorator(ret => Me.IsCasting || Me.Silenced,
                    new ActionIdle()),

                // Move closer to the target if we are too far away or in !Los
                new Decorator(ret => Me.GotTarget && (Me.CurrentTarget.Distance > PullDistance + 3 || !Me.CurrentTarget.InLineOfSight),
                    new NavigationAction(ret => Me.CurrentTarget.Location)),

                // At this point we shouldn't be moving. Atleast not with this 'simple' kind of logic
                new Decorator(ret => Me.IsMoving,
                              new Action(ret => WoWMovement.MoveStop())),

               new Decorator(ret => WarlockSettings.Instance.Use_LifeTap && Me.HealthPercent > WarlockSettings.Instance.LifeTap_HP_Limit && Me.ManaPercent < WarlockSettings.Instance.LifeTap_MP_Start , 
                   new PrioritySelector(
                       CreateSpellCheckAndCast("Life Tap"))),

               new Decorator(ret => Me.GotTarget && WarlockSettings.Instance.Use_Corruption && !Me.CurrentTarget.Auras.ContainsKey("Corruption"),
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Corruption")
                        )),
               new Decorator(ret => Me.GotTarget && WarlockSettings.Instance.Use_CurseofWeekness && !Me.CurrentTarget.Auras.ContainsKey("Curse of Weakness"),
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Curse of Weakness")
                        )),
               new Decorator(ret => Me.GotTarget && WarlockSettings.Instance.Use_CurseofAgony  && !Me.CurrentTarget.Auras.ContainsKey("Curse of Agony"),
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Curse of Agony")
                        )),
               new Decorator(ret => Me.GotTarget && WarlockSettings.Instance.Use_Immolate && !Me.CurrentTarget.Auras.ContainsKey("Immolate"),
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Immolate", "Immolate")
                        )),
               new Decorator(ret => WarlockSettings.Instance.Use_ShadowBolt && Me.GotTarget,
                    new PrioritySelector(
                        CreateSpellCheckAndCast("Shadow Bolt")

                        ))
                );
        }
    }
}
