﻿using System.Linq;
using Styx;
using Styx.Helpers;
using Styx.Logic.Combat;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using TreeSharp;

namespace Zerfall
{
    public partial class Zerfall
    {
        private Composite _restBehavior;
        public override Composite RestBehavior
        {
            get
            {
                if (_restBehavior == null)
                {
                    Log("Creating 'Rest' behavior");
                    _restBehavior = CreateRestBehavior();
                }

                return _restBehavior;
            }
        }

        /// <summary>
        /// Creates the behavior used for resting. Eating/Drinking
        /// </summary>
        /// <returns></returns>
        private Composite CreateRestBehavior()
        {
            return new PrioritySelector(

                // If our health and mana is 100 we make it return failure to make sure 'NeedRest' returns false and allow it to proceed executing other code!
                // also cacel any existing food/drink buff.
                new Decorator(ret => Me.HealthPercent == 100 && Me.ManaPercent == 100,
                              new Action(delegate
                                             {
                                                 if (Me.Buffs.ContainsKey("Food") || Me.Buffs.ContainsKey("Drink"))
                                                     Lua.DoString(
                                                         "CancelUnitBuff('player', 'Food') CancelUnitBuff('player', 'Drink')");

                                                 return RunStatus.Failure;
                                             })),

                new Decorator(ctx => Me.IsCasting || Me.Buffs.ContainsKey("Food") || Me.Buffs.ContainsKey("Drink"),
                              new Action(delegate { return RunStatus.Success; })
                    ),

                // Don't rest if we are mounted or swimming
                new Decorator(ctx => !Me.Mounted && !Me.IsSwimming,
                              // Decide what and if to do          
                              new PrioritySelector(
                                  // Check if we need to  take a drink or bite
                                  new Decorator(ret =>
                                                Me.ManaPercent <= WarlockSettings.Instance.RestManaPercentage
                                                || Me.HealthPercent <= WarlockSettings.Instance.RestHealthPercentage ,

                                                new Sequence(
                                                    // Clear our target
                                                    new Action(ctx => Me.ClearTarget()),
                                                    // Stop moving if we are moving
                                                    new Action(delegate
                                                                   {
                                                                       WoWMovement.MoveStop();
                                                                       return Me.IsMoving
                                                                                  ? RunStatus.Running
                                                                                  : RunStatus.Success;
                                                                   }),
                                                    new Action(ctx => WarlockRest(null)))),






                                  // Return 'Success' if we have the food or drink buff as then we should already be drinking
                                  new Decorator(ret => Me.Buffs.ContainsKey("Food") || Me.Buffs.ContainsKey("Drink"),
                                                new Action(delegate { return RunStatus.Success; })))));

                  
                                  
        }

        private static RunStatus WarlockRest(object context)
        {
            if (SpellManager.GlobalCooldown)
                return RunStatus.Running;


            if (Me.ManaPercent <= WarlockSettings.Instance.RestManaPercentage && !Me.Buffs.ContainsKey("Drink"))
                {
                    Styx.Logic.Common.Rest.Feed();
                }

                if (Me.HealthPercent <= WarlockSettings.Instance.RestHealthPercentage && !Me.Buffs.ContainsKey("Food"))
                {

                    Styx.Logic.Common.Rest.Feed();
                }
            

            return RunStatus.Success;
        }

        #region Food & Water / Rest

       

        

       
        #endregion
    }
}
