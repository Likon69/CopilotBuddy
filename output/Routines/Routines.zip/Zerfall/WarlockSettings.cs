﻿using System.IO;
using Styx;
using Styx.Helpers;

namespace Zerfall
{
    public class WarlockSettings : Settings
    {
        public static readonly WarlockSettings Instance = new WarlockSettings();

        public WarlockSettings()
            : base(Path.Combine(Logging.ApplicationPath, string.Format(@"CustomClasses/Config/Zerfall-Settings-{0}.xml", StyxWoW.Me.Name)))
        {
        }

        #region Rest

        [Setting, DefaultValue(40)]
        public int RestHealthPercentage { get; set; }

        [Setting, DefaultValue(40)]
        public int RestManaPercentage { get; set; }

        [Setting, DefaultValue(45)]
        public int LifeTap_MP_Start { get; set; }

        [Setting, DefaultValue(45)]
        public int LifeTap_HP_Limit { get; set; }

        [Setting, DefaultValue("Summon Imp")]
        public string PetSpell { get; set; }

        #region Spells

        [Setting, DefaultValue(true)]
        public bool Use_CurseofAgony { get; set; }

        [Setting, DefaultValue(true)]
        public bool Use_CurseofWeekness { get; set; }

        [Setting, DefaultValue(true)]
        public bool Use_Immolate { get; set; }

        [Setting, DefaultValue(true)]
        public bool Use_Corruption { get; set; }

        [Setting, DefaultValue(true)]
        public bool Use_LifeTap { get; set; }

        [Setting, DefaultValue(true)]
        public bool Use_ShadowBolt { get; set; }
        #endregion
        #endregion


    }
}
