﻿using Styx.Logic.Combat;
using TreeSharp;

namespace Zerfall
{
    public partial class Zerfall
    {
        private Composite _preCombatBuffBehavior;
        public override Composite PreCombatBuffBehavior
        {
            get
            {
                if (_preCombatBuffBehavior == null)
                {
                    Log("Creating 'PreCombatBuff' behavior");
                    _preCombatBuffBehavior = CreatePreCombatBuffsBehavior();
                }

                return _preCombatBuffBehavior;
            }
        }

        /// <summary>
        /// Creates the behavior used for buffing with regular buffs. eg; 'Power Word: Fortitude', 'Inner Fire' etc...
        /// </summary>
        /// <returns></returns>
        private Composite CreatePreCombatBuffsBehavior()
        {
            return new PrioritySelector(
                new Decorator(ret => !Me.Mounted,
                              new PrioritySelector(
                                  CreateBuffCheckAndCast("Demon Skin")
                                  )),
                 new Decorator(ret => !GotPet(),
                              new PrioritySelector(
                                  SummonPet(WarlockSettings.Instance.PetSpell)
                                  ))

                );
        }
    }
}
