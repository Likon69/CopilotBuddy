//
// skiWarlock
// Original: 03/27/2010
// Last Updated: 8:19 PM 20/08/2010
//
//
// Thanks to:
// king
// Mordd
// fpsware
// DarkBen
// CodeNameG
// erenion
// MaiN
// thedrunk
//

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Xml.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using Styx;
using Styx.Logic;
using Styx.Helpers;
using Styx.Logic.Pathing;
using Styx.Combat.CombatRoutine;
using Styx.Logic.Combat;
using Styx.Logic.Profiles;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System.ComponentModel;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

#pragma warning disable
namespace Styx.Bot.CustomClasses
{
	public class skiWarlock : CombatRoutine
	{
		#region Initialize
		public static skiWarlock Instance;
		public skiWarlockGUI.SettingsProfile Settings;
		public readonly skiWarlockGUI.SettingsProfile DefaultSettings = new skiWarlockGUI.SettingsProfile();
		public List<string> SettingsDisplayIgnore = new List<string>(){ "Name", "PathPrecision", "Pet", "FightAdds", "MassPull" };
		public bool UseAffliction;
		public bool UseDemonology;
		public bool UseDestruction;
		public bool UseDefault;
		
		public int PetID;
		public int FearCountPVE;
		bool SummonPetNeeded = false;
		bool RAFFollow = false;
		public bool _Debug = false;
		public static int MaxLevel { get { return (int) (ProfileManager.CurrentProfile.MaxLevel != null ? ProfileManager.CurrentProfile.MaxLevel : 99); } }
		public static int MinLevel { get { return (int) (ProfileManager.CurrentProfile.MinLevel != null ? ProfileManager.CurrentProfile.MinLevel : 0); } }
		public bool FightAddsWithAOE = true;
		public Dictionary<string, int> PetData = new Dictionary<string, int>(){
			{ "Imp",	416 },
			{ "Voidwalker",	1860 },
			{ "Succubus",	1863 },
			{ "Felhunter",	417 },
			{ "Felguard",	17252 },
		};
		
		// HB overrides
		public override WoWClass Class { get { return WoWClass.Warlock; } }
		public override string Name { get { return "skiWarlock v3." + Regex.Replace("$Rev: 69 $", @"\$Rev: (\d+) \$", "$1"); } }
		public override bool WantButton { get { return true; } }
		
		private static Thread thread { get; set; }
		private skiWarlockGUI _skiWarlockGUI = new skiWarlockGUI();
		private skiWarlockGUI.skiWarlockConfig _skiWarlockConfig = new skiWarlockGUI.skiWarlockConfig();
		private static BotEvents.Battleground.BattlegroundEnterDelegate EventBattlegroundEnterDelegate;
		private static BotEvents.Battleground.BattlegroundLeftDelegate EventBattlegroundLeftDelegate;
		private static BotEvents.Player.LevelUpDelegate EventLevelUpDelegate;
		private static BotEvents.OnBotStartDelegate EventBotStartDelegate;
		private static BotEvents.OnBotStopDelegate EventBotStopDelegate;
		public bool UseMoltenCore = false;
		
		public override void OnButtonPress()
		{
			thread = new Thread(OpenGUI) { IsBackground = true, Name = "GUIThread" };
			thread.Start();
		}
		public void OpenGUI()
		{
			if (_skiWarlockGUI.Visible)
			{
				_skiWarlockGUI.Hide();
			}
			_skiWarlockGUI.ShowDialog();
		}
		public override void Initialize()
		{
			Instance = this;
			InitializeEventHooks();
		}
		public void LoadSettings()
		{
			// Update global settings from config file
			_skiWarlockConfig.Load();
			// Log
			mlog("Initializing: Loading Settings Profile: {0}", _skiWarlockConfig.ActiveSettingsProfile);
			// Load settings profile - uses object from skiWarlockGUI
			Settings = skiWarlockGUI.LoadProfile(_skiWarlockConfig.ActiveSettingsProfile);
			// Switch specs for PVP
			if (_skiWarlockConfig.UseSecondaryTalentSpecForPVP && LuaGetInt("GetNumTalentGroups(false, false)") > 1)
			{
				int ActiveTalentGroup = LuaGetInt("GetActiveTalentGroup()");
				if (InBattleground && ActiveTalentGroup == 1)
				{
					LuaDo("SetActiveTalentGroup(2)");
					WaitWhileCasting();
				}
				else if (ActiveTalentGroup == 2)
				{
					LuaDo("SetActiveTalentGroup(1)");
					WaitWhileCasting();
				}
			}
			// Determine talent spec
			CC_TalentGroup primaryTalents = new CC_TalentGroup();
			CC_TalentGroup secondaryTalents = new CC_TalentGroup();
			primaryTalents.Load(1);
			secondaryTalents.Load(2);
			CC_TalentGroup TalentGroup = (primaryTalents.IsActiveGroup() ? primaryTalents : secondaryTalents);
			if (TalentGroup.Spec() == 1)
			{
				dplog("Initializing: Spec: Affliction");
				
				UseAffliction = true;
				if (Settings.Pet == "Auto")
				{
					Settings.Pet = (SpellManager.KnownSpells.ContainsKey("Summon Felhunter") ? "Felhunter" : "Voidwalker");
				}
			}
			else if (TalentGroup.Spec() == 2)
			{
				dplog("Initializing: Spec: Demonology");
				
				UseDemonology = true;
				if (Settings.Pet == "Auto")
				{
					Settings.Pet = (SpellManager.KnownSpells.ContainsKey("Summon Felguard") ? "Felguard" : "Voidwalker");
				}
				
			}
			else if (TalentGroup.Spec() == 3)
			{
				dplog("Initializing: Spec: Destruction");
				
				UseDestruction = true;
				if (Settings.Pet == "Auto")
				{
					Settings.Pet = "Imp";
				}
			}
			else
			{
				dplog("Initializing: Spec: Default (Below Level 10)");
				
				UseDefault = true;
				if (Settings.Pet == "Auto")
				{
					Settings.Pet = (Me.Level >= 10 ? "Voidwalker" : "Imp");
				}
			}
			// Disable Mana Feed mechanic - if we dont have it
			if (Settings.UseManaFeed && LuaGetInt("name, iconTexture, tier, column, rank = GetTalentInfo(2, 14, false, false, nil); return rank;") == 0)
			{
				Settings.UseManaFeed = false;
			}
			// Enable Molten Core mechanic - if we have any ranks
			if (LuaGetInt("name, iconTexture, tier, column, rank = GetTalentInfo(2, 17, false, false, nil); return rank;") > 0)
			{
				UseMoltenCore = true;
			}
			// Pet
			PetID = PetData[Settings.Pet];
			slog("Initializing: Pet: {0}", Settings.Pet, PetID);
			// Turn off FightAdds if we dont have SoC
			FightAddsWithAOE = true;
			if (Settings.FightAdds && !SpellManager.KnownSpells.ContainsKey("Seed of Corruption"))
			{
				FightAddsWithAOE = false;
			}
			slog("Initializing: Fight Adds: {0}, With AOE: {1}", Settings.FightAdds, FightAddsWithAOE);
			// RAF
			if (!InBattleground && inParty && RaFHelper.Leader != null && RaFHelper.Leader.Guid != Me.Guid)
			{
				slog("Initializing: RAF: Follow mode enabled");
				RAFFollow = true;
			}
			slog("Initializing: Mass Pull: {0}", Settings.MassPull);
			// Set PathPrecision
			slog("Initializing: Path Precision: {0}", Settings.PathPrecision);
			Styx.Logic.Pathing.Navigator.PathPrecision = Settings.PathPrecision;
			// Low Level character checks
			// Check for spells we dont have yet, then disable them
			if (Settings.UseCorruption && !SpellManager.HasSpell("Corruption"))
			{
				Settings.UseCorruption = false;
			}
            if (Settings.UseCoA && !SpellManager.HasSpell("Curse of Agony"))
			{
				Settings.UseCoA = false;
			}
			// Log any Setting from the current Settings Profile that is not default
			// Variables
			List<string> Differences = new List<string>();
			// Get the SettingsProfile Type
			Type SettingsProfileType = DefaultSettings.GetType();
			// Get Properties from Type
			PropertyInfo[] propertyInfo = SettingsProfileType.GetProperties();
			// Iterate all Properties - order by Name, ignore any settings in SettingsDisplayIgnore
			foreach (PropertyInfo info in propertyInfo.OrderBy(obj => (obj.Name)).Where(obj => (!SettingsDisplayIgnore.Contains(obj.Name))))
			//foreach (PropertyInfo info in propertyInfo)
			{
				// Variables - grab the information we need to work with from our current Settings Profile and the Default Settings Profile
				// NOTE: ToString() does not work as intended here - use Convert.ToString() instead
				string Name = Convert.ToString(info.Name);
				string Value = Convert.ToString(info.GetValue(Settings, null));
				string DefaultValue = Convert.ToString(info.GetValue(DefaultSettings, null));
				// Test - Does this variables value differ from the Default? If so, push into our Differences List
				if (Value != DefaultValue)
				{
					Differences.Add(string.Format("{0}: {1}", Name, (Value == "0" ? "Disabled" : Value)));
					//Differences.Add(string.Format("Name: {0}, Value: {1}, Default: {2}", Name, Value, DefaultValue));
				}
			}
			
			// Check Differences - output to log
			slog("---");
			if (Differences.Count > 0)
			{
				mlog("Initializing: Displaying customized Settings Profile variables");
				foreach (string Difference in Differences)
				{
					// doesnt work as intended :(
					//slog("Initializing: {0}", Difference);
					slog("Initializing: " + Difference);
				}
			}
			slog("---");
			slog("Initializing: Complete");
		}
		// Hook events
		public void InitializeEventHooks()
		{
			if (EventBattlegroundEnterDelegate == null)
			{
				EventBattlegroundEnterDelegate = new BotEvents.Battleground.BattlegroundEnterDelegate(EventBattlegroundEnter);
				BotEvents.Battleground.OnBattlegroundEntered += EventBattlegroundEnterDelegate;
			}
			if (EventBattlegroundLeftDelegate == null)
			{
				EventBattlegroundLeftDelegate = new BotEvents.Battleground.BattlegroundLeftDelegate(EventBattlegroundLeft);
				BotEvents.Battleground.OnBattlegroundLeft += EventBattlegroundLeftDelegate;
			}
			if (EventLevelUpDelegate == null)
			{
				EventLevelUpDelegate = new BotEvents.Player.LevelUpDelegate(EventLevelUp);
				BotEvents.Player.OnLevelUp += EventLevelUpDelegate;
			}
			if (EventBotStartDelegate == null)
			{
				EventBotStartDelegate = new BotEvents.OnBotStartDelegate(EventBotStart);
				BotEvents.OnBotStart += EventBotStartDelegate;
			}
			if (EventBotStopDelegate == null)
			{
				EventBotStopDelegate = new BotEvents.OnBotStopDelegate(EventBotStop);
				BotEvents.OnBotStop += EventBotStopDelegate;
			}
		}
		// Battleground entered
		private void EventBattlegroundEnter(BattlegroundType Battleground)
		{
			rlog("Entered Battleground: {0}", Battleground);
			InitializeBattleground();
		}
		// Battleground left
		private void EventBattlegroundLeft(EventArgs args)
		{
			// Battleground left - load grind setting profile
			rlog("Left Battleground");
			InitializeGrind();
		}
		// Level up
		private void EventLevelUp(EventArgs args)
		{
			// TODO: Reload spell book
			rlog("Level up! Grats on level {0}!", Me.Level);
		}
		// Start is pressed
		private void EventBotStart(EventArgs args)
		{
			// Log
			rlog("Starting {0}", Name);
			// Load config data - uses object from skiWarlockGUI
			_skiWarlockConfig.Load();
			// Load settings profile based on activity
			if (InBattleground)
			{
				InitializeBattleground();
			}
			else
			{
				InitializeGrind();
			}
		}
		// Stop is pressed
		private void EventBotStop(EventArgs args)
		{
			rlog("Stopping {0}", Name);
		}
		// Load battleground settings profile
		private void InitializeBattleground()
		{
			olog("Selecting PVP Settings Profile", _skiWarlockConfig.PVPSettingsProfile);
			LoadProfile(_skiWarlockConfig.PVPSettingsProfile);
		}
		// Load grind settings profile
		private void InitializeGrind()
		{
			olog("Selecting Grind Settings Profile", _skiWarlockConfig.GrindSettingsProfile);
			LoadProfile(_skiWarlockConfig.GrindSettingsProfile);
		}
		// Set a profile as active, save settings, reinit bot
		private void LoadProfile(string Name)
		{
			_skiWarlockConfig.ActiveSettingsProfile = Name;
			_skiWarlockConfig.Save();
			LoadSettings();
		}
		
		// Variables
		private string _logspam;
		private int _logspamMobCount;
		private readonly LocalPlayer Me = ObjectManager.Me;
		private static Stopwatch PetPresenceTimer = new Stopwatch();
		private static Stopwatch fightTimer = new Stopwatch();
		private static Stopwatch addsTimer = new Stopwatch();
		private static Stopwatch MassPullTimer = new Stopwatch();
		private static ulong lastGuid;
		private int fearNum;
		#endregion
		#region Need Rest
		public override bool NeedRest
		{
			get
			{
				//if (Styx.Logic.Battlegrounds.Finished)
				// Dont rest in battlegrounds
				if (InBattleground)
				{
					return false;
				}
				// Rest checks
				// Dark Pact
				if (Settings.UseDarkPact && Me.GotAlivePet && Me.ManaPercent < Settings.DarkPactMinMana && SpellManager.CanCastSpell("Dark Pact") && Me.Pet.ManaPercent > 5)
				{
					blog("NeedRest: Need to Dark Pact");
					return true;
				}
				
				// Detect Invisibility
				if (SpellManager.CanCastSpell("Detect Invisibility") && Settings.UseDetectInvisibility && !Me.Buffs.ContainsKey("Detect Invisibility"))
				{
					slog("NeedRest: Need Detect Invisibility");
					return true;
				}
				
				// Life Tap - for caster or pet mana
				if ((	SpellManager.CanCastSpell("Life Tap") &&
					Me.HealthPercent > Settings.LifeTapMinHealth &&
					Me.ManaPercent < Settings.LifeTapMaxMana && !Settings.UseDarkPact)
					||
					(Settings.UseManaFeed && !Me.Mounted && Me.GotAlivePet && Me.Pet.ManaPercent < Settings.ManaFeedPetManaPercent)
					)
				{
					blog("NeedRest: Need to Lifetap");
					return true;
				}
				
				// Delete shards
				if (SoulShardCount > Settings.MaxShards)
				{
					slog("NeedRest: Too many shards, deleting one");
					return true;
				}
				
				// Pet Presence check reset
				if (Me.Mounted)
				{
					PetPresenceTimer.Stop();
					PetPresenceTimer.Reset();
				}
				// Dont check pet rest variables while mounted
				if (!Me.Mounted)
				{
					PetPresenceTimer.Start();
					
					// Reset Pet Presence variables
					if (PetPresenceTimer.ElapsedMilliseconds > 2000 &&
						SpellManager.CanCastSpell("Summon Imp") &&
						!Me.GotAlivePet)
					{
						slog("NeedRest: Need Demon");
						PetPresenceTimer.Reset();
						SummonPetNeeded = true;
						return true;
					}
					// Soul Link
					if (SpellManager.CanCastSpell("Soul Link") && !Me.Buffs.ContainsKey("Soul Link") && Me.GotAlivePet && PetPresenceTimer.ElapsedMilliseconds > 2000)
					{
						slog("NeedRest: Need Soul Link");
						return true;
					}
					
					// Health Funnel
					if (SpellManager.CanCastSpell("Health Funnel") &&
						Me.GotAlivePet &&
						Me.Pet.HealthPercent < Settings.HealPetPercent &&
						Me.HealthPercent > Settings.DontHealPetBelow &&
						!Me.Pet.GetBuffs(true).ContainsKey("Health Funnel") &&
						PetPresenceTimer.ElapsedMilliseconds > 2000)
					{
						glog("NeedRest: Need Pet Heal");
						PetPresenceTimer.Reset();
						return true;
					}
					// Armor buff
					if (Settings.UseArmorBuff)
					{
						// Fel Armor
						if (SpellManager.CanCastSpell("Fel Armor") && !Me.Buffs.ContainsKey("Fel Armor"))
						{
							slog("NeedRest: Need Fel Armor");
							return true;
						}
						// Demon Armor
						else if (!SpellManager.KnownSpells.ContainsKey("Fel Armor") && SpellManager.CanCastSpell("Demon Armor") && !Me.Buffs.ContainsKey("Demon Armor"))
						{
							slog("NeedRest: Need Demon Armor");
							return true;
						}
						// Demon Skin
						else if (!SpellManager.KnownSpells.ContainsKey("Fel Armor") && !SpellManager.KnownSpells.ContainsKey("Demon Armor") && SpellManager.CanCastSpell("Demon Skin") && !Me.Buffs.ContainsKey("Demon Skin"))
						{
							slog("NeedRest: Need Demon Skin");
							return true;
						}
					}
					//if (Me.GotAlivePet && SpellManager.KnownSpells.ContainsKey("Summon Imp") && SpellManager.KnownSpells.ContainsKey("Summon " + pet) && Me.Pet.Entry == PetID && SoulShardCount > 0 && Battlegrounds.Battlegroundstatus != BattlegroundStatus.Active) {
					//	Thread.Sleep(500);
					// slog("NeedRest: Need to Replace Pet");
					//	return true;
					//}
				}
				
				// Unending Breath
				if (Settings.UseUnendingBreath && SpellManager.CanCastSpell("Unending Breath") && !Me.Buffs.ContainsKey("Unending Breath"))
				{
					slog("NeedRest: Need Unending Breath");
					return true;
				}
				
				// Healthstone
				if (Settings.UseHealthstone && myHealthstone == null && SoulShardCount > 1 && SpellManager.CanCastSpell("Create Healthstone"))
				{
					glog("NeedRest: Need a Healthstone");
					return true;
				}
				// Low Health
				if (Me.HealthPercent < Settings.RestHealth && !Styx.Logic.Common.Rest.NoFood && !Me.Buffs.ContainsKey("Food") && !Me.IsSwimming)
				{
					glog("NeedRest: Need Health: {0}%", Me.HealthPercent);
					return true;
				}
				
				// Low Mana
				if (Me.ManaPercent < Settings.RestMana && !Styx.Logic.Common.Rest.NoDrink && !Me.Buffs.ContainsKey("Drink") && !Me.IsSwimming)
				{
					blog("NeedRest: Need Mana: {0}%", Me.ManaPercent);
					return true;
				}
				
				// Spellstone
				if (Settings.UseSpellstone && mySpellstone == null && SoulShardCount > 1 && SpellManager.CanCastSpell("Create Spellstone"))
				{
					slog("NeedRest: Need Spellstone");
					return true;
				}
				
				// Firestone
				if (Settings.UseFirestone && myFirestone == null && SoulShardCount > 1 && SpellManager.CanCastSpell("Create Firestone"))
				{
					slog("NeedRest: Need Firestone");
					return true;
				}
				
				// Soulstone
				if (Settings.UseSoulstone && mySoulstone == null && !Me.Buffs.ContainsKey("Soulstone Resurrection") && SpellManager.CanCastSpell("Create Soulstone") && SoulShardCount > 1)
				{
					slog("NeedRest: Need Soulstone");
					return true;
				}
				
				// Soulstone: Apply
				if (Settings.UseSoulstone && mySoulstone != null && !Me.Buffs.ContainsKey("Soulstone Resurrection") && !IsItemOnCooldown(mySoulstone))
				{
					slog("NeedRest: Need to apply Soulstone");
					return true;
				}
				// Spellstone: Apply to weapon
				if (Settings.UseSpellstone && mySpellstone != null && !_spellstoneEnchantEntryId.Contains(Me.Mainhand.TemporaryEnchantment.Id) && !_firestoneEnchantEntryId.Contains(Me.Mainhand.TemporaryEnchantment.Id) && SpellManager.CanCastSpell("Create Spellstone"))
				{
					slog("NeedRest: Need to apply Spellstone Enchant to weapon");
					return true;
				}
				
				// Firestone: Apply to weapon
				if (Settings.UseFirestone && myFirestone != null && !_firestoneEnchantEntryId.Contains(Me.Mainhand.TemporaryEnchantment.Id) && !_spellstoneEnchantEntryId.Contains(Me.Mainhand.TemporaryEnchantment.Id) && SpellManager.CanCastSpell("Create Firestone"))
				{
					slog("NeedRest: Need to apply Firestone Enchant to weapon");
					return true;
				}
				
				// Return false - dont need to rest
				return false;
			}
		}
		#endregion
		#region Rest
		public override void Rest()
		{
			// Dismount to cast
			if (Me.Mounted)
			{
				Mount.Dismount();
			}
			
			// Summon Pet
			if (!Me.GotAlivePet && SpellManager.KnownSpells.ContainsKey("Summon Imp") && !Me.Mounted && SummonPetNeeded)
			{
				// Fel Domination
				if (SpellManager.KnownSpells.ContainsKey("Fel Domination") &&
					SpellManager.CanCastSpell("Fel Domination") &&
					!SpellManager.KnownSpells["Fel Domination"].Cooldown)
				{
					FelDomination();
				}
				
				// Summon Pet - Summon imp if we dont have shards or dont know the configured Pet
				if (SoulShardCount == 0 || !SpellManager.KnownSpells.ContainsKey("Summon " + Settings.Pet))
				{
					Thread.Sleep(500);
					slog("Rest: Summon Imp");
					SummonImp();
					SummonPetNeeded = false;
				}
				else
				{
					Thread.Sleep(500);
					slog("Rest: Summon " + Settings.Pet);
					SummonPet();
				}
			}
			// Replace Imp with desired Pet
			// if (Me.GotAlivePet && SpellManager.KnownSpells.ContainsKey("Summon Imp") && SpellManager.KnownSpells.ContainsKey("Summon " + pet) && !Me.Mounted && Me.Pet.Entry == PetID && SoulShardCount > 0 && Battlegrounds.Battlegroundstatus != BattlegroundStatus.Active) {
			//	Thread.Sleep(500);
			//   slog("Rest: Replacing Pet");
			//	SummonPet();
			// }
			
			// Dark Pack
			if (Settings.UseDarkPact && Me.ManaPercent < Settings.DarkPactMinMana && Me.GotAlivePet && SpellManager.CanCastSpell("Dark Pact") && Me.Pet.ManaPercent > 5)
			{
				blog("Rest: Dark Pact");
				DarkPact();
			}
			
			// Life Tap
			if (	SpellManager.CanCastSpell("Life Tap") &&
				((Me.HealthPercent > Settings.LifeTapMinHealth && Me.ManaPercent < Settings.LifeTapMaxMana)
				||
				(Settings.UseManaFeed && Me.GotAlivePet && Me.Pet.ManaPercent < Settings.ManaFeedPetManaPercent)))
			{
				blog("Rest: Casting Lifetap");
				LifeTap();
			}
			
			// Healthstone
			if (Settings.UseHealthstone && SoulShardCount > 1 && SpellManager.CanCastSpell("Create Healthstone") && myHealthstone == null)
			{
				glog("Rest: Create Healthstone");
				CreateHealthstone();
			}
			
			// Soul Link
			if (Me.GotAlivePet && SpellManager.CanCastSpell("Soul Link") && !Me.Buffs.ContainsKey("Soul Link"))
			{
				slog("Rest: Soul Link");
				SoulLink();
			}
			
			// Detect Invisibility
			if (SpellManager.CanCastSpell("Detect Invisibility") && Settings.UseDetectInvisibility && !Me.Buffs.ContainsKey("Detect Invisibility"))
			{
				slog("Rest: Detect Invisibility");
				DetectInvisibility();
			}
			
			// Armor buff
			if (Settings.UseArmorBuff)
			{
				// Fel Armor
				if (SpellManager.CanCastSpell("Fel Armor") && !Me.Buffs.ContainsKey("Fel Armor"))
				{
					slog("Rest: Fel Armor");
					FelArmor();
				}
				// Demon Armor
				else if (!SpellManager.KnownSpells.ContainsKey("Fel Armor") && SpellManager.CanCastSpell("Demon Armor") && !Me.Buffs.ContainsKey("Demon Armor"))
				{
					slog("Rest: Demon Armor");
					DemonArmor();
				}
				// Demon Skin
				else if (!SpellManager.KnownSpells.ContainsKey("Fel Armor") && !SpellManager.KnownSpells.ContainsKey("Demon Armor") && SpellManager.CanCastSpell("Demon Skin") && !Me.Buffs.ContainsKey("Demon Skin"))
				{
					slog("Rest: Demon Skin");
					DemonSkin();
				}
			}
			
			// Anything past here is not instant - stop moving is we are moving
			if (Me.IsMoving)
			{
				WoWMovement.MoveStop();
			}
			// Health Funnel
			if (SpellManager.CanCastSpell("Health Funnel") &&
					Me.GotAlivePet &&
					Me.Pet.HealthPercent < Settings.HealPetStopPercent &&
					Me.Pet.HealthPercent < Settings.HealPetPercent &&
					Me.HealthPercent > Settings.DontHealPetBelow &&
					!Me.Pet.GetBuffs(true).ContainsKey("Health Funnel") &&
					PetPresenceTimer.ElapsedMilliseconds > 2000)
			{
				glog("Rest: Health Funnel");
				HealthFunnel();
			}
			
			// Create Soulstone
			if (Settings.UseSoulstone && mySoulstone == null && !Me.Buffs.ContainsKey("Soulstone Resurrection") && SpellManager.CanCastSpell("Create Soulstone") && SoulShardCount > 1)
			{
				slog("Rest: Creating Soulstone");
				CreateSoulstone();
			}
			
			// Create Spellstone
			if (Settings.UseSpellstone && mySpellstone == null && SpellManager.CanCastSpell("Create Spellstone") && SoulShardCount > 1)
			{
				slog("Rest: Creating Spellstone");
				CreateSpellstone();
			}
			
			// Create Firestone
			if (Settings.UseFirestone && myFirestone == null && SpellManager.CanCastSpell("Create Firestone") && SoulShardCount > 1)
			{
				slog("Rest: Creating Firestone");
				CreateFirestone();
			}
			// Use Spellstone
			if (Settings.UseSpellstone && mySpellstone != null && SpellManager.CanCastSpell("Create Spellstone") && !_spellstoneEnchantEntryId.Contains(Me.Mainhand.TemporaryEnchantment.Id) && !_firestoneEnchantEntryId.Contains(Me.Mainhand.TemporaryEnchantment.Id))
			{
				
				
				slog("Rest: Applying Spellstone to weapon");
				Lua.DoString("UseItemByName(\"" + mySpellstone.Name + "\")");
				Thread.Sleep(300);
				Lua.DoString("UseInventoryItem(16)");
				Thread.Sleep(300);
				WaitWhileCasting();
			}
			
			// Use Firestone
			if (Settings.UseFirestone && myFirestone != null && SpellManager.CanCastSpell("Create Firestone") && !_spellstoneEnchantEntryId.Contains(Me.Mainhand.TemporaryEnchantment.Id) && !_firestoneEnchantEntryId.Contains(Me.Mainhand.TemporaryEnchantment.Id))
			{
				if (Me.IsMoving) WoWMovement.MoveStop();
				
				slog("Rest: Applying Firestone to weapon");
				Lua.DoString("UseItemByName(\"" + myFirestone.Name + "\")");
				Thread.Sleep(300);
				Lua.DoString("UseInventoryItem(16)");
				Thread.Sleep(300);
				WaitWhileCasting();
			}
			
			// Use Soulstone
			if (Settings.UseSoulstone && mySoulstone != null && !IsItemOnCooldown(mySoulstone))
			{
				if (Me.IsMoving) WoWMovement.MoveStop();
				
				slog("Rest: Applying Soulstone");
				Lua.DoString("UseItemByName(\"" + mySoulstone.Name + "\")");
				Thread.Sleep(300);
				WaitWhileCasting();
			}
			
			// Unending Breath
			if (Settings.UseUnendingBreath && SpellManager.CanCastSpell("Unending Breath") && !Me.Buffs.ContainsKey("Unending Breath"))
			{
				slog("Rest: Unending Breath");
				UnendingBreath();
			}
			// Eat Food
			if (!Styx.Logic.Common.Rest.NoFood && Me.HealthPercent < Settings.RestHealth && !Me.IsSwimming)
			{
				slog("Rest: Eating Food");
				Logic.Common.Rest.Feed();
			}
			// Drink Water
			if (!Styx.Logic.Common.Rest.NoDrink && Me.ManaPercent < Settings.RestMana && !Me.IsSwimming)
			{
				slog("Rest: Drinking Drink");
				Logic.Common.Rest.Feed();
			}
			
			// Delete shards if we have too many
			if (SoulShardCount > Settings.MaxShards)
			{
				slog("Rest: Deleting Shard");
				DeleteShard();
			}
		}
		#endregion
		#region Pull
		public override void Pull()
		{
			// BG check
			BattlegroundTargetCheck();
			
			// Last mob check
			if (Me.CurrentTarget.Guid != lastGuid)
			{
				fightTimer.Reset();
				lastGuid = Me.CurrentTarget.Guid;
				if (Me.CurrentTarget.IsPlayer)
				{
					slog("Pull: Target is a Player");
				}
				slog("Pull: Killing {0} at distance {1} yards", Me.CurrentTarget.Name, Math.Round(Me.CurrentTarget.Distance).ToString());
				pullTimer.Reset();
				pullTimer.Start();
			}
			
			// Move within range of mob
			MoveWithinRangeToMob("Pull", Me.CurrentTarget);
			
			// Pet Attack
			if (combatChecks && Me.GotAlivePet && Settings.UsePetAttack)
			{
				if (!Me.Pet.IsAutoAttacking)
				{
					Lua.DoString("PetAttack()");
				}
				PetPresenceTimer.Reset();
			}
			// Lifetap (Rank 1) before pull
			if (Settings.PullWithGlyphOfLifeTap && !Me.Buffs.ContainsKey("Life Tap"))
			{
				slog("Pull: Lifetap (Rank 1) for Glyph of Life Tap buff");
				SpellManagerEx.Cast(1454, Me.CurrentTarget);
			}
			// Pull with Shadow Bolt
			if (Settings.PullWithShadowBolt)
			{
				slog("Pull: Pulling with Shadow Bolt");
				ShadowBolt();
			}
			
			// Reset variables
			FearCountPVE = 0;
			
			// Call Combat
			Combat();
		}
		#endregion
		#region Combat
		public override void Combat()
		{
			int tickCount = Environment.TickCount;
			
			// While not in PVP: If our target is too far away, drop target and return
			if (!InBattleground && Me.GotTarget && Me.CurrentTarget.Distance > (Targeting.PullDistance * 2))
			{
				Me.ClearTarget();
				return;
			}
			
			// If im attacking a mob that is attacking me, and the pet is not attacking the mob
			//if (Me.CurrentTarget.CurrentTargetGuid == Me.Guid && Me.Pet.CurrentTargetGuid != Me.CurrentTarget.CurrentTargetGuid) Lua.DoString("PetAttack()");
			
			// Dismount if mounted
			if (Me.Mounted && !InBattleground) Mount.Dismount();
			
			// Clear target if CurrentTarget is dead
			if (Me.GotTarget && !Me.CurrentTarget.IsAlive)
			{
				Me.ClearTarget();
				Thread.Sleep(200);
			}
			
			// Update mobs attacking us
			UpdateAddList();
			
			// If in combat and have no target, find one!
			if (!Me.GotTarget)
			{
				// RAF: Target 
				if (RAFFollow && RaFHelper.Leader.CurrentTargetGuid != 0)
				{
					Target("Combat: Raf", RaFHelper.Leader.CurrentTarget, true);
					return;
				}
				
				// If we find an attacking mob
				if (GotAdds)
				{
					// Log
					slog("Combat: Finding target..");
					
					// Find valid mob
					int mobIndex = 0;
					do
					{
						AddList[mobIndex++].Target();
					} while (!Me.GotTarget && (Me.GotTarget && !Me.CurrentTarget.IsAlive) && AddList.Count < mobIndex);
					
					// Pet attack if we have a mob
					PetAttack("Find Target", Me.CurrentTarget, false);
					
					// Move to attack range
					MoveWithinRangeToMob("Find Target", Me.CurrentTarget);
				}
				else
				// No attacking mobs
				{
					// Recall pet
					Lua.DoString("PetFollow()");
					
					// Log
					slog("Combat: No target found, ending combat..");
					
					// Return from Combat()
					return;
				}
			}
			
			// Line of Sight
			//MoveIntoLineOfSight("Combat");
			
			// Mass Pull
			if (Settings.MassPull && !InBattleground && !RAFFollow)
			{
				// Things attacking us
				//UpdateAddList();
				// Things not attacking us, but valid to attack
				UpdateMobList();
				if (_Debug) if ((MobList.Count + AddList.Count) > Settings.MassPullMaxAdds) rlog("DEBUG: Mass Pull: Not pulling, would pull too many mobs: could pull = " + (MobList.Count + AddList.Count) + ", max pull = " + Settings.MassPullMaxAdds); // DEBUG
				//if (_Debug) if (AddList.Count <= MassPullMinAdds) rlog("DEBUG: Mass Pull: Pulling more, not enough mobs: adds = " + AddList.Count + ", min = " + MassPullMinAdds); // DEBUG
				if ((Me.Combat && MobList.Count >= 1 && AddList.Count <= (Settings.MassPullMaxAdds / 2) && (MobList.Count + AddList.Count) < Settings.MassPullMaxAdds && Me.HealthPercent > Settings.MassPullMinInCombatHealth && Me.ManaPercent > Settings.MassPullMinInCombatMana && Me.GotAlivePet && Me.Pet.HealthPercent > Settings.MassPullMinInCombatHealth && Me.Pet.ManaPercent > Settings.MassPullMinInCombatMana)
					||
					(!Me.Combat && MobList.Count >= 2)
					)
				{
					// Log
					mlog("Mass Pulling: " + (MobList.Count > Settings.MassPullMaxAdds ? Settings.MassPullMaxAdds : MobList.Count));
					
					// Iterate the Mob List, sending the pet to attack each
					int i = 1;
					while (MobList.Count > 0 && i < Settings.MassPullMaxAdds)// && MassPullMobIndex++ < MassPullMaxAdds
					{
						// Log
						mlog("MassPull: " + i + ": Pulling: " + MobList[0].Name);
						
						// Target
						Target("MassPull: " + i, MobList[0], true);
						
						// Face
						WoWMovement.Face();
						// Start timer - used in check below
						MassPullTimer.Reset();
						MassPullTimer.Start();
						
						// Variables
						double petToMobDistance = Me.Pet.Location.Distance(MobList[0].Location);
						
						// Iterate while the mob is not attacking us
						while (!MobList[0].IsTargetingMe && !MobList[0].IsTargetingPet && !MobList[0].GetBuffs(true).ContainsKey("Intercept"))
						{
							// Single spell rotation pull
							if (Settings.MassPullWithSpell && Me.CurrentTarget.IsAlive)
							{
								MoveWithinRangeToMob("MassPull: " + i, Me.CurrentTarget);
								SingleRotation("MassPull: " + i, Me.CurrentTarget);
							}
							
							// Things that can go wrong :(
							// Pet dies
							if (!Me.GotAlivePet)
							{
								mlog("MassPull: " + i + ": Pet has died... this is going to hurt");
								break;
							}
							// Distance between Caster
							else if (MobList[0].Distance > (Targeting.PullDistance * 1.5))
							{
								mlog("MassPull: " + i + ": Invalid target: Caster->Mob Distance");
								break;
							}
							// Distance between Pet
							else if (Me.Combat && Me.Pet.Location.Distance(MobList[0].Location) > (Targeting.PullDistance * 1.5))
							{
								mlog("MassPull: " + i + ": Invalid target: Pet->Mob Distance");
								break;
							}
							// Too high to too low
							else if (((Me.Z - MobList[0].Z) > 10 || (MobList[0].Z - Me.Z) > 10))
							{
								mlog("MassPull: " + i + ": Invalid target: Z Distance");
								break;
							}
							// Mob is not alive
							else if (!MobList[0].IsAlive)
							{
								mlog("MassPull: " + i + ": Invalid target: Target died");
								break;
							}
							// Timeout
							//else if (MassPullTimer.Elapsed.TotalSeconds >= (Targeting.PullDistance * 1.5 / 10))
							else if (MassPullTimer.Elapsed.TotalSeconds >= (petToMobDistance * 8 / 10))
							{
								Logic.Blacklist.Add(MobList[0].Guid, TimeSpan.FromMinutes(1.00));
								mlog("MassPull: " + i + ": Invalid target: Timeout");
								break;
							}
							
							// Pet Attack
							if (Me.Pet.CurrentTargetGuid != MobList[0].Guid)
							{
								PetAttack("MassPull: " + i, MobList[0], false);
							}
							
							// Wait
							Thread.Sleep(200);
						}
						
						// Stop timer
						MassPullTimer.Stop();
			
						// Range check - every 2nd mob, move to optimum range if too far from pet
						if (i % 2 != 0)
						{
							MoveWithinRangeToPet("MassPull: " + i);
						}
						
						// Remove current mob from list
						MobList.RemoveAt(0);
						// Sort by Pet->Mob distance, closest to pet
						MobList.Sort(SortByPetDistance);
						// Reverse, furthest away from pet
						//MobList.Reverse();
						
						// Log
						//mlog("MassPull: " + i + ": Gained aggro");
						
						i++;
					}
					
					//mlog("MassPull: Complete");
				}
			}
			
			// Use pet to attack - if its not already attacking
			if (Settings.UsePetAttack && Me.GotAlivePet && !Me.Pet.IsAutoAttacking)
			{
				PetAttack("Combat", Me.CurrentTarget, false);
			}
			// Health Funnel
			if (Me.GotAlivePet &&
				SpellManager.CanCastSpell("Health Funnel") &&
				Me.Pet.HealthPercent < Settings.HealPetStopPercent &&
				Me.Pet.HealthPercent < Settings.HealPetPercent &&
				Me.HealthPercent > Settings.DontHealPetBelow &&
				!Me.Pet.GetBuffs(true).ContainsKey("Health Funnel") &&
				Me.Combat &&
				PetPresenceTimer.ElapsedMilliseconds > 2000)
			{
				glog("Combat: Health Funnel");
				HealthFunnel();
			}
			// Battleground target check
			BattlegroundTargetCheck();
			// Rest target check variables
			if (!fightTimer.IsRunning || Me.CurrentTarget.Guid != lastGuid)
			{
				fightTimer.Reset();
				fightTimer.Start();
				lastGuid = Me.CurrentTarget.Guid;
				fearNum = 0;
			}
			// Bugged/evade mob check
			if (fightTimer.ElapsedMilliseconds > 20000 && Me.CurrentTarget.HealthPercent > 95)
			{
				slog("Combat: This target is a bugged mob.  Blacklisting for 1 hour");
				Logic.Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromHours(1.00));
				Me.ClearTarget();
				Lua.DoString("PetFollow()");
				lastGuid = 0;
				return;
			}
			// Auto-attack
			if (Me.Level < 20 && Me.CurrentTarget.Distance < 5 && !Me.IsAutoAttacking && Me.GotTarget && !Me.CurrentTarget.Dead)
			{
				slog("Default: Starting Autoattack");
				Lua.DoString("StartAttack()");
			}
			// Heal
			Healing("Combat");
			
			// Pet Checks
			PetCheck("Combat");
			// If FightAdds is enabled and we have atleast 2 mobs
			if (Settings.FightAdds && !InBattleground && AddList.Count >= 2)
			{
				CombatAdds();
			}
			else
			{			
				// Single spell rotation
				SingleRotation("Combat", Me.CurrentTarget);
			}
			// PVE fear
			if (Settings.UseFearPVE && FearCountPVE == 0 && Me.CurrentTarget.Distance < 20)
			{
				slog("Combat: PVE Fear Casting");
				SpellManager.CastSpell("Fear");
				FearCountPVE = 1;
			}
			
			if (_Debug) slog("Tick: Took {0} ms", Environment.TickCount - tickCount);
		}
		#endregion
		#region Battleground Blacklisting
		public void BattlegroundTargetCheck()
		{
			if (InBattleground)
			{
				if (Me.GotTarget && Me.CurrentTarget.IsPet)
				{
					slog("Battleground: Blacklist Pet {0}", Me.CurrentTarget.Name);
					Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromDays(1));
					Me.ClearTarget();
					lastGuid = 0;
					return;
				}
				// test, if in battleground and someone is out of line of sight, blacklist for 5 seconds
				if (Me.GotTarget && !Me.CurrentTarget.InLineOfSight)
				{
					slog("Battleground: Target out of Line of Sight, blacklisting for 3 seconds");
					Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromSeconds(3));
					Me.ClearTarget();
					Lua.DoString("PetFollow()");
					lastGuid = 0;
				}
				// && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Fear") && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Death Coil")
				if (Me.GotTarget && Me.CurrentTarget.Distance > 35)
				{
					slog("Battleground: Target out of Range ({0} yards), blacklisting for 3 seconds", Math.Round(Me.CurrentTarget.Distance));
					Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromSeconds(3));
					Me.ClearTarget();
					Lua.DoString("PetFollow()");
					lastGuid = 0;
				}
				else if (Me.GotTarget && Me.CurrentTarget.Distance > 29)
				{
					MoveWithinRangeToMob("PVP Target", Me.CurrentTarget);
				}
				// if target has bubble up, blacklist for duration
				if (Me.GotTarget && Me.CurrentTarget.GetBuffs(true).ContainsKey("Divine Shield"))
				{
					slog("Battleground: Target has Divine Shield, blacklisting for 10 seconds");
					Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromSeconds(10));
					Me.ClearTarget();
					Lua.DoString("PetFollow()");
					lastGuid = 0;
				}
				// if target has iceblock up, blacklist for duration
				if (Me.GotTarget && Me.CurrentTarget.GetBuffs(true).ContainsKey("Ice Block"))
				{
					slog("Battleground: Target has Ice Block, blacklisting for 10 seconds");
					Blacklist.Add(Me.CurrentTarget.Guid, TimeSpan.FromSeconds(10));
					Me.ClearTarget();
					Lua.DoString("PetFollow()");
					lastGuid = 0;
				}
			}
		}
		#endregion
		#region Healing
		public void Healing(string logPrefix)
		{
			// Health Funnel
			if (SpellManager.CanCastSpell("Health Funnel") &&
				Me.GotAlivePet &&
				Me.Pet.HealthPercent < Settings.HealPetStopPercent &&
				Me.Pet.HealthPercent < Settings.HealPetPercent &&
				Me.HealthPercent > Settings.DontHealPetBelow &&
				!Me.Pet.GetBuffs(true).ContainsKey("Health Funnel") &&
				Me.Combat &&
				PetPresenceTimer.ElapsedMilliseconds > 2000)
			{
				glog(logPrefix + ": Healing: Health Funnel");
				HealthFunnel();
			}
		
			// Healthstone Use
			if (Settings.UseHealthstone && Me.HealthPercent < Settings.HealthStoneUsePercent && myHealthstone != null)
			{
				glog(logPrefix + ": Healing: Use Healthstone");
				Lua.DoString("UseItemByName(\"" + myHealthstone.Name + "\")");
			}
			
			// Health Potion Use
			if (Me.HealthPercent < Settings.HealthPotionUsePercent)
			{
				glog(logPrefix + ": Healing: Use Health Potion if I have one");
				Logic.Combat.Healing.UseHealthPotion();
			}
			
			// Mana Potion Use
			if (Me.ManaPercent < Settings.ManaPotionUsePercent)
			{
				blog(logPrefix + ": Healing: Use Mana Potion");
				Logic.Combat.Healing.UseManaPotion();
			}
		}
		#endregion
		#region Affliction Spell Decision
		public string afflictionDecideSpell(string logPrefix)
		{
			// Drain Soul
			if (combatChecks && (SoulShardCount < Settings.MaxShards || Settings.UseDrainSoulAsFinisher) && Me.CurrentTarget.HealthPercent < Settings.DrainSoulMaxHealthPercent && SpellManager.CanCastSpell("Drain Soul"))
			{
				drlog(logPrefix + ": Affliction: Drain Soul");
				return "Drain Soul";
			}
			
			// Death Coil
			if (Me.HealthPercent < Settings.DeathCoilHealthPercent && SpellManager.CanCastSpell("Death Coil"))
			{
				glog(logPrefix + ": Affliction: Death Coil");
				return "Death Coil";
			}
			
			// PVP Cast Fear
			if (combatChecks && Me.CurrentTarget.IsPlayer && Settings.UseFearPVP && SpellManager.CanCastSpell("Fear") && fearNum < Settings.FearCount && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Fear") && Me.CurrentTarget.Distance < 20)
			{
				drlog(logPrefix + ": Affliction: PVP Cast Fear");
				fearNum = fearNum + 1;
				return "Fear";
			}
			
			// Dark Pact
			if (Me.ManaPercent < Settings.DarkPactMinMana && Settings.UseDarkPact && Me.GotAlivePet && SpellManager.CanCastSpell("Dark Pact") && Me.GotAlivePet && Me.Pet.ManaPercent > 5)
			{
				blog(logPrefix + ": Affliction: Dark Pact");
				return "Dark Pact";
			}
			
			// Lifetap
			if (!Settings.UseDarkPact && Me.HealthPercent > Settings.LifeTapMinHealth && Me.ManaPercent < Settings.LifeTapMaxMana && SpellManager.CanCastSpell("Life Tap"))
			{
				blog(logPrefix + ": Affliction: Lifetap");
				return "Life Tap";
			}
						
			// Shadow Trance
			if (Me.GetBuffs(true).ContainsKey("Shadow Trance") && Me.CurrentTarget.HealthPercent > Settings.DirectDmgMinHealth)
			{
				drlog(logPrefix + ": Affliction: Shadow Trance, casting Shadow Bolt");
				return "Shadow Bolt";
			}
			
			// Curse of the Elements
			if (Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Curse of the Elements") && Settings.UseCoE && SpellManager.CanCastSpell("Curse of the Elements"))
			{
				drlog(logPrefix + ": Affliction: Curse of the Elements");
				return "Curse of the Elements";
			}
			
			// Haunt
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && Settings.UseHaunt && SpellManager.CanCastSpell("Haunt"))
			{
				drlog(logPrefix + ": Affliction: Haunt");
				return "Haunt";
			}
			
			// Corruption
			if (SpellManager.CanCastSpell("Corruption") && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Corruption") && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Seed of Corruption") && Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && Settings.UseCorruption)
			{
				drlog(logPrefix + ": Affliction: Corruption");
				return "Corruption";
			}
			
			// Curse of Agony
			if (!Me.CurrentTarget.GetBuffs(true).ContainsKey("Curse of Agony") && Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && SpellManager.CanCastSpell("Curse of Agony") && Settings.UseCoA)
			{
				drlog(logPrefix + ": Affliction: Curse of Agony");
				return "Curse of Agony";
			}
			
			// Immolate
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Immolate") && Settings.UseImmolate && SpellManager.CanCastSpell("Immolate"))
			{
				drlog(logPrefix + ": Affliction: Immolate");
				return "Immolate";
			}
			
			// Unstable Affliction
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Unstable Affliction") && Settings.UseUA && SpellManager.CanCastSpell("Unstable Affliction"))
			{
				drlog(logPrefix + ": Affliction: Unstable Affliction");
				return "Unstable Affliction";
			}
			
			// Drain Life
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DrainLifeMinTargetHealth && Me.HealthPercent < Settings.DrainLifePercent && SpellManager.CanCastSpell("Drain Life") && Me.CurrentTarget.CreatureType != WoWCreatureType.Mechanical)
			{
				drlog(logPrefix + ": Affliction: Drain Life");
				return "Drain Life";
			}
			// Shadow Bolt
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DirectDmgMinHealth && Settings.UseShadowbolt && SpellManager.CanCastSpell("Shadow Bolt"))
			{
				drlog(logPrefix + ": Affliction: Shadow Bolt");
				return "Shadow Bolt";
			}
			// Searing Pain
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DirectDmgMinHealth && Settings.UseSearingPain && SpellManager.CanCastSpell("Searing Pain"))
			{
				drlog(logPrefix + ": Affliction: Searing Pain");
				return "Searing Pain";
			}
			// Wanding
			if (combatChecks && Me.HealthPercent < Settings.WandHealth && Me.ManaPercent < Settings.WandMana && SpellManager.CanCastSpell("Shoot") && !Me.IsAutoAttacking && Me.HealthPercent > 1 && Me.ManaPercent > 1)
			{
				drlog(logPrefix + ": Affliction: Wanding");
				return "Shoot";
			}
			return "";
		}
		#endregion
		#region Destruction Spell Decision
		public string destructionDecideSpell(string logPrefix)
		{
			// Drain Soul
			if (combatChecks && (SoulShardCount < Settings.MaxShards || Settings.UseDrainSoulAsFinisher) && Me.CurrentTarget.HealthPercent < Settings.DrainSoulMaxHealthPercent && SpellManager.CanCastSpell("Drain Soul"))
			{
				drlog(logPrefix + ": Destruction: Drain Soul");
				return "Drain Soul";
			}
					
			// Death Coil
			if (Me.HealthPercent < Settings.DeathCoilHealthPercent && SpellManager.CanCastSpell("Death Coil"))
			{
				glog(logPrefix + ": Destruction: Death Coil");
				return "Death Coil";
			}
			
			// PVP Cast Fear
			if (combatChecks && Me.CurrentTarget.IsPlayer && Settings.UseFearPVP && SpellManager.CanCastSpell("Fear") && fearNum < Settings.FearCount && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Fear") && Me.CurrentTarget.Distance < 20)
			{
				drlog(logPrefix + ": Destruction: PVP Cast Fear");
				fearNum = fearNum + 1;
				return "Fear";
			}
			// Dark Pact
			if (Me.ManaPercent < Settings.DarkPactMinMana && Settings.UseDarkPact && Me.GotAlivePet && SpellManager.CanCastSpell("Dark Pact") && Me.GotAlivePet && Me.Pet.ManaPercent > 5)
			{
				blog(logPrefix + ": Destruction: Dark Pact");
				return "Dark Pact";
			}
			// Lifetap
			if (!Settings.UseDarkPact && Me.HealthPercent > Settings.LifeTapMinHealth && Me.ManaPercent < Settings.LifeTapMaxMana && SpellManager.CanCastSpell("Life Tap"))
			{
				blog(logPrefix + ": Destruction: Lifetap");
				return "Life Tap";
			}
			// Backlash -> Incinerate
			if (combatChecks && Me.Buffs.ContainsKey("Backlash") && SpellManager.CanCastSpell("Incinerate"))
			{
				drlog(logPrefix + ": Destruction: Backlash, casting Incinerate");
				return "Incinerate";
			}
			// Backlash -> Shadow Bolt
			if (combatChecks && Me.Buffs.ContainsKey("Backlash") && SpellManager.CanCastSpell("Shadow Bolt") && !SpellManager.KnownSpells.ContainsKey("Incinerate"))
			{
				drlog(logPrefix + ": Destruction: Backlash, casting Shadow Bolt");
				return "Shadow Bolt";
			}
			// Shadowburn
			if (Me.CurrentTarget.HealthPercent < Settings.ShadowburnHealth && SpellManager.CanCastSpell("Shadowburn") && Settings.UseShadowburn && SoulShardCount >= Settings.MaxShards)
			{
				drlog(logPrefix + ": Destruction: Shadowburn");
				return "Shadowburn";
			}
			// Curse of the Elements
			if (Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Curse of the Elements") && Settings.UseCoE && SpellManager.CanCastSpell("Curse of the Elements"))
			{
				drlog(logPrefix + ": Destruction: Curse of the Elements");
				return "Curse of the Elements";
			}
			// Corruption
			if (SpellManager.CanCastSpell("Corruption") && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Corruption") && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Seed of Corruption") && Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && Settings.UseCorruption)
			{
				drlog(logPrefix + ": Destruction: Corruption");
				return "Corruption";
			}
			// Curse of Agony
			if (Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Curse of Agony") && Settings.UseCoA && SpellManager.CanCastSpell("Curse of Agony"))
			{
				drlog(logPrefix + ": Destruction: Curse of Agony");
				return "Curse of Agony";
			}
			// Immolate
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Immolate") && Settings.UseImmolate && SpellManager.CanCastSpell("Immolate"))
			{
				drlog(logPrefix + ": Destruction: Immolate");
				return "Immolate";
			}
			// Conflagrate
			if (Me.CurrentTarget.GetBuffs(true).ContainsKey("Immolate") && Me.CurrentTarget.HealthPercent > Settings.DirectDmgMinHealth && SpellManager.CanCastSpell("Conflagrate") && Settings.UseConflagrate)
			{
				drlog(logPrefix + ": Destruction: Conflagrate");
				return "Conflagrate";
			}
			// Drain Life
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DrainLifeMinTargetHealth && Me.HealthPercent < Settings.DrainLifePercent && SpellManager.CanCastSpell("Drain Life") && Me.CurrentTarget.CreatureType != WoWCreatureType.Mechanical)
			{
				drlog(logPrefix + ": Destruction: Drain Life");
				return "Drain Life";
			}
			// Chaos Bolt
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DirectDmgMinHealth && SpellManager.CanCastSpell("Chaos Bolt") && Settings.UseChaosBolt)
			{
				drlog(logPrefix + ": Destruction: Chaos Bolt");
				return "Chaos Bolt";
			}
			// Incinerate
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DirectDmgMinHealth && SpellManager.CanCastSpell("Incinerate") && Settings.UseIncinerate)
			{
				drlog(logPrefix + ": Destruction: Incinerate");
				return "Incinerate";
			}
			// Shadow Bolt
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DirectDmgMinHealth && Settings.UseShadowbolt && SpellManager.CanCastSpell("Shadow Bolt") && !SpellManager.KnownSpells.ContainsKey("Incinerate"))
			{
				drlog(logPrefix + ": Destruction: Shadow Bolt");
				return "Shadow Bolt";
			}
			// Searing Pain
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DirectDmgMinHealth && Settings.UseSearingPain && SpellManager.CanCastSpell("Searing Pain"))
			{
				drlog(logPrefix + ": Destruction: Searing Pain");
				return "Searing Pain";
			}
			// Wanding
			if (Me.HealthPercent < Settings.WandHealth && Me.ManaPercent < Settings.WandMana && SpellManager.CanCastSpell("Shoot") && !Me.IsAutoAttacking && Me.HealthPercent > 1 && Me.ManaPercent > 1)
			{
				drlog(logPrefix + ": Destruction: Wanding");
				return "Shoot";
			}
			return "";
		}
		#endregion
		#region Demonology Spell Decision
		public string demonologyDecideSpell(string logPrefix)
		{
			// Drain Soul
			if (combatChecks && (SoulShardCount < Settings.MaxShards || Settings.UseDrainSoulAsFinisher) && Me.CurrentTarget.HealthPercent < Settings.DrainSoulMaxHealthPercent && SpellManager.CanCastSpell("Drain Soul"))
			{
				drlog(logPrefix + ": Demonology: Drain Soul");
				return "Drain Soul";
			}
			// Metamorphosis
			if (Me.GetBuffs(true).ContainsKey("Metamorphosis") && !Me.GetBuffs(true).ContainsKey("Immolation Aura") && SpellManager.CanCastSpell("Immolation Aura"))
			{
				drlog(logPrefix + ": Demonology: Moving and Casting Immolation Aura");
				
				if (Me.CurrentTarget.Distance > 25)
				{
					MoveToUnit(Me.CurrentTarget, 23f);
					while (Me.CurrentTarget.Distance > 25)
					{
						Thread.Sleep(200);
					}
				}
				
				if (Me.CurrentTarget.Distance > 8 && Me.CurrentTarget.Distance < 25)
				{
					if (SpellManager.CanCastSpell("Demon Charge"))
					{
						return "Demon Charge";
					}
					else
					{
						MoveToUnit(Me.CurrentTarget, 4f);
					}
				}
				if (Me.CurrentTarget.Distance <= 4.5)
				{
					return "Immolation Aura";
				}
			}
			// Death Coil
			if (Me.HealthPercent < Settings.DeathCoilHealthPercent && SpellManager.CanCastSpell("Death Coil"))
			{
				glog(logPrefix + ": Demonology: Death Coil");
				return "Death Coil";
			}
			// PVP Cast Fear
			if (combatChecks && Me.CurrentTarget.IsPlayer && Settings.UseFearPVP && SpellManager.CanCastSpell("Fear") && fearNum < Settings.FearCount && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Fear") && Me.CurrentTarget.Distance < 20)
			{
				drlog(logPrefix + ": Demonology: PVP Cast Fear");
				fearNum = fearNum + 1;
				return "Fear";
			}
			// Shadow Trance -> Shadow Bolt
			if (Me.GetBuffs(true).ContainsKey("Shadow Trance") && Me.CurrentTarget.HealthPercent > Settings.DirectDmgMinHealth)
			{
				drlog(logPrefix + ": Demonology: Shadow Trance, casting Shadow Bolt");
				return "Shadow Bolt";
			}
			// Dark Pact
			if (Me.ManaPercent < Settings.DarkPactMinMana && Settings.UseDarkPact && Me.GotAlivePet && SpellManager.CanCastSpell("Dark Pact") && Me.GotAlivePet && Me.Pet.ManaPercent > 5)
			{
				blog(logPrefix + ": Demonology: Dark Pact");
				return "Dark Pact";
			}
			// Lifetap
			if (!Settings.UseDarkPact && Me.HealthPercent > Settings.LifeTapMinHealth && Me.ManaPercent < Settings.LifeTapMaxMana && SpellManager.CanCastSpell("Life Tap"))
			{
				blog(logPrefix + ": Demonology: Lifetap");
				return "Life Tap";
			}
			// Demonic Empowerment
			if (Settings.UseDemonicEmpowerment && SpellManager.CanCastSpell("Demonic Empowerment") && Me.GotAlivePet)
			{
				drlog(logPrefix + ": Demonology: Demonic Empowerment");
				return "Demonic Empowerment";
			}
			// Metamorphosis
			if (Settings.UseMetamorphosis && SpellManager.CanCastSpell("Metamorphosis") && AddList.Count >= Settings.MetamorphosisMinAdds)
			{
				drlog(logPrefix + ": Demonology: Metamorphosis");
				return "Metamorphosis";
			}
			// Molten Core -> Incinerate
			// Must check for Active Buff as learning the talent applies a Passive buff to your character which is also called "Molten Core"
			if (combatChecks && Me.ActiveAuras.ContainsKey("Molten Core") && SpellManager.CanCastSpell("Incinerate"))
			{
				drlog(logPrefix + ": Demonology: Molten Core, casting Incinerate");
				return "Incinerate";
			}
			// Curse of the Elements
			if (Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Curse of the Elements") && Settings.UseCoE && SpellManager.CanCastSpell("Curse of the Elements"))
			{
				drlog(logPrefix + ": Demonology: Curse of the Elements");
				return "Curse of the Elements";
			}
			// Curse of Agony
			if (Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Curse of Agony") && Settings.UseCoA && SpellManager.CanCastSpell("Curse of Agony"))
			{
				drlog(logPrefix + ": Demonology: Curse of Agony");
				return "Curse of Agony";
			}
			// Corruption
			if (SpellManager.CanCastSpell("Corruption") && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Corruption") && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Seed of Corruption") && Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && Settings.UseCorruption)
			{
				drlog(logPrefix + ": Demonology: Corruption");
				return "Corruption";
			}
			// Immolate
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Immolate") && Settings.UseImmolate && SpellManager.CanCastSpell("Immolate"))
			{
				drlog(logPrefix + ": Demonology: Immolate");
				return "Immolate";
			}
			// Drain Life
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DrainLifeMinTargetHealth && Me.HealthPercent < Settings.DrainLifePercent && SpellManager.CanCastSpell("Drain Life") && Me.CurrentTarget.CreatureType != WoWCreatureType.Mechanical)
			{
				drlog(logPrefix + ": Demonology: Drain Life");
				return "Drain Life";
			}
			// Shadow Bolt
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DirectDmgMinHealth && Settings.UseShadowbolt && SpellManager.CanCastSpell("Shadow Bolt"))
			{
				drlog(logPrefix + ": Demonology: Shadow Bolt");
				return "Shadow Bolt";
			}
			// Searing Pain
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DirectDmgMinHealth && Settings.UseSearingPain && SpellManager.CanCastSpell("Searing Pain"))
			{
				drlog(logPrefix + ": Demonology: Searing Pain");
				return "Searing Pain";
			}
			// Wanding
			if (Me.HealthPercent < Settings.WandHealth && Me.ManaPercent < Settings.WandMana && SpellManager.CanCastSpell("Shoot") && !Me.IsAutoAttacking && Me.HealthPercent > 1 && Me.ManaPercent > 1)
			{
				drlog(logPrefix + ": Demonology: Wanding");
				return "Shoot";
			}
			return "";
		}
		#endregion
		#region No Spec Spell Decision
		public string defaultDecideSpell(string logPrefix)
		{
			// Drain Soul
			if (combatChecks && (SoulShardCount < Settings.MaxShards || Settings.UseDrainSoulAsFinisher) && Me.CurrentTarget.HealthPercent < Settings.DrainSoulMaxHealthPercent && SpellManager.CanCastSpell("Drain Soul"))
			{
				drlog(logPrefix + ": Default: Drain Soul");
				return "Drain Soul";
			}
			
			// Lifetap
			if (!Settings.UseDarkPact && Me.HealthPercent > Settings.LifeTapMinHealth && Me.ManaPercent < Settings.LifeTapMaxMana && SpellManager.CanCastSpell("Life Tap"))
			{
				blog(logPrefix + ": Default: Lifetap");
				return "Life Tap";
			}
			// Drain Life
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DrainLifeMinTargetHealth && Me.HealthPercent < Settings.DrainLifePercent && SpellManager.CanCastSpell("Drain Life") && Me.CurrentTarget.CreatureType != WoWCreatureType.Mechanical)
			{
				drlog(logPrefix + ": Default: Drain Life");
				return "Drain Life";
			}
			// Corruption
			if (SpellManager.CanCastSpell("Corruption") && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Corruption") && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Seed of Corruption") && Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && Settings.UseCorruption)
			{
				drlog(logPrefix + ": Default: Corruption");
				return "Corruption";
			}
			// Curse of Agony
			if (Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Curse of Agony") && Settings.UseCoA && SpellManager.CanCastSpell("Curse of Agony"))
			{
				drlog(logPrefix + ": Default: Curse of Agony");
				return "Curse of Agony";
			}
			// Immolate
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Immolate") && Settings.UseImmolate && SpellManager.CanCastSpell("Immolate"))
			{
				drlog(logPrefix + ": Default: Immolate");
				return "Immolate";
			}
			// Shadow Bolt
			if (combatChecks && Me.CurrentTarget.HealthPercent > Settings.DirectDmgMinHealth && Settings.UseShadowbolt && SpellManager.CanCastSpell("Shadow Bolt"))
			{
				drlog(logPrefix + ": Default: Shadow Bolt");
				return "Shadow Bolt";
			}
			// Wanding
			if (Me.HealthPercent < Settings.WandHealth && Me.ManaPercent < Settings.WandMana && SpellManager.CanCastSpell("Shoot") && !Me.IsAutoAttacking && Me.HealthPercent > 1 && Me.ManaPercent > 1)
			{
				drlog(logPrefix + ": Default: Wanding");
				return "Shoot";
			}
			return "";
		}
		#endregion
		#region Spells
		// / <summary>
		// / Protects the caster, increasing armor by 90, and increasing the amount of
		// / health generated through spells and effects by 20%.
		// / Only one type of Armor spell can be active on the Warlock at any time.  Lasts 30 min.
		// / </summary>
		public void DemonSkin()
		{
			SpellManager.CastSpell("Demon Skin");
			WaitWhileCasting();
		}
		// / <summary>
		// / Burns the enemy for 8 Fire damage and then an additional Fire damage over 15 sec.
		// / </summary>
		public void Immolate()
		{
			SpellManager.CastSpell("Immolate");
			WaitWhileCasting();
		}
		// / <summary>
		// / Sends a shadowy bolt at the enemy, causing Shadow damage.
		// / </summary>
		public void ShadowBolt()
		{
			SpellManager.CastSpell("Shadow Bolt");
			WaitWhileCasting();
		}
		// / <summary>
		// / Use Wand
		// / </summary>
		public void Shoot()
		{
			SpellManager.CastSpell("Shoot");
			WaitWhileCasting();
		}
		// / <summary>
		// / Summons an Imp under the command of the Warlock.
		// / </summary>
		public void SummonImp()
		{
			SpellManager.CastSpell("Summon Imp");
			WaitWhileCasting();
		}
		// / <summary>
		// / Corrupts the target, causing 40 Shadow damage over 12 sec.
		// / </summary>
		public void Corruption()
		{
			SpellManager.CastSpell("Corruption");
			WaitWhileCasting();
		}
		// / <summary>
		// / Converts health into [0 + SPI * 1] mana.  Spirit increases quantity of health converted.
		// / </summary>
		public void LifeTap()
		{
			SpellManager.CastSpell("Life Tap");
			WaitWhileCasting();
		}
		// / <summary>
		// / Curses the target with agony, causing Shadow damage over 24 sec.  This damage is dealt
		// / slowly at first, and builds up as the Curse reaches its full duration.
		// / </summary>
		public void CurseOfAgony()
		{
			SpellManager.CastSpell("Curse of Agony");
			WaitWhileCasting();
		}
		// / <summary>
		// / Creates a Healthstone that can be used to instantly restore health.
		// / </summary>
		public void CreateHealthstone()
		{
			SpellManager.CastSpell("Create Healthstone");
			WaitWhileCasting();
		}
		// / <summary>
		// / Drains the soul of the target, causing 55 Shadow damage over 15 sec.  If the target is at or
		// / below 25% health, Drain Soul causes four times the normal damage
		// / If the target dies while being drained, and yields experience or honor,
		// / the caster gains a Soul Shard.  Each time the Drain Soul damages the target,
		// / it also has a chance to generate a Soul Shard.
		// / </summary>
		public void DrainSoul()
		{
			SpellManager.CastSpell("Drain Soul");
			WaitWhileCasting();
		}
		// / <summary>
		// / Summons a Felhunter under the command of the Warlock.
		// / </summary>
		public void SummonPet()
		{
			SpellManager.CastSpell("Summon " + Settings.Pet);
			WaitWhileCasting();
		}
		// / <summary>
		// / Gives health to the caster's pet every second for 10 sec as long as the caster channels.
		// / </summary>
		public void HealthFunnel()
		{
			// TODO: Fix me
			SpellManager.CastSpell("Health Funnel");
			
			Thread.Sleep(200);
			if (Me.GotAlivePet)
			{
				while (Me.GotAlivePet &&
					Me.HealthPercent > Settings.DontHealPetBelow &&
					Me.Pet.HealthPercent < Settings.HealPetPercent &&
					Me.Pet.HealthPercent < Settings.HealPetStopPercent &&
					Me.Pet.GetBuffs(true).ContainsKey("Health Funnel") &&
					PetPresenceTimer.ElapsedMilliseconds > 2000)
				{
					if (!Me.Combat && Me.GotAlivePet) Lua.DoString("PetFollow()");
					
					glog("Funneling!");
					Thread.Sleep(100);
				}
				
				glog("Funneling finished. Pet Health: {0}%", Me.Pet.HealthPercent);
			}
			else
			{
				glog("Health Funnel failed. Pet is dead");
			}
		}
		// / <summary>
		// / Transfers health every 1 sec from the target to the caster.  Lasts 5 sec.
		// / </summary>
		public void DrainLife()
		{
			SpellManager.CastSpell("Drain Life");
			WaitWhileCasting();
		}
		// / <summary>
		// / The Soulstone can be used to store one target's soul.  If the target dies while his soul is stored,
		// / he will be able to resurrect.
		// / </summary>
		public void CreateSoulstone()
		{
			SpellManager.CastSpell("Create Soulstone");
			WaitWhileCasting();
		}
		// / <summary>
		// / Protects the caster, increasing armor, and increasing the amount of health
		// / generated through spells and effects by 20%
		// / </summary>
		public void DemonArmor()
		{
			SpellManager.CastSpell("Demon Armor");
			WaitWhileCasting();
		}
		// / <summary>
		// / Causes the enemy target to run in horror for 3 sec and causes Shadow damage.
		// / The caster gains 300% of the damage caused in health.
		// / </summary>
		public void DeathCoil()
		{
			SpellManager.CastSpell("Death Coil");
			WaitWhileCasting();
		}
		// / <summary>
		// / Demonic Empowerment
		// / </summary>
		public void DemonicEmpowerment()
		{
			SpellManager.CastSpell("Demonic Empowerment");
			WaitWhileCasting();
		}
		// / <summary>
		// / Drains your summoned demon's Mana, returning 100% to you.
		// / </summary>
		public void DarkPact()
		{
			SpellManager.CastSpell("Dark Pact");
		}
		// / <summary>
		// / Curse of the Elements
		// / </summary>
		public void CurseOfTheElements()
		{
			SpellManager.CastSpell("Curse of the Elements");
		}
		// / <summary>
		// / Shadow energy slowly destroys the target, causing damage over 15 sec.
		// / In addition, if the Unstable Affliction is dispelled it will cause serious damage to the dispeller
		// / and silence them for 5 sec.
		// / </summary>
		public void UnstableAffliction()
		{
			SpellManager.CastSpell("Unstable Affliction");
			WaitWhileCasting();
		}
		// / <summary>
		// / Surrounds the caster with fel energy, increasing spell power plus additional spell
		// / power equal to 30% of your Spirit.
		// / In addition, you regain 2% of your maximum health every 5 sec.
		// / </summary>
		public void FelArmor()
		{
			SpellManager.CastSpell("Fel Armor");
			WaitWhileCasting();
		}
		public void DetectInvisibility()
		{
			Me.ClearTarget();
			SpellManager.CastSpell("Detect Invisibility");
		}
		// / <summary>
		// / When active, 20% of all damage taken by the caster is taken by your Imp, Felhunter,
		// / Succubus, Felhunter, Felguard, or enslaved demon instead.
		// / That damage cannot be prevented. Lasts as long as the demon is active and controlled.
		// / </summary>
		public void SoulLink()
		{
			SpellManager.CastSpell("Soul Link");
			WaitWhileCasting();
		}
		// / <summary>
		// / You send a ghostly soul into the target, dealing Shadow damage and increasing all damage done
		// / by your Shadow damage-over-time effects on the target by 20% for 12 sec.
		// / When the Haunt spell ends or is dispelled, the soul returns to you, healing you for 100% of the
		// / damage it did to the target.
		// / </summary>
		public void Haunt()
		{
			SpellManager.CastSpell("Haunt");
			WaitWhileCasting();
		}
		// / <summary>
		// / Strikes fear in the enemy, causing it to run in fear for up to 20 sec.  Damage caused may interrupt the effect.  Only 1 target can be feared at a time.
		// / </summary>
		public void Fear()
		{
			SpellManager.CastSpell("Fear");
			WaitWhileCasting();
		}
		// / <summary>
		// / Use: While applied to target weapon it increases damage dealt by periodic spells by 1% and spell haste rating by 40.  Lasts for 1 hour.
		// / </summary>
		public void CreateSpellstone()
		{
			SpellManager.CastSpell("Create Spellstone");
			WaitWhileCasting();
		}
		// / <summary>
		// / Use: While applied to target weapon it increases damage dealt by direct spells by 1% and spell crit rating by 160.  Lasts for 1 hour.
		// / </summary>
		public void CreateFirestone()
		{
			SpellManager.CastSpell("Create Firestone");
			WaitWhileCasting();
		}
		// / <summary>
		// / Allows the target to breathe underwater for 30 minutes and increases swim speed by 20%
		// / </summary>
		public void UnendingBreath()
		{
			SpellManager.CastSpell("Unending Breath");
		}
		public void Sacrifice()
		{
			SpellManager.CastSpell("Sacrifice");
		}
		public void Shadowburn()
		{
			SpellManager.CastSpell("Shadowburn");
			WaitWhileCasting();
		}
		public void SearingPain()
		{
			SpellManager.CastSpell("Searing Pain");
			WaitWhileCasting();
		}
		public void Conflagrate()
		{
			SpellManager.CastSpell("Conflagrate");
			WaitWhileCasting();
		}
		public void Shadowfury()
		{
			SpellManager.CastSpell("Shadowfury");
			WaitWhileCasting();
		}
		public void ChaosBolt()
		{
			SpellManager.CastSpell("Chaos Bolt");
			WaitWhileCasting();
		}
		private void Incinerate()
		{
			SpellManager.CastSpell("Incinerate");
			WaitWhileCasting();
		}
		private void SeedOfCorruption()
		{
			SpellManager.CastSpell("Seed of Corruption");
			WaitWhileCasting();
		}
		private void FelDomination()
		{
			SpellManager.CastSpell("Fel Domination");
			WaitWhileCasting();
		}	
		#endregion
		#region Private Functions
		private void UpdateAddList()
		{
			// Variables
			List<WoWUnit> possibleTargets;
			
			// Find valid Adds attacking us
			if (InBattleground)
			{
				possibleTargets = (	from 	o in ObjectManager.ObjectList
							where 	o is WoWUnit &&
								o != StyxWoW.Me &&
								o.Distance <= (Targeting.PullDistance * 2)
							let 	u = o.ToUnit()
							where 	!u.Dead &&
								!Blacklist.Contains(u.Guid) &&
								!u.IsFriendly &&
								u.CreatureType != WoWCreatureType.Critter &&
								u.Attackable &&
								!u.IsPet && 
								!u.IsTotem
							orderby (u.CurrentTargetGuid == Me.Guid) descending, o.Distance ascending
							select 	u
						).ToList();
			}
			else
			{
				possibleTargets = (	from 	o in ObjectManager.ObjectList
							where 	o is WoWUnit &&
								o != StyxWoW.Me &&
								o.Distance <= (Targeting.PullDistance * 4)
							let 	u = o.ToUnit()
							where 	!u.Dead &&
								//!Blacklist.Contains(u.Guid) &&
								!u.IsFriendly &&
								u.CreatureType != WoWCreatureType.Critter &&
								!u.OnTaxi &&
								u.Attackable &&
								(u.IsTargetingMe || u.IsTargetingPet || Me.PartyMemberGuids.Contains(u.CurrentTargetGuid))
							orderby (u.CurrentTargetGuid == Me.Guid) descending, (Me.GotAlivePet ? o.Location.Distance(Me.Pet.Location) : 0) ascending, o.Distance ascending
							select 	u
						).ToList();
			}
			
			// Logging
			if (_Debug || _logspamMobCount != possibleTargets.Count)
			{
				olog("Warning: There are " + possibleTargets.Count.ToString() + " attackers");
				_logspamMobCount = possibleTargets.Count;
				
				if (_Debug)
				{
					rlog("UpdateAddList(): " + possibleTargets.Count);
					DisplayWoWUnit(possibleTargets);
				}
			}
			
			//rlog("UpdateAddList(): " + possibleTargets.Count);
			//DisplayWoWUnit(possibleTargets);
			
			// Return
			//return possibleTargets;
			AddList = possibleTargets;
		}
		
		private bool GotAdds { get { return (AddList.Count > 0 ? true : false); } }
		//private List<WoWUnit> UpdateMobList()
		private void UpdateMobList()
		{
			// Variables
			List<WoWUnit> possibleTargets;
			
			// Find valid Mobs not attacking us
			if (InBattleground)
			{
				possibleTargets = (	from 	o in ObjectManager.ObjectList
							where 	o is WoWUnit &&
								o != StyxWoW.Me &&
								o.Distance <= (Targeting.PullDistance * 2)
							let 	u = o.ToUnit()
							where 	!u.Dead &&
								!Blacklist.Contains(u.Guid) &&
								!u.IsFriendly &&
								u.CreatureType != WoWCreatureType.Critter &&
								u.Attackable
							orderby (u.CurrentTargetGuid == Me.Guid) descending, o.Distance ascending
							select 	u
						).ToList();
			}
			else
			{
				possibleTargets = (	from 	o in ObjectManager.ObjectList
							where 	o is WoWUnit &&
								o != StyxWoW.Me &&
								o.Distance <= (Targeting.PullDistance * 1.5) &&
								o.Location.Distance(StyxWoW.AreaManager.CurrentGrindArea.CurrentHotSpot.Position) <= 200
							let 	u = o.ToUnit()
							where 	!u.Dead &&
								ProfileManager.CurrentProfile.Factions.Contains(u.FactionId) &&
								!ProfileManager.CurrentProfile.AvoidMobs.Contains(u.Entry) &&
								!Blacklist.Contains(u.Guid) &&
								!u.PvpFlagged &&
								!u.IsFriendly &&
								u.CreatureType != WoWCreatureType.Critter &&
								!u.Tagged &&
								u.Level >= MinLevel &&
								u.Level <= MaxLevel &&
								!u.OnTaxi &&
								u.Attackable
							orderby (Me.GotAlivePet ? o.Location.Distance(Me.Pet.Location) : 0) ascending, o.Distance ascending
							select 	u
						).ToList();
			}
			
			// Logging
			if (_Debug && possibleTargets.Count > 0)
			{
				rlog("UpdateMobList(): " + possibleTargets.Count);
				DisplayWoWUnit(possibleTargets);
			}
			
			//rlog("TargetList:");
			//DisplayWoWUnit(Targeting.TargetList);
			
			//OrderKillList(possibleTargets);
			
			// Return
			//return possibleTargets;
			MobList = possibleTargets;
		}
		private int SortByDistance(WoWUnit x, WoWUnit y)
		{
			//rlog("x.Distance: " + x.Distance + ", y.Distance: " + y.Distance);
			
			int retval = x.Distance.CompareTo(y.Distance);
			return retval;
		}
		private int SortByPetDistance(WoWUnit x, WoWUnit y)
		{
			//rlog("Me.Pet.Location.Distance(x.Location): " + Me.Pet.Location.Distance(x.Location) + ", Me.Pet.Location.Distance(y.Location): " + Me.Pet.Location.Distance(y.Location));
			
			int retval = Me.Pet.Location.Distance(x.Location).CompareTo(Me.Pet.Location.Distance(y.Location));
			return retval;
		}
		
		private void DisplayWoWUnit(List<WoWUnit> list)
		{
			foreach( WoWUnit s in list )
			{
				//rlog("Name: " + s.Name + ", Distance: " + s.Distance + ", CalculateNeededFacing: " + Styx.Helpers.WoWMathHelper.CalculateNeededFacing(Me.ToUnit(), s.ToUnit());
				//rlog("Name: " + s.Name + ", Distance: " + s.Distance + ", IsFacing: " + Me.IsFacing(s.Location) + ", IsBehind: " + Styx.Helpers.WoWMathHelper.IsBehind(Me.Location, s.Location, Styx.Helpers.WoWMathHelper.DegreesToRadians(90)));
				//rlog("Name: " + s.Name + ", Distance: " + Math.Round(s.Distance, 2) + ", DistanceFromPet: " + Math.Round(Me.Pet.Location.Distance(s.Location), 2));
				if (s.CurrentTargetGuid == Me.Guid) rlog("Name: " + s.Name + ", Distance: " + Math.Round(s.Distance, 2) + ", DistanceFromPet: " + Math.Round(Me.Pet.Location.Distance(s.Location), 2));
			}
		}
		public override bool NeedPreCombatBuffs
		{
			get
			{
				return false;
			}
		}
		public override void PreCombatBuff()
		{
		}
		public override bool NeedCombatBuffs
		{
			get
			{
				return false;
			}
		}
		public override void CombatBuff()
		{
		}
		public override bool NeedHeal
		{
			get
			{
				return false;
			}
		}
		public override void Heal()
		{
		}
		public override bool NeedPullBuffs
		{
			get
			{
				return false;
			}
		}
		public override void PullBuff()
		{
		}
		private WoWItem HaveItemCheck(List<uint> listId)
		{
			foreach (WoWItem item in Me.BagItems)
			{
				if (listId.Contains(item.Entry))
				{
					return item;
				}
			}
			return null;
		}
		public class CC_TalentGroup
		{
			private volatile LocalPlayer Me = ObjectManager.Me;
			public string[] _tabName = new string[4];
			public int[] _tabPoints = new int[4];
			public int _idxGroup;
			public int totalPoints
			{
				get
				{
					int nPoints = 0;
					for (int iTab = 1; iTab <= 3; iTab++)
					{
						nPoints += _tabPoints[iTab];
					}
					return nPoints;
				}
			}
			public int Spec()
			{
				int nSpec = 0;
				if (_tabPoints[1] >= (_tabPoints[2] + _tabPoints[3]))
					nSpec = 1;
				else if (_tabPoints[2] >= (_tabPoints[1] + _tabPoints[3]))
					nSpec = 2;
				else if (_tabPoints[3] >= (_tabPoints[1] + _tabPoints[2]))
					nSpec = 3;
				return nSpec;
			}
			public CC_TalentGroup()
			{
			}
			~CC_TalentGroup()
			{
			}
			public bool Load(int nGroup)
			{
				int nTab;
				_idxGroup = nGroup;
				for (nTab = 1; nTab <= 3; nTab++)
				{
					Lua.DoString("readTabName, __, readTabPointsSpent, __, __ = GetTalentTabInfo(" + nTab + ",false,false," + _idxGroup + ")");
					_tabName[nTab] = Lua.GetLocalizedText("readTabName", Me.BaseAddress);
					_tabPoints[nTab] = Lua.GetLocalizedInt32("readTabPointsSpent", Me.BaseAddress);
				}
				return false;
			}
			public bool IsActiveGroup()
			{
				return GetActiveGroup() == _idxGroup;
			}
			public int GetActiveGroup()
			{
				Lua.DoString("activeTalentGroup = GetActiveTalentGroup(false,false)");
				int nActiveGroup = Lua.GetLocalizedInt32("activeTalentGroup", Me.BaseAddress);
				return nActiveGroup;
			}
			public void ActivateGroup()
			{
				Lua.DoString("SetActiveTalentGroup(" + _idxGroup + ")");
			}
			public int GetNumGroups()
			{
				Lua.DoString("numTalentGroups = GetNumTalentGroups(false,false)");
				int cntGroup = Lua.GetLocalizedInt32("numTalentGroups", Me.BaseAddress);
				return cntGroup;
			}
		}
		private static Stopwatch shardTimer = new Stopwatch();
		private void DeleteShard()
		{
			if (shardTimer.IsRunning && shardTimer.ElapsedMilliseconds < 1000)
			{
				return;
			}
			if (SoulShardCount > Settings.MaxShards)
			{
				shardTimer.Reset();
				shardTimer.Start();
				
				string shardDelete = "d=1 for x=0,4 do for y=1,GetContainerNumSlots(x) do  if (d>0) then l=GetContainerItemID(x,y) if l and l==6265 then PickupContainerItem(x,y) DeleteCursorItem() d=d-1 end end end end";
				Lua.DoString(shardDelete);
			}
		}
		public void slog(string msg, params object[] args)
		{
			if (msg != _logspam)
			{
				Logging.Write(Color.FromName("Purple"), "[skiWarlock] " + msg, args);
				_logspam = msg;
			}
		}
		private void dplog(string msg, params object[] args)
		{
			if (msg != _logspam)
			{
				Logging.Write(Color.FromName("Purple"), "[skiWarlock] " + msg, args);
				_logspam = msg;
			}
		}
		
		private void drlog(string msg, params object[] args)
		{
			if (msg != _logspam)
			{
				Logging.Write(Color.FromName("DarkRed"), "[skiWarlock] " + msg, args);
				_logspam = msg;
			}
		}
		
		private void rlog(string msg, params object[] args)
		{
			if (msg != _logspam)
			{
				Logging.Write(Color.FromName("Red"), "[skiWarlock] " + msg, args);
				_logspam = msg;
			}
		}
		
		private void glog(string msg, params object[] args)
		{
			if (msg != _logspam)
			{
				Logging.Write(Color.FromName("Green"), "[skiWarlock] " + msg, args);
				_logspam = msg;
			}
		}
		
		private void blog(string msg, params object[] args)
		{
			if (msg != _logspam)
			{
				Logging.Write(Color.FromName("Blue"), "[skiWarlock] " + msg, args);
				_logspam = msg;
			}
		}
		
		private void olog(string msg, params object[] args)
		{
			if (msg != _logspam)
			{
				Logging.Write(Color.FromName("DarkOrange"), "[skiWarlock] " + msg, args);
				_logspam = msg;
			}
		}
		
		private void mlog(string msg, params object[] args)
		{
			if (msg != _logspam)
			{
				Logging.Write(Color.FromName("MediumPurple"), "[skiWarlock] " + msg, args);
				_logspam = msg;
			}
		}
		public void HandleFalling()
		{
			rlog("Falling");
		}
		WoWPoint attackPoint
		{
			get
			{
				if (Me.GotTarget)
				{
					if (!movementTimer.IsRunning || movementTimer.ElapsedMilliseconds > 2500)
					{
						movementTimer.Reset();
						movementTimer.Start();
						attackPointBuffer = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 24.0f);
						return attackPointBuffer;
					}
					else
					{
						return attackPointBuffer;
					}
				}
				else
				{
					WoWPoint noSpot = new WoWPoint();
					return noSpot;
				}
			}
		}
		WoWPoint attackPointPVP
		{
			get
			{  
				if (Me.GotTarget)
				{
					if (!movementTimer.IsRunning || movementTimer.ElapsedMilliseconds > 1000)
					{
						movementTimer.Reset();
						movementTimer.Start();
						attackPointBuffer = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 25.0f);
						return attackPointBuffer;
					}
					else
					{
						return attackPointBuffer;
					}
				}
				else
				{
					WoWPoint noSpot = new WoWPoint();
					return noSpot;
				}
			}
		}
		
		WoWPoint petPoint
		{
			get
			{
				if (Me.GotAlivePet)
				{
					if (!movementTimer.IsRunning || movementTimer.ElapsedMilliseconds > 2500)
					{
						movementTimer.Reset();
						movementTimer.Start();
						attackPointBuffer = WoWMovement.CalculatePointFrom(Me.Pet.Location, 12.0f);
						return attackPointBuffer;
					}
					else
					{
						return attackPointBuffer;
					}
				}
				else
				{
					WoWPoint noSpot = new WoWPoint();
					return noSpot;
				}
			}
		}
		WoWPoint targetPoint
		{
			get
			{
				if (Me.GotTarget)
				{
					if (!movementTimer.IsRunning || movementTimer.ElapsedMilliseconds > 2500)
					{
						movementTimer.Reset();
						movementTimer.Start();
						attackPointBuffer = WoWMovement.CalculatePointFrom(Me.CurrentTarget.Location, 7.0f);
						return attackPointBuffer;
					}
					else
					{
						return attackPointBuffer;
					}
				}
				else
				{
					WoWPoint noSpot = new WoWPoint();
					return noSpot;
				}
			}
		}
		WoWPoint attackPointBuffer;
		private static Stopwatch movementTimer = new Stopwatch();
		private bool combatChecks
		{
			get
			{
				double shadowRange = 29;
				if (Me.GotTarget && Me.CurrentTarget.Distance <= shadowRange)
				{
					if (Me.IsMoving) WoWMovement.MoveStop();
					WoWMovement.Face();
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		private uint SoulShardCount
		{
			get
			{
				uint Count = 0;
				foreach (WoWItem Item in Me.BagItems)
				{
					if (Item.Entry == 6265)
					{
						Count++;
					}
				}
				
				if (Count > Settings.MaxShards + 1 || _Debug)
				{
					olog("Soul Shard count: {0}", Count);
				}
				
				return Count;
			}
		}
		private WoWItem myHealthstone
		{
			get
			{
				return HaveItemCheck(_healthstoneEntryId);
			}
		}
		private WoWItem mySpellstone
		{
			get
			{
				return HaveItemCheck(_spellstoneEntryId);
			}
		}
		private WoWItem myFirestone
		{
			get
			{
				return HaveItemCheck(_firestoneEntryId);
			}
		}
		private WoWItem mySoulstone
		{
			get
			{
				return HaveItemCheck(_soulstoneEntryId);
			}
		}
		List<WoWUnit> AddList = new List<WoWUnit>();
		List<WoWUnit> MobList = new List<WoWUnit>();
		private static Stopwatch pullTimer = new Stopwatch();
		private readonly List<uint> _healthstoneEntryId = new List<uint>
		{
			5509, 5510, 5511, 5512, 9421, 19004, 19005, 19006,
			19007, 19008, 19009, 19010, 19011, 19012, 19013,
			22103, 22104, 22105, 36889, 36890, 36891, 36892,
			36893, 36894
		};
		private readonly List<uint> _spellstoneEntryId = new List<uint>
		{
			41191, 41192, 41193, 41194, 41195, 41196
		};
		private readonly List<uint> _firestoneEntryId = new List<uint>
		{
			40773, 41169, 41170, 41171, 41172, 41173, 41174
		};
		private readonly List<uint> _spellstoneEnchantEntryId = new List<uint>
		{
			3615, 3616, 3617, 3618, 3619, 3620
		};
		private readonly List<uint> _firestoneEnchantEntryId = new List<uint>
		{
			3597, 3609, 3610, 3611, 3612, 3613, 3614
		};
		private readonly List<uint> _soulstoneEntryId = new List<uint>
		{
			5232, 16892, 16893, 16895, 16896, 22116, 36895
		};
		public bool IsBuffOnMeLUA(string BuffName)
		{
			Lua.DoString("buffName,_,_,stackCount,_,_,_,_,_=UnitBuff(\"player\",\"" + BuffName + "\")");
			string buffName = Lua.GetLocalizedText("buffName", Me.BaseAddress);
			if (buffName == BuffName)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		public void CombatAdds()
		{
			// Update the Add List
			UpdateAddList();
			
			slog("Combating Adds: {0}", AddList.Count);
			int i = 0;
			foreach (WoWUnit mob in AddList)
			{
				i++;
				if (mob.IsAlive)
				{
					// Healing
					Healing("Adds");
				
					// Target mob
					Target("Add: " + i, mob, true);
					
					// Pet Attack
					PetAttack("Add: " + i, mob, false);
					
					// Stop and Face
					if (Me.IsMoving) WoWMovement.MoveStop();
					WoWMovement.Face();
					
					// If we have Seed of Corruption - this is used at higher levels
					// Disabled in PVP
					if (FightAddsWithAOE && !InBattleground && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Seed of Corruption"))
					{
						// Metamorphosis - untested... tell us if it works!
						if (UseDemonology)
						{
							if (Settings.UseMetamorphosis && SpellManager.CanCastSpell("Metamorphosis"))
							{
								drlog("Add: {0}: Metamorphosis", i);
								SpellManager.CastSpell("Metamorphosis");
							}
							if (Me.GetBuffs(true).ContainsKey("Metamorphosis") && !Me.GetBuffs(true).ContainsKey("Immolation Aura") && SpellManager.CanCastSpell("Immolation Aura"))
							{
								slog("Add: {0}: Moving and Casting Immolation Aura", i);
								if (Me.CurrentTarget.Distance > 25)
								{
									MoveToUnit(Me.CurrentTarget, 23f);
									while (Me.CurrentTarget.Distance > 25)
									{
										Thread.Sleep(200);
									}
								}
								if (Me.CurrentTarget.Distance > 8 && Me.CurrentTarget.Distance < 25)
								{
									if (SpellManager.CanCastSpell("Demon Charge"))
									{
										SpellManager.CastSpell("Demon Charge");
									}
									else
									{
										MoveToUnit(Me.CurrentTarget, 4f);
									}
								}
								if (Me.CurrentTarget.Distance <= 4.5)
								{
									SpellManager.CastSpell("Immolation Aura");
								}
							}
						}
						// Shadowfury
						if (UseDestruction && SpellManager.CanCastSpell("Shadowfury"))
						{
							drlog("Add: {0}: Shadowfury", i);
							Shadowfury();
							SpellManager.ClickRemoteLocation(Me.CurrentTarget.Location);
						}
						// Haunt
						if (UseAffliction && SpellManager.CanCastSpell("Haunt") && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Haunt") && Me.CurrentTarget.HealthPercent > Settings.DotMinTargetHealth)
						{
							drlog("Add: {0}: Haunt", i);
							Haunt();
						}
						// Seed of Corruption
						//if (!UseDefault && SpellManager.CanCastSpell("Seed of Corruption") && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Seed of Corruption"))
						if (SpellManager.CanCastSpell("Seed of Corruption"))
						{
							drlog("Add: {0}: Seed of Corruption", i);
							SeedOfCorruption();
						}
					}
					else
					{
						// If the mob already has Seed of Corruption - or, we dont know Seed of Corruption
						// Use single target rotation - get Corruption, Curse of Agony, Immolate up
						// Try a total of 4 times, this accounts of Life Taps, instants and other spell casts
						int SpellTries = 4;
						int TryCount = 0;
						while ((
								(Settings.UseCorruption && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Corruption")) ||
								(Settings.UseImmolate && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Immolate")) ||
								(Settings.UseCoA && !Me.CurrentTarget.GetBuffs(true).ContainsKey("Curse of Agony"))) &&
								Me.CurrentTarget.IsAlive &&
								//Me.CurrentTarget.GetBuffs(true).ContainsKey("Seed of Corruption") &&
								TryCount++ < SpellTries)
						{
							SingleRotation("Add: " + i, Me.CurrentTarget);
						}
					}
					// Range check - move to optimum range if too far from pet
					if (!InBattleground)
					{
						MoveWithinRangeToPet("Add: " + i);
					}
				}
			}
		}
		public void WaitWhileCasting()
		{
			// HB handles this internally very well now - but, just in case
			// Give time for HB to update buffs/debuffs
			Thread.Sleep(200);
			while (SpellManager.GlobalCooldown || Me.Casting != 0 || Me.ChanneledCasting != 0)
			{
				Thread.Sleep(50);
			}
		}
		public static bool InBattleground { get { return Battlegrounds.IsInsideBattleground; } }
		private bool IsItemOnCooldown(WoWItem item)
		{
			// If not valid WoWItem was passed, return true (on cooldown)
			if (item == null)
			{
				return true;
			}
			// Try to get item cooldown from LUA
			try
			{
				// Use LUA to test item cooldown
				if (LuaGetDecimal("GetItemCooldown(" + item.Entry + ")") == 0)
				{
					// If item is NOT on cooldown, return false
					return false;
				}
			}
			catch (Exception e)
			{
				// Failed LUA call for what ever reason
				rlog("Fail to get GetItemCooldown for: {0}, Error: {1}", item.Name, e.Message);
			}
			// Return true (on cooldown)
			return true;
		}
		
		private void MoveWithinRangeToPet(string logPrefix)
		{
			if (Me.GotAlivePet && Me.Pet.Distance > 15)
			{
				slog(logPrefix + ": Move: " + Math.Round(Me.Pet.Distance) + " yard from Pet");
				
				while (Me.GotAlivePet && Me.Pet.CurrentTarget.IsAlive && Me.Pet.Distance > 15)
				{
					Navigator.MoveTo(petPoint);
					
					Thread.Sleep(200);
					
					Healing("Move");
				}
				
				if (Me.IsMoving) WoWMovement.MoveStop();
			}
		}
		
		private void MoveWithinRangeToMob(string logPrefix, WoWUnit mob)
		{
			if (mob.Distance > 29)
			{
				slog(logPrefix + ": Move: " + Math.Round(mob.Distance).ToString() + " yard from: " + mob.Name);
				
				while (Me.GotTarget && mob.IsAlive && mob.Distance > 29)
				{
					Navigator.MoveTo((InBattleground ? attackPointPVP : attackPoint));
					
					Thread.Sleep(50);
					Healing(logPrefix + ": Move");
				}
				
				if (Me.IsMoving) WoWMovement.MoveStop();
			}
		}
		
		private void MoveIntoLineOfSight(string logPrefix)
		{
			if (!Me.CurrentTarget.InLineOfSight && !Me.CurrentTarget.Attackable)
			{
				slog(logPrefix + ": Move into line of sight: " + Math.Round(Me.CurrentTarget.Distance).ToString() + " yard from: " + Me.CurrentTarget.Name);
				
				while (Me.GotTarget && Me.CurrentTarget.IsAlive && Me.CurrentTarget.Distance > 7 && !Me.CurrentTarget.InLineOfSight)
				{
					Navigator.MoveTo(targetPoint);
					
					Thread.Sleep(200);
					Healing("Move LOS");
				}
				
				if (Me.IsMoving) WoWMovement.MoveStop();
			}
		}
		
		private void PetAttack(string logPrefix, WoWUnit mob, bool WaitForTargetMatch)
		{
			if (Settings.UsePetAttack && Me.GotAlivePet)
			{
				// Log
				slog(logPrefix + ": Pet attack: " + mob.Name);
				
				// Pet attack, set raid icon
				if (Settings.UseRaidIcons)
				{
					Lua.DoString("PetAttack(); if (GetRaidTargetIndex('target') ~= 7) then SetRaidTarget('target', 7); end");
				}
				else
				{
					Lua.DoString("PetAttack()");
				}
				
				// Wait for HB to update
				if (WaitForTargetMatch)
				{
					while (Me.GotAlivePet && mob.IsAlive && Me.Pet.CurrentTargetGuid != mob.Guid && !Me.Dead)
					{
						Thread.Sleep(200);
					}
				}
			}
		}
		
		private void Target(string logPrefix, WoWUnit mob, bool WaitForTargetMatch)
		{
			// Log
			slog(logPrefix + ": Target: " + mob.Name);
						
			// Target
			mob.Target();
			
			// Wait for HB to update
			if (WaitForTargetMatch)
			{
				while (mob.IsAlive && Me.CurrentTargetGuid != mob.Guid && !Me.Dead)
				{
					// Target
					mob.Target();
					
					// Sleep
					Thread.Sleep(100);
				}
			}
		}
		
		private void SingleRotation(string logPrefix, WoWUnit mob)
		{
			// Varibles
			string spell;
			// Update ObjectManager we our decide routines has fresh data
			ObjectManager.Update();
			// Move to mob
			MoveWithinRangeToMob(logPrefix, mob);
			
			// Decide on a spell based on spec and variables set
			if (UseAffliction == true)
			{
				spell = afflictionDecideSpell(logPrefix);
			}
			else if (UseDestruction == true)
			{
				spell = destructionDecideSpell(logPrefix);
			}
			else if (UseDemonology == true)
			{
				spell = demonologyDecideSpell(logPrefix);
			}
			else if (UseDefault == true)
			{
				spell = defaultDecideSpell(logPrefix);
			}
			else
			{
				slog("Please select a spec");
				return;
			}
			
			// If we have a spell, cast it
			if (spell != "")
			{
				// Set raid icon
				if (Settings.UseRaidIcons)
				{
					Lua.DoString("if (GetRaidTargetIndex('target') ~= 8) then SetRaidTarget('target', 8); end");
				}
				
				// Face
				WoWMovement.Face();
				
				// Cast spell
				SpellManager.CastSpell(spell);
				// TODO: Replace with Invoke function
				
				// Wait for spell cast
				WaitWhileCasting();
				// Face stop
				if (InBattleground) WoWMovement.StopFace();
			}
		}
		
		public void MoveToUnit(WoWUnit mob, float distanceFrom)
		{
			WoWPoint newPoint = WoWMovement.CalculatePointFrom(mob.Location, distanceFrom);
			Navigator.MoveTo(newPoint);
		}
		
		public bool inParty
		{
			get
			{
				if (Me.IsInRaid || Me.IsInParty) return true;
				return false;
			}
		}
		
		public bool inCombat
		{
			get
			{
				if (Me.PetInCombat || Me.Combat) return true;
				return false;
			}
		}
		// LUA wrapper funtions - makes LUA easy
		private string LuaPrep(string Code)
		{
			// Regex - used to check if a return is in the code, if not add it in
			Regex ReturnPresent = new Regex("return");
			return (ReturnPresent.IsMatch(Code) ? Code : "return " + Code + "");
		}
		private bool LuaGetBool(string Code)
		{
			string Result = Lua.LuaGetReturnValue(LuaPrep(Code), "Atlas.lua")[0];
			if (Result.Length == 0 || Result == "false" || Result == "False")
			{
				return false;
			}
			else if (Result == "1" || Result == "true" || Result == "True")
			{
				return true;
			}
			else
			{
				rlog("LuaGetBool(): Unknown value: " + Result);
				return true;
			}
		}
		private int LuaGetInt(string Code)
		{
			return Convert.ToInt32(Lua.LuaGetReturnValue(LuaPrep(Code), "Atlas.lua")[0]);
		}
		private decimal LuaGetDecimal(string Code)
		{
			return Convert.ToDecimal(Lua.LuaGetReturnValue(LuaPrep(Code), "Atlas.lua")[0]);
		}
		private List<int> LuaGetIntList(string Code)
		{
			List<string> Results = Lua.LuaGetReturnValue(LuaPrep(Code), "Atlas.lua");
			List<int> intResults = new List<int>();
			for (int i = 0; i < Results.Count; i++)
			{
				intResults.Add(Convert.ToInt32(Results[i]));
			}
			return intResults;
		}
		private string LuaGetString(string Code)
		{
			return Lua.LuaGetReturnValue(LuaPrep(Code), "Atlas.lua")[0];
		}
		private List<string> LuaGetStringList(string Code)
		{
			return Lua.LuaGetReturnValue(LuaPrep(Code), "Atlas.lua");
		}
		private void LuaDo(string Code)
		{
			Lua.DoString(Code, "Atlas.lua");
		}
		
		private void PetCheck(string logPrefix)
		{
			// In combat Pet Summon if Fel Domination is avaiable - disabled in Battlegrounds
			if (!InBattleground && PetPresenceTimer.ElapsedMilliseconds > 2000 && !Me.GotAlivePet && SpellManager.KnownSpells.ContainsKey("Fel Domination") && SpellManager.CanCastSpell("Fel Domination") && !SpellManager.KnownSpells["Fel Domination"].Cooldown && SoulShardCount > 0)
			{
				drlog(logPrefix + ": No Pet! In combat summon using Fel Domination");
				FelDomination();
				SummonPet();
			}
		}
		#endregion
	}
}
#pragma warning restore
namespace Styx.Bot.CustomClasses
{
	public partial class skiWarlockGUI : Form
	{
		skiWarlockConfig _skiWarlockConfig = new skiWarlockConfig();
		public static string CurrentProfile;
		/*
		// Enable this when working in Visual Studio to allow compling - comment out before packing
		public class Logging
		{
			public static string ApplicationPath = "";
		}
		*/
		public skiWarlockGUI()
		{
			// Init GUI
			InitializeComponent();
			// Load global config
			_skiWarlockConfig.Load();
			// Load profile list
			LoadProfileList();
			// Load GrindSettingsProfile in gloal config as the default setting profile
			ProfileGrid.SelectedObject = LoadProfile(_skiWarlockConfig.ActiveSettingsProfile);
			// Select GrindSettingsProfile in List
			listProfiles.SelectedItem = _skiWarlockConfig.ActiveSettingsProfile;
			// Update display labels
			UpdateProfileLabels();
			//MoveSplitter(ProfileGrid, -100);
		}
		public void UpdateProfileLabels()
		{
			lblActiveProfile.Text = _skiWarlockConfig.ActiveSettingsProfile;
			lblGrindProfile.Text = _skiWarlockConfig.GrindSettingsProfile;
			lblPVPProfile.Text = _skiWarlockConfig.PVPSettingsProfile;
		}
		private void MoveSplitter(PropertyGrid propertyGrid, int x)
		{
			object propertyGridView = typeof(PropertyGrid).InvokeMember("gridView", BindingFlags.GetField | BindingFlags.NonPublic | BindingFlags.Instance, null, propertyGrid, null);
			propertyGridView.GetType().InvokeMember("MoveSplitterTo", BindingFlags.InvokeMethod | BindingFlags.NonPublic | BindingFlags.Instance, null, propertyGridView, new object[] { x });
		}
		private static void log(string Message, params object[] args)
		{
			// Update status bar
			statusStripLabel.Text = string.Format(Message, args);
		}
		private void listProfiles_Select(object sender, EventArgs e)
		{
			// Toggle button states
			if (!btnSave.Enabled && btnLoad.Enabled) btnSave.Enabled = true;
			btnLoad.Enabled = true;
			btnRemove.Enabled = true;
			btnActivateProfile.Enabled = true;
			btnSetGrindProfile.Enabled = true;
			btnSetPVPProfile.Enabled = true;
		}
		private void SaveProfile(string Name)
		{
			// Variables
			string ProfilePath = PathCheck(string.Format(@"Config\{0}.xml", Name));
			// Add Name variable to config
			SettingsProfile Profile = (SettingsProfile)ProfileGrid.SelectedObject;
			Profile.Name = Name;
			// Log
			log("Saving: {0}", Name);
			// Serialize config and write to file
			try
			{
				// Serialize
				XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
				ns.Add("", "");
				TextWriter SingleWriter = new StreamWriter(ProfilePath);
				XmlSerializer SingleSerializer = new XmlSerializer(typeof(SettingsProfile));
				SingleSerializer.Serialize(SingleWriter, Profile, ns);
				SingleWriter.Close();
				// Log
				log("Saved: {0}", Name);
			}
			catch (Exception _Exception)
			{
				// Failed to save
				log("Failed to save: {0}, Error: {1}", ProfilePath, _Exception.Message);
			}
		}
		public static SettingsProfile LoadProfile(string Name)
		{
			// Variables
			SettingsProfile Settings;
			string ProfilePath = PathCheck(string.Format(@"Config\{0}.xml", Name));
			// Try to load and deserialize config file
			try
			{
				// Deserialize
				XmlSerializer deserializer = new XmlSerializer(typeof(SettingsProfile));
				TextReader textReader = new StreamReader(ProfilePath);
				Settings = (SettingsProfile)deserializer.Deserialize(textReader);
				textReader.Close();
				// Log
				log("Loaded: {0}", Name);
			}
			catch (Exception _Exception)
			{
				// Failed to load - return defaults
				log("Failed to load: {0}, Error: {1}", ProfilePath, _Exception.Message);
				// Create a default settings object
				Settings = new SettingsProfile(Name);
				// Save defaults to file
				Settings.Save();
			}
			// Update the profile name we are displaying
			DisplayName(Name);
			return Settings;
		}
		private void LoadProfileList()
		{
			// Variables
			string ProfilePath = PathCheck(@"Config\");
		
			// Clear items in list
			listProfiles.Items.Clear();
			// Iterate Config directory for Config files
			DirectoryInfo di = new DirectoryInfo(ProfilePath);
			FileInfo[] rgFiles = di.GetFiles("*.xml");
			foreach (FileInfo fi in rgFiles)
			{
				listProfiles.Items.Add(Path.GetFileNameWithoutExtension(fi.Name));
			}
			// Select active config in list
			listProfiles.SelectedItem = _skiWarlockConfig.ActiveSettingsProfile;
		}
		static string UppercaseFirst(string s)
		{
			if (string.IsNullOrEmpty(s)) return string.Empty;
			return char.ToUpper(s[0]) + s.Substring(1);
		}
		public void SetActive(string Name)
		{
			// Set new ActiveSettingsProfile in Config file
			_skiWarlockConfig.ActiveSettingsProfile = Name;
			_skiWarlockConfig.Save();
			// Load profile for displaying
			if (CurrentProfile != Name)
			{
				ProfileGrid.SelectedObject = LoadProfile(Name);
			}
			// Load profile list
			LoadProfileList();
			// Update display labels
			lblActiveProfile.Text = Name;
			// Log
			log("Active Profile Set: {0}", Name);
			// If skiWarlock is running, reload its settings
			if (skiWarlock.Instance != null)
			{
				skiWarlock.Instance.LoadSettings();
			}
		}
		public static void DisplayName(string Name)
		{
			// Set variable
			CurrentProfile = Name;
			// Update label value
			lblProfileName.Text = Name;
		}
		private void btnSaveAs_Click(object sender, EventArgs e)
		{
			// Return if no name was entered
			if (txtNewProfile.Text == "") return;
			// Variables
			string Name = UppercaseFirst(txtNewProfile.Text);
			// Save profile to file, rest and reload
			SaveProfile(Name);
			DisplayName(Name);
			LoadProfileList();
			listProfiles.SelectedItem = Name;
		}
		private void btnSave_Click(object sender, EventArgs e)
		{
			// Return if nothing has been selected
			if (listProfiles.SelectedItems.Count == 0) return;
			// Name of the profile
			string Name = listProfiles.SelectedItems[0].ToString();
			try
			{
				// Save profile to file
				SaveProfile(Name);
				// Disable save button
				btnSave.Enabled = false;
				// Update the profile name we are displaying
				DisplayName(Name);
				// If the loaded profile we are working on is CurrentProfile AND If skiWarlock is running, reload its settings
				if (CurrentProfile == Name && skiWarlock.Instance != null)
				{
					skiWarlock.Instance.LoadSettings();
				}
			}
			catch
			{
				log("Failed to save: {0}", Name);
			}
		}
		private void btnLoad_Click(object sender, EventArgs e)
		{
			// Return if nothing has been selected
			if (listProfiles.SelectedItems.Count == 0) return;
			// Name of the profile
			string Name = listProfiles.SelectedItems[0].ToString();
			try
			{
				// Load profile from file
				ProfileGrid.SelectedObject = LoadProfile(Name);
				// Disable save button
				btnSave.Enabled = false;
			}
			catch
			{
				log("Failed to save: {0}", Name);
			}
		}
		private void ProfileGrid_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
		{
			// Toggle Save button save on if off
			if (!btnSave.Enabled) btnSave.Enabled = true;
		}
		private void btnRemove_Click(object sender, EventArgs e)
		{
			// Return if nothing has been selected
			if (listProfiles.SelectedItems.Count == 0) return;
			// Variables
			string Name = listProfiles.SelectedItems[0].ToString();
			string ProfilePath = PathCheck(string.Format(@"Config\{0}.xml", Name));
			// Log
			log("Removing: {0}", Name);
			// Try to delete file
			try
			{
				// Delete
				File.Delete(ProfilePath);
				// Log
				log("Removed: {0}", Name);
			}
			catch (Exception _Exception)
			{
				// Failed to delete
				log("Failed to delete: {0}, Error: {1}", ProfilePath, _Exception.Message);
			}
			// Refresh Profile list after delete
			LoadProfileList();
			// If the profile we were editing was the removed profile, reload the active config profile
			if (CurrentProfile == Name && _skiWarlockConfig.ActiveSettingsProfile != Name)
			{
				ProfileGrid.SelectedObject = LoadProfile(_skiWarlockConfig.ActiveSettingsProfile);
			}
		}
		private void btnActivateProfile_Click(object sender, EventArgs e)
		{
			// Return if nothing has been selected
			if (listProfiles.SelectedItems.Count == 0) return;
			// Set selected profile in list as ActiveSettingsProfile
			SetActive(listProfiles.SelectedItems[0].ToString());
		}
		private void skiWarlockGUI_Load(object sender, EventArgs e)
		{
			// Refresh the Profile List when form is loaded
			LoadProfileList();
			// Update title label
			DisplayName(CurrentProfile);
			// Update profile labels
			UpdateProfileLabels();
		}
		private void btnSetGrindProfile_Click(object sender, EventArgs e)
		{
			// Return if nothing has been selected
			if (listProfiles.SelectedItems.Count == 0) return;
			_skiWarlockConfig.GrindSettingsProfile = listProfiles.SelectedItems[0].ToString();
			_skiWarlockConfig.Save();
			lblGrindProfile.Text = listProfiles.SelectedItems[0].ToString();
		}
		private void btnSetPVPProfile_Click(object sender, EventArgs e)
		{
			// Return if nothing has been selected
			if (listProfiles.SelectedItems.Count == 0) return;
			string Name = listProfiles.SelectedItems[0].ToString();
			_skiWarlockConfig.PVPSettingsProfile = Name;
			_skiWarlockConfig.Save();
			lblPVPProfile.Text = Name;
		}
		private static string PathCheck(string FilePath)
		{
			try
			{
				FilePath = Path.Combine(Logging.ApplicationPath, @"Routines\skiWarlock\" + FilePath);
			}
			catch { }
			if (!Directory.Exists(Path.GetDirectoryName(FilePath)))
			{
				Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
			}
			return FilePath;
		}
		public class skiWarlockConfig
		{
			// Variables
			public string ActiveSettingsProfile { get { return m_ActiveSettingsProfile; } set { m_ActiveSettingsProfile = value; } }
			public string GrindSettingsProfile { get { return m_GrindSettingsProfile; } set { m_GrindSettingsProfile = value; } }
			public string PVPSettingsProfile { get { return m_PVPSettingsProfile; } set { m_PVPSettingsProfile = value; } }
			public bool UseSecondaryTalentSpecForPVP { get { return m_UseSecondaryTalentSpecForPVP; } set { m_UseSecondaryTalentSpecForPVP = value; } }
			public bool Debug { get { return m_Debug; } set { m_Debug = value; } }
			
			// Defaults
			private string m_ActiveSettingsProfile = "Default";
			private string m_GrindSettingsProfile = "Default";
			private string m_PVPSettingsProfile = "Default PVP";
			private bool m_UseSecondaryTalentSpecForPVP = false;
			private bool m_Debug = false;
			// Variables
			private string SettingsPath = @"skiWarlock\skiWarlock.xml";
			// Constructor
			public skiWarlockConfig()
			{
				try
				{
					// If in HB, use the correct path for config variables
					SettingsPath = Path.Combine(Logging.ApplicationPath, @"Routines\" + SettingsPath);
				}
				catch { }
			}
			// Calls the above Constructor, then Loads config file data if passed true
			public skiWarlockConfig(bool AutoLoad) : this()
			{
				if (AutoLoad)
				{
					Load();
				}
			}
			// Save to file
			public void Save()
			{
				// Serialize settings to file
				XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
				ns.Add("", "");
				TextWriter SingleWriter = new StreamWriter(SettingsPath);
				XmlSerializer SingleSerializer = new XmlSerializer(typeof(skiWarlockConfig));
				SingleSerializer.Serialize(SingleWriter, this, ns);
				SingleWriter.Close();
			}
			// Load from file
			public void Load()
			{
				// Try load config file
				try
				{
					// Deserialize config file
					XmlSerializer deserializer = new XmlSerializer(typeof(skiWarlockConfig));
					TextReader textReader = new StreamReader(SettingsPath);
					//skiWarlockConfig Config;
					skiWarlockConfig Config = new skiWarlockConfig();
					Config = (skiWarlockConfig)deserializer.Deserialize(textReader);
					textReader.Close();
					// Assign variables
					this.ActiveSettingsProfile = Config.ActiveSettingsProfile;
					this.GrindSettingsProfile = Config.GrindSettingsProfile;
					this.PVPSettingsProfile = Config.PVPSettingsProfile;
					this.Debug = Config.Debug;
				}
				catch
				{
					// Cant find file, Save defaults to file
					Save();
				}
			}
		}
		public class SettingsProfile
		{
			public SettingsProfile()
			{
			}
			public SettingsProfile(string Name)
			{
				this.Name = Name;
			}
			public void Save()
			{
				// Variables
				string SettingsPath = PathCheck(string.Format(@"Config\{0}.xml", Name));
				// Serialize settings to file
				XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
				ns.Add("", "");
				TextWriter SingleWriter = new StreamWriter(SettingsPath);
				XmlSerializer SingleSerializer = new XmlSerializer(typeof(SettingsProfile));
				SingleSerializer.Serialize(SingleWriter, this, ns);
				SingleWriter.Close();
			}
			[Browsable(false)]
			public string Name { get { return m_Name; } set { m_Name = value; } }
			[Category("Talents")]
			[Description("Use the talent Dark Pack to leech mana from your pet")]
			[DisplayName("Dark Pack - Minimum Mana")]
			public int DarkPactMinMana { get { return m_DarkPactMinMana; } set { m_DarkPactMinMana = value; } }
			[Category("Spells")]
			[Description("Use Death Coil when your Health Percent drops below this value")]
			[DisplayName("Death Coil - Health Percent")]
			public int DeathCoilHealthPercent { get { return m_DeathCoilHealthPercent; } set { m_DeathCoilHealthPercent = value; } }
			[Category("General")]
			[Description("Stop using Direct Damage spells when your target drops below this value")]
			[DisplayName("Stop Direct Damage Health Percent")]
			public int DirectDmgMinHealth { get { return m_DirectDmgMinHealth; } set { m_DirectDmgMinHealth = value; } }
			[Category("Spells")]
			[Description("Dont cast Health Funnel if your Health Percent is below this value")]
			[DisplayName("Health Funnel - Dont Heal Health Percent")]
			public int DontHealPetBelow { get { return m_DontHealPetBelow; } set { m_DontHealPetBelow = value; } }
			[Category("General")]
			[Description("Stop using DOT spells when your target drops below this value")]
			[DisplayName("Stop DOTs Health Percent")]
			public int DotMinTargetHealth { get { return m_DotMinTargetHealth; } set { m_DotMinTargetHealth = value; } }
			[Category("Spells")]
			[Description("Dont cast Drain Life if your target's Health Percent is below this value")]
			[DisplayName("Drain Life - Minimum Target Health")]
			public int DrainLifeMinTargetHealth { get { return m_DrainLifeMinTargetHealth; } set { m_DrainLifeMinTargetHealth = value; } }
			[Category("Spells")]
			[Description("Cast Drain Life when your Health Percent drops below this value")]
			[DisplayName("Drain Life - Health Percent")]
			public int DrainLifePercent { get { return m_DrainLifePercent; } set { m_DrainLifePercent = value; } }
			[Category("Spells")]
			[Description("Cast Drain Soul when your target's Health Percent drops below this value - only used when you need Soul Shards")]
			[DisplayName("Drain Soul - Health Percent")]
			public int DrainSoulMaxHealthPercent { get { return m_DrainSoulMaxHealthPercent; } set { m_DrainSoulMaxHealthPercent = value; } }
			[Category("Spells")]
			[Description("Maximum number of times to fear a target in PVP")]
			[DisplayName("Fear - PVP - Maximum Fears")]
			public int FearCount { get { return m_FearCount; } set { m_FearCount = value; } }
			[Category("General")]
			[Description("If enabled, combat adds when they are pulled. This uses AOE if avaiable, otherwise each mob will be DOT'd")]
			[DisplayName("Fight Adds?")]
			public bool FightAdds { get { return m_FightAdds; } set { m_FightAdds = value; } }
			[Category("Pet")]
			[Description("Cast Health Funnel when your Pet drops below this value")]
			[DisplayName("Health Funnel - Use at Pet Health Percent")]
			public int HealPetPercent { get { return m_HealPetPercent; } set { m_HealPetPercent = value; } }
			[Category("Pet")]
			[Description("Stop casting Health Funnel when your Pet's Health Percent is above this value")]
			[DisplayName("Health Funnel - Stop Health Percent")]
			public int HealPetStopPercent { get { return m_HealPetStopPercent; } set { m_HealPetStopPercent = value; } }
			[Category("General")]
			[Description("Use a Health Potion when your Health Percent drops below this value")]
			[DisplayName("Health Potion - Health Percent")]
			public int HealthPotionUsePercent { get { return m_HealthPotionUsePercent; } set { m_HealthPotionUsePercent = value; } }
			[Category("General")]
			[Description("Use a Health Stone when your Health Percent drops below this value")]
			[DisplayName("Health Stone - Health Percent")]
			public int HealthStoneUsePercent { get { return m_HealthStoneUsePercent; } set { m_HealthStoneUsePercent = value; } }
			[Category("Spells")]
			[Description("Cast Life Tap when your Mana Percent drops below this value")]
			[DisplayName("Life Tap - Mana Percent")]
			public int LifeTapMaxMana { get { return m_LifeTapMaxMana; } set { m_LifeTapMaxMana = value; } }
			[Category("Spells")]
			[Description("Dont cast Life Tap if your Health Percent drops below this value")]
			[DisplayName("Life Tap - Minimum Health Percent")]
			public int LifeTapMinHealth { get { return m_LifeTapMinHealth; } set { m_LifeTapMinHealth = value; } }
			[Category("Talents")]
			[Description("Use Lifetap at this Pet Mana Percent to feed mana to your Pet")]
			[DisplayName("Mana Feed - Mana Percent")]
			public int ManaFeedPetManaPercent { get { return m_ManaFeedPetManaPercent; } set { m_ManaFeedPetManaPercent = value; } }
			[Category("General")]
			[Description("Use a Mana Potion when your Mana Percent drops below this value")]
			[DisplayName("Mana Potion - Health Percent")]
			public int ManaPotionUsePercent { get { return m_ManaPotionUsePercent; } set { m_ManaPotionUsePercent = value; } }
			[Category("General")]
			[Description("If enabled, extra mobs will be pulled in combat. This can greatly increases kills per hour, but should only be enabled when you are capable of handling multiple mobs at once")]
			[DisplayName("Mass Pull")]
			public bool MassPull { get { return m_MassPull; } set { m_MassPull = value; } }
			[Category("General")]
			[Description("The Maximum amount of mobs to be pulled with Mass Pull")]
			[DisplayName("Mass Pull - Maximum Adds")]
			public int MassPullMaxAdds { get { return m_MassPullMaxAdds; } set { m_MassPullMaxAdds = value; } }
			[Category("General")]
			[Description("The Minimum amount of mobs to be pulled with Mass Pull")]
			[DisplayName("Mass Pull - Minimum Adds")]
			public int MassPullMinAdds { get { return m_MassPullMinAdds; } set { m_MassPullMinAdds = value; } }
			[Category("General")]
			[Description("Dont pull more mobs if your Health Percent or your Pet's Health Percent fall below this value")]
			[DisplayName("Mass Pull - Minimum Health Percent")]
			public int MassPullMinInCombatHealth { get { return m_MassPullMinInCombatHealth; } set { m_MassPullMinInCombatHealth = value; } }
			[Category("General")]
			[Description("Dont pull more mobs if your Mana Percent or your Pet's Mana Percent fall below this value")]
			[DisplayName("Mass Pull - Minimum Mana Percent")]
			public int MassPullMinInCombatMana { get { return m_MassPullMinInCombatMana; } set { m_MassPullMinInCombatMana = value; } }
			[Category("General")]
			[Description("When Mass Pulling, use a single target rotation spell to pull the mob instead of waiting for the Pet to gain aggro. This greatly increases kills per hour, but should only be enabled when you are capable of handling few hits")]
			[DisplayName("Mass Pull - With Spell")]
			public bool MassPullWithSpell { get { return m_MassPullWithSpell; } set { m_MassPullWithSpell = value; } }
			[Category("General")]
			[Description("Maximum amount of Soul Shards to carry")]
			[DisplayName("Soul Shards - Maximum Amount")]
			public int MaxShards { get { return m_MaxShards; } set { m_MaxShards = value; } }
			[Category("General")]
			[Description("Sets HB's internal variable (Styx.Logic.Pathing.Navigator.PathPrecision) to this value. This effects how accurate the bot will be when determining if it has reached it's target location when moving. If you are getting stuck a lot, lower this value")]
			[DisplayName("Path Precision")]
			public float PathPrecision { get { return m_PathPrecision; } set { m_PathPrecision = value; } }
			[Category("Pet")]
			[Description("Sets which Pet to use. Auto will determine the best pet for your spec")]
			[DisplayName("Pet")]
			public string Pet { get { return m_Pet; } set { m_Pet = value; } }
			[Category("Pet")]
			[Description("Use your Pet to attack mobs when casting spells on them")]
			[DisplayName("Pet Attack Enabled")]
			public bool UsePetAttack { get { return m_UsePetAttack; } set { m_UsePetAttack = value; } }
			
			[Category("Glyphs")]
			[Description("Cast Life Tap (Rank 1) to buff Glyph Of Life Tap. If you are jumped and thrown into Combat (not a ranged pull) this value will be ignored")]
			[DisplayName("Pull with Life Tap (Rank 1)")]
			public bool PullWithGlyphOfLifeTap { get { return m_PullWithGlyphOfLifeTap; } set { m_PullWithGlyphOfLifeTap = value; } }
			[Category("Talents")]
			[Description("Cast Shadowbolt as your opening spell. This is only useful when using the 'Improved Shadowbolt' talent. If you are jumped and thrown into Combat (not a ranged pull) this value will be ignored")]
			[DisplayName("Pull with Shadowbolt")]
			public bool PullWithShadowBolt { get { return m_PullWithShadowBolt; } set { m_PullWithShadowBolt = value; } }
			[Category("General")]
			[Description("Eat food when your Health Percent drops below this value")]
			[DisplayName("Rest - Health Percent")]
			public int RestHealth { get { return m_RestHealth; } set { m_RestHealth = value; } }
			[Category("General")]
			[Description("Eat food when your Mana Percent drops below this value")]
			[DisplayName("Rest - Mana Percent")]
			public int RestMana { get { return m_RestMana; } set { m_RestMana = value; } }
			[Category("Talents")]
			[Description("Shadow Burn your target when they are at or below this value")]
			[DisplayName("Shadow Burn - Health Percent")]
			public int ShadowburnHealth { get { return m_ShadowburnHealth; } set { m_ShadowburnHealth = value; } }
			[Category("Spells")]
			[Description("Cast Chaos Bolt in your single target rotation")]
			[DisplayName("Chaos Bolt - Use?")]
			public bool UseChaosBolt { get { return m_UseChaosBolt; } set { m_UseChaosBolt = value; } }
			[Category("Spells")]
			[Description("Cast Curse of Agony in your single target rotation")]
			[DisplayName("Curse of Agony - Use?")]
			public bool UseCoA { get { return m_UseCoA; } set { m_UseCoA = value; } }
			[Category("Spells")]
			[Description("Cast Curse of Elements in your single target rotation")]
			[DisplayName("Curse of Elements - Use?")]
			public bool UseCoE { get { return m_UseCoE; } set { m_UseCoE = value; } }
			[Category("Spells")]
			[Description("Cast Conflagrate in your single target rotation")]
			[DisplayName("Conflagrate - Use?")]
			public bool UseConflagrate { get { return m_UseConflagrate; } set { m_UseConflagrate = value; } }
			[Category("Spells")]
			[Description("Cast Corruption in your single target rotation")]
			[DisplayName("Corruption - Use?")]
			public bool UseCorruption { get { return m_UseCorruption; } set { m_UseCorruption = value; } }
			[Category("Talents")]
			[Description("Cast Dark Pack Talent when your Mana is low")]
			[DisplayName("Dark Pack - Use?")]
			public bool UseDarkPact { get { return m_UseDarkPact; } set { m_UseDarkPact = value; } }
			[Category("Pet")]
			[Description("Cast Demonic Empowerment talent")]
			[DisplayName("Demonic Empowerment - Use?")]
			public bool UseDemonicEmpowerment { get { return m_UseDemonicEmpowerment; } set { m_UseDemonicEmpowerment = value; } }
			[Category("Buffs")]
			[Description("Use Detect Invisibility buff")]
			[DisplayName("Detect Invisibility - Use?")]
			public bool UseDetectInvisibility { get { return m_UseDetectInvisibility; } set { m_UseDetectInvisibility = value; } }
			[Category("Talents")]
			[Description("Useful if you have 'Improved Drain Soul' talent")]
			[DisplayName("Drain Soul - Use As Finisher")]
			public bool UseDrainSoulAsFinisher { get { return m_UseDrainSoulAsFinisher; } set { m_UseDrainSoulAsFinisher = value; } }
			[Category("Spells")]
			[Description("Cast Fear on PVE targets?")]
			[DisplayName("Fear - PVE - Use?")]
			public bool UseFearPVE { get { return m_UseFearPVE; } set { m_UseFearPVE = value; } }
			[Category("Spells")]
			[Description("Cast Fear on PVP targets?")]
			[DisplayName("Fear - PVP - Use?")]
			public bool UseFearPVP { get { return m_UseFearPVP; } set { m_UseFearPVP = value; } }
			[Category("Buffs")]
			[Description("Use your highest rank armor buff? Fel Armor > Demon Armor > Demon Skin")]
			[DisplayName("Armor Buff - Use?")]
			public bool UseArmorBuff { get { return m_UseArmorBuff; } set { m_UseArmorBuff = value; } }
			[Category("Buffs")]
			[Description("Use Spellstone weapon enchant. Only Spellstone or Firestone can be applied")]
			[DisplayName("Firestone - Use?")]
			public bool UseFirestone { get { return m_UseFirestone; } set { m_UseFirestone = value; } }
			[Category("Spells")]
			[Description("Cast Haunt in your single target rotation")]
			[DisplayName("Haunt - Use?")]
			public bool UseHaunt { get { return m_UseHaunt; } set { m_UseHaunt = value; } }
			[Category("General")]
			[Description("Use a Healthstone?")]
			[DisplayName("Healthstone - Use?")]
			public bool UseHealthstone { get { return m_UseHealthstone; } set { m_UseHealthstone = value; } }
			[Category("Spells")]
			[Description("Cast Immolate in your single target rotation")]
			[DisplayName("Immolate - Use?")]
			public bool UseImmolate { get { return m_UseImmolate; } set { m_UseImmolate = value; } }
			[Category("Spells")]
			[Description("Cast Incinerate in your single target rotation")]
			[DisplayName("Incinerate - Use?")]
			public bool UseIncinerate { get { return m_UseIncinerate; } set { m_UseIncinerate = value; } }
			[Category("Talents")]
			[Description("Cast Mana Feed to feed mana to your Pet via Lifetap")]
			[DisplayName("Mana Feed - Use?")]
			public bool UseManaFeed { get { return m_UseManaFeed; } set { m_UseManaFeed = value; } }
			[Category("Talents")]
			[Description("Use Metamorphosis talent?")]
			[DisplayName("Metamorphosis - Use?")]
			public bool UseMetamorphosis { get { return m_UseMetamorphosis; } set { m_UseMetamorphosis = value; } }
			[Category("Talents")]
			[Description("Only cast Metamorphosis when there are atleast this many Adds")]
			[DisplayName("Metamorphosis - Minimum Adds")]
			public int MetamorphosisMinAdds { get { return m_MetamorphosisMinAdds; } set { m_MetamorphosisMinAdds = value; } }
			[Category("Debug")]
			[Description("Useful to determine when your Pet and Caster are attacking")]
			[DisplayName("Raid Icons")]
			public bool UseRaidIcons { get { return m_UseRaidIcons; } set { m_UseRaidIcons = value; } }
			[Category("Spells")]
			[Description("Cast Searing Pain in your single target rotation")]
			[DisplayName("Searing Pain - Use?")]
			public bool UseSearingPain { get { return m_UseSearingPain; } set { m_UseSearingPain = value; } }
			[Category("Spells")]
			[Description("Cast Shadowbolt in your single target rotation")]
			[DisplayName("Shadowbolt - Use?")]
			public bool UseShadowbolt { get { return m_UseShadowbolt; } set { m_UseShadowbolt = value; } }
			[Category("Talents")]
			[Description("Cast Shadow Burn Talent in your single target rotation")]
			[DisplayName("Shadow Burn - Use?")]
			public bool UseShadowburn { get { return m_UseShadowburn; } set { m_UseShadowburn = value; } }
			[Category("Buffs")]
			[Description("Use Soulstone")]
			[DisplayName("Soulstone - Use?")]
			public bool UseSoulstone { get { return m_UseSoulstone; } set { m_UseSoulstone = value; } }
			[Category("Buffs")]
			[Description("Use Spellstone weapon enchant. Only Spellstone or Firestone can be applied")]
			[DisplayName("Spellstone - Use?")]
			public bool UseSpellstone { get { return m_UseSpellstone; } set { m_UseSpellstone = value; } }
			[Category("Spells")]
			[Description("Cast Unstable Afflication in your single target rotation")]
			[DisplayName("Unstable Afflication - Use?")]
			public bool UseUA { get { return m_UseUA; } set { m_UseUA = value; } }
			[Category("Buffs")]
			[Description("Use Unending Breath")]
			[DisplayName("Unending Breath - Use?")]
			public bool UseUnendingBreath { get { return m_UseUnendingBreath; } set { m_UseUnendingBreath = value; } }
			[Category("General")]
			[Description("Use Wand when your Health Percent drops below this value. Use 0 to disable")]
			[DisplayName("Wand - Health Percent")]
			public int WandHealth { get { return m_WandHealth; } set { m_WandHealth = value; } }
			[Category("General")]
			[Description("Use Wand when your Mana Percent drops below this value. Use 0 to disable")]
			[DisplayName("Wand - Mana Percent")]
			public int WandMana { get { return m_WandMana; } set { m_WandMana = value; } }
			private string m_Name = "New Profile";
			private int m_DarkPactMinMana = 80;
			private int m_DeathCoilHealthPercent = 60;
			private int m_DirectDmgMinHealth = 10;
			private int m_DontHealPetBelow = 50;
			private int m_DotMinTargetHealth = 20;
			private int m_DrainLifeMinTargetHealth = 30;
			private int m_DrainLifePercent = 60;
			private int m_DrainSoulMaxHealthPercent = 20;
			private int m_FearCount = 2;
			private bool m_FightAdds = true;
			private int m_HealPetPercent = 50;
			private int m_HealPetStopPercent = 90;
			private int m_HealthPotionUsePercent = 40;
			private int m_HealthStoneUsePercent = 40;
			private int m_LifeTapMaxMana = 75;
			private int m_LifeTapMinHealth = 50;
			private int m_ManaFeedPetManaPercent = 50;
			private int m_ManaPotionUsePercent = 30;
			private bool m_MassPull = false;
			private int m_MassPullMaxAdds = 4;
			private int m_MassPullMinAdds = 1;
			private int m_MassPullMinInCombatHealth = 50;
			private int m_MassPullMinInCombatMana = 50;
			private bool m_MassPullWithSpell = true;
			private int m_MaxShards = 5;
			private float m_PathPrecision = 1.8f;
			private string m_Pet = "Auto";
			private bool m_UsePetAttack = true;
			private bool m_PullWithGlyphOfLifeTap = false;
			private bool m_PullWithShadowBolt = false;
			private int m_RestHealth = 60;
			private int m_RestMana = 60;
			private int m_ShadowburnHealth = 20;
			private bool m_UseChaosBolt = false;
			private bool m_UseCoA = true;
			private bool m_UseCoE = false;
			private bool m_UseConflagrate = false;
			private bool m_UseCorruption = true;
			private bool m_UseDarkPact = false;
			private bool m_UseDemonicEmpowerment = true;
			private bool m_UseDetectInvisibility = false;
			private bool m_UseDrainSoulAsFinisher = false;
			private bool m_UseFearPVE = false;
			private bool m_UseFearPVP = true;
			private bool m_UseArmorBuff = true;
			private bool m_UseFirestone = false;
			private bool m_UseHaunt = false;
			private bool m_UseHealthstone = true;
			private bool m_UseImmolate = true;
			private bool m_UseIncinerate = false;
			private bool m_UseManaFeed = false;
			private bool m_UseMetamorphosis = false;
			private int m_MetamorphosisMinAdds = 2;
			private bool m_UseRaidIcons = false;
			private bool m_UseSearingPain = false;
			private bool m_UseShadowbolt = true;
			private bool m_UseShadowburn = false;
			private bool m_UseSoulstone = false;
			private bool m_UseSpellstone = true;
			private bool m_UseUA = false;
			private bool m_UseUnendingBreath = false;
			private int m_WandHealth = 10;
			private int m_WandMana = 10;
		}
	}
}
namespace Styx.Bot.CustomClasses
{
	partial class skiWarlockGUI
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.statusStrip = new System.Windows.Forms.StatusStrip();
			statusStripLabel = new System.Windows.Forms.ToolStripStatusLabel();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.lblPVPProfile = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.lblGrindProfile = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.btnSetGrindProfile = new System.Windows.Forms.Button();
			this.btnSetPVPProfile = new System.Windows.Forms.Button();
			this.lblActiveProfile = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.btnActivateProfile = new System.Windows.Forms.Button();
			this.btnRemove = new System.Windows.Forms.Button();
			this.btnLoad = new System.Windows.Forms.Button();
			this.txtNewProfile = new System.Windows.Forms.TextBox();
			this.btnSave = new System.Windows.Forms.Button();
			this.listProfiles = new System.Windows.Forms.ListBox();
			this.btnSaveAs = new System.Windows.Forms.Button();
			this.ProfileGrid = new System.Windows.Forms.PropertyGrid();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			lblProfileName = new System.Windows.Forms.Label();
			this.statusStrip.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// statusStrip
			// 
			this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
			statusStripLabel});
			this.statusStrip.Location = new System.Drawing.Point(0, 499);
			this.statusStrip.Name = "statusStrip";
			this.statusStrip.Size = new System.Drawing.Size(557, 22);
			this.statusStrip.TabIndex = 2;
			// 
			// statusStripLabel
			// 
			statusStripLabel.Name = "statusStripLabel";
			statusStripLabel.Size = new System.Drawing.Size(0, 17);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.lblPVPProfile);
			this.groupBox2.Controls.Add(this.label6);
			this.groupBox2.Controls.Add(this.lblGrindProfile);
			this.groupBox2.Controls.Add(this.label4);
			this.groupBox2.Controls.Add(this.btnSetGrindProfile);
			this.groupBox2.Controls.Add(this.btnSetPVPProfile);
			this.groupBox2.Controls.Add(this.lblActiveProfile);
			this.groupBox2.Controls.Add(this.label2);
			this.groupBox2.Controls.Add(this.label1);
			this.groupBox2.Controls.Add(this.btnActivateProfile);
			this.groupBox2.Controls.Add(this.btnRemove);
			this.groupBox2.Controls.Add(this.btnLoad);
			this.groupBox2.Controls.Add(this.txtNewProfile);
			this.groupBox2.Controls.Add(this.btnSave);
			this.groupBox2.Controls.Add(this.listProfiles);
			this.groupBox2.Controls.Add(this.btnSaveAs);
			this.groupBox2.Location = new System.Drawing.Point(347, 0);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(186, 479);
			this.groupBox2.TabIndex = 2;
			this.groupBox2.TabStop = false;
			// 
			// lblPVPProfile
			// 
			this.lblPVPProfile.Location = new System.Drawing.Point(83, 181);
			this.lblPVPProfile.Name = "lblPVPProfile";
			this.lblPVPProfile.Size = new System.Drawing.Size(96, 18);
			this.lblPVPProfile.TabIndex = 13;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(6, 181);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(72, 13);
			this.label6.TabIndex = 12;
			this.label6.Text = "PVP Profile:";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lblGrindProfile
			// 
			this.lblGrindProfile.Location = new System.Drawing.Point(83, 163);
			this.lblGrindProfile.Name = "lblGrindProfile";
			this.lblGrindProfile.Size = new System.Drawing.Size(96, 18);
			this.lblGrindProfile.TabIndex = 11;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(6, 163);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(72, 13);
			this.label4.TabIndex = 10;
			this.label4.Text = "Grind Profile:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// btnSetGrindProfile
			// 
			this.btnSetGrindProfile.Enabled = false;
			this.btnSetGrindProfile.Location = new System.Drawing.Point(6, 309);
			this.btnSetGrindProfile.Name = "btnSetGrindProfile";
			this.btnSetGrindProfile.Size = new System.Drawing.Size(173, 30);
			this.btnSetGrindProfile.TabIndex = 9;
			this.btnSetGrindProfile.Text = "Set as Grind Profile";
			this.btnSetGrindProfile.UseVisualStyleBackColor = true;
			this.btnSetGrindProfile.Click += new System.EventHandler(this.btnSetGrindProfile_Click);
			// 
			// btnSetPVPProfile
			// 
			this.btnSetPVPProfile.Enabled = false;
			this.btnSetPVPProfile.Location = new System.Drawing.Point(6, 345);
			this.btnSetPVPProfile.Name = "btnSetPVPProfile";
			this.btnSetPVPProfile.Size = new System.Drawing.Size(173, 30);
			this.btnSetPVPProfile.TabIndex = 8;
			this.btnSetPVPProfile.Text = "Set as PVP Profile";
			this.btnSetPVPProfile.UseVisualStyleBackColor = true;
			this.btnSetPVPProfile.Click += new System.EventHandler(this.btnSetPVPProfile_Click);
			// 
			// lblActiveProfile
			// 
			this.lblActiveProfile.Location = new System.Drawing.Point(83, 145);
			this.lblActiveProfile.Name = "lblActiveProfile";
			this.lblActiveProfile.Size = new System.Drawing.Size(96, 18);
			this.lblActiveProfile.TabIndex = 7;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(6, 145);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(72, 13);
			this.label2.TabIndex = 6;
			this.label2.Text = "Active Profile:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(50, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(77, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Setting Profiles";
			// 
			// btnActivateProfile
			// 
			this.btnActivateProfile.Enabled = false;
			this.btnActivateProfile.Location = new System.Drawing.Point(6, 273);
			this.btnActivateProfile.Name = "btnActivateProfile";
			this.btnActivateProfile.Size = new System.Drawing.Size(173, 30);
			this.btnActivateProfile.TabIndex = 5;
			this.btnActivateProfile.Text = "Activate Profile";
			this.btnActivateProfile.UseVisualStyleBackColor = true;
			this.btnActivateProfile.Click += new System.EventHandler(this.btnActivateProfile_Click);
			// 
			// btnRemove
			// 
			this.btnRemove.Enabled = false;
			this.btnRemove.Location = new System.Drawing.Point(6, 443);
			this.btnRemove.Name = "btnRemove";
			this.btnRemove.Size = new System.Drawing.Size(173, 30);
			this.btnRemove.TabIndex = 4;
			this.btnRemove.Text = "Remove";
			this.btnRemove.UseVisualStyleBackColor = true;
			this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
			// 
			// btnLoad
			// 
			this.btnLoad.Enabled = false;
			this.btnLoad.Location = new System.Drawing.Point(6, 201);
			this.btnLoad.Name = "btnLoad";
			this.btnLoad.Size = new System.Drawing.Size(173, 30);
			this.btnLoad.TabIndex = 2;
			this.btnLoad.Text = "Load";
			this.btnLoad.UseVisualStyleBackColor = true;
			this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
			// 
			// txtNewProfile
			// 
			this.txtNewProfile.Location = new System.Drawing.Point(6, 381);
			this.txtNewProfile.Name = "txtNewProfile";
			this.txtNewProfile.Size = new System.Drawing.Size(172, 20);
			this.txtNewProfile.TabIndex = 3;
			// 
			// btnSave
			// 
			this.btnSave.Enabled = false;
			this.btnSave.Location = new System.Drawing.Point(6, 237);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(173, 30);
			this.btnSave.TabIndex = 1;
			this.btnSave.Text = "Save";
			this.btnSave.UseVisualStyleBackColor = true;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// listProfiles
			// 
			this.listProfiles.FormattingEnabled = true;
			this.listProfiles.Items.AddRange(new object[] {
			"Default"});
			this.listProfiles.Location = new System.Drawing.Point(6, 20);
			this.listProfiles.Name = "listProfiles";
			this.listProfiles.Size = new System.Drawing.Size(173, 121);
			this.listProfiles.TabIndex = 3;
			this.listProfiles.SelectedIndexChanged += new System.EventHandler(this.listProfiles_Select);
			// 
			// btnSaveAs
			// 
			this.btnSaveAs.Location = new System.Drawing.Point(6, 407);
			this.btnSaveAs.Name = "btnSaveAs";
			this.btnSaveAs.Size = new System.Drawing.Size(173, 30);
			this.btnSaveAs.TabIndex = 0;
			this.btnSaveAs.Text = "Save As";
			this.btnSaveAs.UseVisualStyleBackColor = true;
			this.btnSaveAs.Click += new System.EventHandler(this.btnSaveAs_Click);
			// 
			// ProfileGrid
			// 
			this.ProfileGrid.Location = new System.Drawing.Point(6, 24);
			this.ProfileGrid.Name = "ProfileGrid";
			this.ProfileGrid.SelectedObject = new Styx.Bot.CustomClasses.skiWarlockGUI.SettingsProfile();
			this.ProfileGrid.Size = new System.Drawing.Size(335, 449);
			this.ProfileGrid.TabIndex = 3;
			this.ProfileGrid.PropertyValueChanged += new System.Windows.Forms.PropertyValueChangedEventHandler(this.ProfileGrid_PropertyValueChanged);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(lblProfileName);
			this.groupBox1.Controls.Add(this.ProfileGrid);
			this.groupBox1.Controls.Add(this.groupBox2);
			this.groupBox1.Location = new System.Drawing.Point(10, 10);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(533, 479);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			// 
			// lblProfileName
			// 
			lblProfileName.AutoSize = true;
			lblProfileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			lblProfileName.Location = new System.Drawing.Point(6, -4);
			lblProfileName.Name = "lblProfileName";
			lblProfileName.Size = new System.Drawing.Size(121, 25);
			lblProfileName.TabIndex = 4;
			lblProfileName.Text = "New Profile";
			// 
			// skiWarlockGUI
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(557, 521);
			this.Controls.Add(this.statusStrip);
			this.Controls.Add(this.groupBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "skiWarlockGUI";
			this.Text = "skiWarlock Configuration";
			this.Load += new System.EventHandler(this.skiWarlockGUI_Load);
			this.statusStrip.ResumeLayout(false);
			this.statusStrip.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		#endregion
		private System.Windows.Forms.StatusStrip statusStrip;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Button btnRemove;
		private System.Windows.Forms.Button btnLoad;
		private System.Windows.Forms.TextBox txtNewProfile;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.ListBox listProfiles;
		private System.Windows.Forms.Button btnSaveAs;
		private System.Windows.Forms.PropertyGrid ProfileGrid;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button btnActivateProfile;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblActiveProfile;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnSetGrindProfile;
		private System.Windows.Forms.Button btnSetPVPProfile;
		private System.Windows.Forms.Label lblPVPProfile;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label lblGrindProfile;
		private System.Windows.Forms.Label label4;
		// static
		private static System.Windows.Forms.ToolStripStatusLabel statusStripLabel;
		private static System.Windows.Forms.Label lblProfileName;
	}
}